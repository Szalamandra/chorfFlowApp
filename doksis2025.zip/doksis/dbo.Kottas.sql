﻿CREATE TABLE [dbo].[Kottas] (
    [Id]        INT            IDENTITY (1, 1) NOT NULL,
    [DateTime]  DATETIME       NOT NULL,
    [Kiadas]    NVARCHAR (255) NOT NULL,
    [Eloado_Id] NVARCHAR (128) NOT NULL,
    [Mufaj_Id]  TINYINT        NOT NULL,
    CONSTRAINT [PK_dbo.Kottas] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [FK_dbo.Kottas_dbo.AspNetUsers_Eloado_Id] FOREIGN KEY ([Eloado_Id]) REFERENCES [dbo].[AspNetUsers] ([Id]) ON DELETE CASCADE,
    CONSTRAINT [FK_dbo.Kottas_dbo.Mufajs_Mufaj_Id] FOREIGN KEY ([Mufaj_Id]) REFERENCES [dbo].[Mufajs] ([Id]) ON DELETE CASCADE
);


GO
CREATE NONCLUSTERED INDEX [IX_Eloado_Id]
    ON [dbo].[Kottas]([Eloado_Id] ASC);


GO
CREATE NONCLUSTERED INDEX [IX_Mufaj_Id]
    ON [dbo].[Kottas]([Mufaj_Id] ASC);

