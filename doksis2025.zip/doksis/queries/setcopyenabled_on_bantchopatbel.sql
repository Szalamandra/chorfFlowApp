WITH
  tableList   
AS
(
            SELECT '%EZE_ERZEUGUNGSEINHEIT"%' AS match
  UNION ALL SELECT '%EZE_PRODUKTFAMILIE"%' AS match
  UNION ALL SELECT '%STA_GRUPPE"%' AS match
  UNION ALL SELECT '%V_EDH_UNI_DOMAINTYPES"%' AS match
  UNION ALL SELECT '%_KTG_%' AS match
)

UPDATE [harnes].[MainControlTable_lvn] set copyenabled=0 where  
  [CopySourceSettings] not like '%MND_ID = %'  and [CopySourceSettings] not like '%_DOKUMENTATION%' 
  and NOT EXISTS (SELECT * FROM tableList WHERE [harnes].[MainControlTable_lvn].SourceObjectSettings LIKE match)
