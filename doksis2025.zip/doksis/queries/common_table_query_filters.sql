SELECT *
  FROM [eam].[MainControlTable_Common] where BU_Code='LVN' and -- is not Null --and IsFullLoad is Null and RequiredInJoin is Null
  copyenabled=1 and
  --JoinInfo is not null --and
  --IsFullLoad is not null --and
  FilterCriteria is not Null --order by IsFullLoad
  --ViewName like  '%jsto%'
  order by viewname

  --/ETN/IPM_EQUIP  bukrs
--/ETN/IPM_EQUZ  iwerk
--/ETN/IPM_FL_V2   iwerk
--/ETN/IPMABCTXT

--/ETN/IPMFLCATTXT
--/ETN/IPMFLTXT
--/ETN/IPMSQEQUIP   bukrs
--/ETN/IPMSQMDOCM
--/ETN/IPMSQMPHDR
--/ETN/IPMSQMPITM  iwerk
--/ETN/IPMSQNOITM
--/ETN/IPMSQNOFHDR  bukrs