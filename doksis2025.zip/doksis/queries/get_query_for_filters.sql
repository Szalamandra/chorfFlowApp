 
 --select split(JSON_VALUE(b.value, '$.rfcTableFields') as query from (select JSON_VALUE(a.value, '$.table') as tablename,CopySourceSettings FROM [isu].[MainControlTable_hen]
--cross apply OPENJSON(json_array([SourceObjectSettings])) as a WHERE ISJSON(a.value) = 1 and JSON_VALUE(a.value, '$.table')='ZISU_MDAT') as inner_q
--cross apply OPENJSON(json_array([CopySourceSettings])) as b --WHERE ISJSON(a.value) = 1


select tablename, JSON_VALUE(b.value, '$.rfcTableOptions') as query FROM ( select JSON_VALUE(a.value, '$.table') as tablename,CopySourceSettings FROM [isu].[MainControlTable_hen]
cross apply OPENJSON(json_array([SourceObjectSettings])) as a WHERE ISJSON(a.value) = 1 and JSON_VALUE(a.value, '$.table')='ZISU_MDAT') as inner_q
cross apply OPENJSON(json_array([CopySourceSettings])) as b 

SELECT Top 1 SinkObjectSettings, ROW_NUMBER() OVER (ORDER BY [TaskId], [Id] DESC) AS RowNumber
                             FROM @{pipeline().parameters.MainControlTableName_Schema}.@{pipeline().parameters.MainControlTableName}
                             where TopLevelPipelineName = '@{pipeline().parameters.TopLevelPipelineName}'