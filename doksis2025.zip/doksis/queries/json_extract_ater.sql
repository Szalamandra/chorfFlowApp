with cte as (
select JSON_VALUE(x.value, '$.table') as tablename,[CopySourceSettings]   FROM [ecount].[MainControlTable_miz]
cross apply OPENJSON(json_array([SourceObjectSettings])) as x   WHERE ISJSON(x.value) = 1--and JSON_VALUE(x.value, '$.table')='AUFK'
) 

select tablename, JSON_VALUE(y.value,'$.query') as query from cte cross apply OPENJSON(json_array([CopySourceSettings])) as y  WHERE  ISJSON(y.value) = 1




with cte as (
select JSON_VALUE(x.value, '$.table') as tablename,[CopySourceSettings]   FROM  @{pipeline().parameters.MainControlTableName_Schema}.@{pipeline().parameters.MainControlTableName}
cross apply OPENJSON(json_array([SourceObjectSettings])) as x   WHERE ISJSON(x.value) = 1
) 

select tablename, JSON_VALUE(y.value,'$.query') as query from cte cross apply OPENJSON(json_array([CopySourceSettings])) as y  WHERE  ISJSON(y.value) = 1


