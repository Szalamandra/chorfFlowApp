
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [eam].[HawEamUpdate]  ON [eam].[MainControlTable_haw]    AFTER    UPDATE  AS  EXEC  [dbo].[SP_GetViewsDetails_EAM]; 
GO

ALTER TABLE [eam].[MainControlTable_haw] ENABLE TRIGGER [HawEamUpdate]
GO