

--with cte as (SELECT Top 1 SourceObjectSettings
       --                      FROM [leanix].[MainControlTable_edt]
  --                           where TopLevelPipelineName = 'leanix_edt' ORDER BY [TaskId], [Id] DESC)

  with cte as (select JSON_VALUE(a.value, '$.table') as tablename,* FROM [leanix].[MainControlTable_edt]
cross apply OPENJSON(json_array([SourceObjectSettings])) as a WHERE ISJSON(a.value) = 1 and JSON_VALUE(a.value, '$.table')='Application')

select JSON_VALUE(x.value, '$.xPath') as xpath, JSON_VALUE(x.value, '$.unrollPath') as unrollPath 
from cte
cross apply OPENJSON(json_array(CopySourceSettings)) as x WHERE ISJSON(x.value) = 1

--select JSON_VALUE(x.value, '$.xpath') as xpath, JSON_VALUE(x.value, '$.unrollPath') as unrollPath FROM [leanix].[MainControlTable_edt]
--cross apply OPENJSON(json_array(CopySourceSettings)) as x WHERE ISJSON(x.value) = 1

--select JSON_VALUE(x.value, '$.table') as tablename,JSON_VALUE(j.value, '$.xpath') as xpath, JSON_VALUE(j.value, '$.unrollPath') as unrollPath FROM [leanix].[MainControlTable_edt]
--cross apply OPENJSON(json_array([SourceObjectSettings])) as x, OPENJSON(json_array([CopySourceSettings])) as j WHERE ISJSON(x.value) = 1 and ISJSON(j.value) = 1 and JSON_VALUE(x.value, '$.table')='Application'