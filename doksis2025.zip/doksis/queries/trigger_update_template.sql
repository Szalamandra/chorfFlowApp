
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO

--CREATE TRIGGER [s4u].[HawS4uInsert]  ON [s4u].[MainControlTable_haw]    AFTER    INSERT  AS  EXEC  [dbo].[SP_GetViewsDetails_S4U]; 
--GO

--ALTER TABLE [s4u].[MainControlTable_haw] ENABLE TRIGGER [HawS4uInsert]
--GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [eam].[LvnEamInsert]  ON [eam].[MainControlTable_lvn]    AFTER    INSERT  AS  EXEC  [dbo].[SP_GetViewsDetails_EAM]; 
GO

ALTER TABLE [eam].[MainControlTable_lvn] ENABLE TRIGGER [LvnEamInsert]
GO
