DECLARE @json NVARCHAR(MAX)
DECLARE @var NVARCHAR(MAX)

SET @json='{"name":"John","surname":"Doe","age":45,"skills":["SQL","C#","MVC"]}';
set @var= '[s4u].[MainControlTable_bag]'
SELECT *
FROM OPENJSON(@json);


with cte as (select o.*,
 (select [CopySourceSettings]  
    from [s4u].[MainControlTable_bag] i 
        where o.Id=i.Id for json auto) as JsonColumn 
 from [s4u].[MainControlTable_bag] o)

select JSON_VALUE(a.value, '$.partitionOption'), JSON_VALUE(a.value, '$.query') as part FROM cte
 cross apply OPENJSON(json_array([CopySourceSettings])) as a WHERE ISJSON(a.value) = 1

 --with cs as (select [CopySourceSettings] FROM [s4u].[MainControlTable_bag))

 --select JSON_VALUE(cs, '$.partitionOption'), JSON_VALUE(cs, '$.query') as part from 
--(select [CopySourceSettings] FROM [s4u].[MainControlTable_bag]) as cs


--{"schema": "Application", "table": "Application", "business_unit_name": "EDT", "table_type": "regular"}

select JSON_VALUE(x.value, '$.table') as tablename FROM [leanix].[MainControlTable_edt]
cross apply OPENJSON(json_array([SourceObjectSettings])) as x WHERE ISJSON(x.value) = 1

select JSON_VALUE(x.value, '$.xpath') as xpath, JSON_VALUE(x.value, '$.unrollPath') as unrollPath FROM [leanix].[MainControlTable_edt]
cross apply OPENJSON(json_array(CopySourceSettings)) as x WHERE ISJSON(x.value) = 1

