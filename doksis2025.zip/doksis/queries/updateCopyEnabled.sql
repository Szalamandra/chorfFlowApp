  update [iconnect].[MainControlTable_lvn] set CopyEnabled = 0 where id  in (35)


