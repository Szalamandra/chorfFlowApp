

with CTE_t(loadType) as (select JSON_VALUE(x.value, '$.dataLoadingBehavior') as loadType FROM [eegis].[MainControlTable_hen]
cross apply OPENJSON(json_array(DataLoadingBehaviorSettings )) as x WHERE ISJSON(x.value) = 1)

select count(*) as fulload_cnt from CTE_t
