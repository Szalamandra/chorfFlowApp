SELECT TOP (1000) [Id]
      ,[SchemaName]
      ,[ViewName]
      ,[ColumnNames]
      ,[Select_Query]
      ,[JoinInfo]
      ,[FilterCriteria]
      ,[BU_Code]
      ,[CreatedDate]
      ,[ModifiedDate]
      ,[MANDT]
      ,[CopyEnabled]
      ,[ApplyUnion]
      ,[IsFullLoad]
      ,[RequiredInJoin]
  FROM [s4u].[MainControlTable_Common] 

  select * from [s4u].[MainControlTable_Common]  where (BU_Code='VSE' and IsFullLoad = 'Y' and FilterCriteria is NULL) 
  --or (BU_Code='VSE' and RequiredInJoin='Y' ) 

