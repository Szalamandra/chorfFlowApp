-- =======================================================
-- /****** Object:  StoredProcedure [dbo].[InsertCopyLogsEDH]    Script Date: 11/23/2023 3:48:51 PM ******/
-- =======================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      <Author, , Reka.Zsigmond>
-- Create Date: <Create Date,123-11-2023 >

-- =============================================
CREATE PROCEDURE [dbo].[InsertCopyLogsEDH]
		(@ADF_PipelineRunId NVARCHAR(100),
            @ADF_Name NVARCHAR(100),
            @ADF_PipelineName NVARCHAR(100),
            @Environment NVARCHAR(100),
            @Copy_Status NVARCHAR(100),
			@Trigger_Name NVARCHAR(100),
			@Trigger_Time DATETIME,
			@Copy_Summary NVARCHAR(MAX))
AS
BEGIN
    SET NOCOUNT ON

    -- Insert statements for procedure here
    IF NOT EXISTS (
    SELECT * FROM sys.tables t 
    JOIN sys.schemas s ON (t.schema_id = s.schema_id) 
    WHERE s.name = 'dbo' AND t.name = 'edh_ADF_Copy_Logs') 	
    CREATE TABLE dbo.edh_ADF_Copy_Logs (
	ADF_PipelineRunId NVARCHAR(100) NOT NULL PRIMARY KEY, 		
       ADF_Name NVARCHAR(100),
       ADF_PipelineName  NVARCHAR(100),
	   Environment NVARCHAR(100),
	   Copy_Status  NVARCHAR(100),
	   Trigger_Name  NVARCHAR(100),
	   Trigger_Time DATETIME,
	   Copy_Summary NVARCHAR(MAX)
        );

     INSERT INTO dbo.edh_ADF_Copy_Logs
          (
		  ADF_PipelineRunId,
			ADF_Name,
            ADF_PipelineName,
            Environment,
            Copy_Status,
			Trigger_Name,
			Trigger_Time,
			Copy_Summary
          ) 
     VALUES 
          ( @ADF_PipelineRunId,
            @ADF_Name,
            @ADF_PipelineName,
            @Environment,
            @Copy_Status,
			@Trigger_Name,
			@Trigger_Time,
			@Copy_Summary
          ) 

END 
GO
