
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--CREATE TRIGGER [s4u].[MizS4uUpdate]  ON [s4u].[MainControlTable_miz]    AFTER    UPDATE  AS  EXEC  [dbo].[SP_GetViewsDetails_S4U]; 
--GO

--ALTER TABLE [s4u].[MainControlTable_miz] ENABLE TRIGGER [MizS4uUpdate]
--GO







CREATE TRIGGER [eam].[LvnEamUpdate]  ON [eam].[MainControlTable_lvn]    AFTER    UPDATE  AS  EXEC  [dbo].[SP_GetViewsDetails_EAM]; 
GO

ALTER TABLE [eam].[MainControlTable_lvn] ENABLE TRIGGER [LvnEamUpdate]
GO


