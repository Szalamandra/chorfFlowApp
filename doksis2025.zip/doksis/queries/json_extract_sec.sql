with cte as (
select JSON_VALUE(x.value, '$.table') as tablename, [CopyActivitySettings] FROM [isu].[MainControlTable_hen]
cross apply OPENJSON(json_array([SourceObjectSettings])) as x  WHERE ISJSON(x.value) = 1 and JSON_VALUE(x.value, '$.table')='AUFK'
) 

select tablename, [CopyActivitySettings] from cte where tablename='ZISU_MDAT'


  
 -- select tablename, JSON_VALUE(y.value, '$.translator') as translator from cte
 --  cross apply OPENJSON([CopyActivitySettings]) as y where ISJSON(y.value) = 1


 with cte as (
select JSON_VALUE(x.value, '$.table') as tablename, [CopyActivitySettings] FROM @{pipeline().parameters.MainControlTableName_Schema}.@{pipeline().parameters.MainControlTableName} 
cross apply OPENJSON(json_array([SourceObjectSettings])) as x  WHERE ISJSON(x.value) = 1 )

select tablename, [CopyActivitySettings] from cte where tablename='@{substring(item().name,0,sub(length(item().name),20))}'
