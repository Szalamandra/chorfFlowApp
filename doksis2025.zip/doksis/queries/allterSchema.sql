


  --ALTER SCHEMA isu111 TRANSFER [isu].[MainControlTable_hen]

--CREATE SCHEMA isu111 AUTHORIZATION isu
--GO

ALTER SCHEMA [isu101]
TRANSFER [isu].[MainControlTable_hen]
GO