DECLARE @json NVARCHAR(MAX)



with cte as (SELECT Top 1 SourceObjectSettings
                             FROM [nexthink].[MainControlTable_edt]
                             where TopLevelPipelineName = 'nexthink_edt' ORDER BY [TaskId], [Id] DESC);


