# Databricks notebook source
import os
import requests
import json
import sys


from src.utils.config_handler import *

from src.utils.cluster_config import *
from src.utils.utils import fileExists
from src.utils.logger import DBFSLogger, logging
from src.utils.job_dispatcher import  *
from typing import Generator, Dict, Any, List
from src.utils.erwin_json import read_json_df

from pyspark.sql.functions import explode, col,lower
from difflib import SequenceMatcher





# COMMAND ----------

current_directory=os.getcwd()
if current_directory=="/databricks/driver":
    current_directory="/Workspace/Repos/release/edh-en-edz-eam/src/generalized_pipeline/scripts"
config_directory="dbfs:/libraries/edh-en-edz-eam/src/generalized_pipeline/scripts"
script_current_directory=current_directory.replace("/Workspace","")

ws_url=spark.conf.get("spark.databricks.workspaceUrl")

# COMMAND ----------

# Get Configuration Variables
config_df =get_config_df(config_directory)
(env, net_type, token) = get_config_values(config_df,ws_url)
storage_account = get_storage_account(net_type,env)


# COMMAND ----------

# Setting Credentials using Platform Values
(scope, client_id, client_secret, tenant_id) =  get_platform_config(config_directory, net_type, env)
set_credentials(scope,storage_account,client_id,client_secret,tenant_id)

# COMMAND ----------

# setting credentials on erwin storage account
(scope, client_id, client_secret, tenant_id) =  get_platform_config(config_directory, net_type, env)
metadata_storage_account = get_metadata_storage_account(net_type)
set_credentials(scope,metadata_storage_account,client_id,client_secret,tenant_id)

# COMMAND ----------


# Getting Payload json from ADF
dbutils.widgets.text("payload_json", "","") 
dbutils.widgets.text("query_json", "","") 

payload_json = dbutils.widgets.get("payload_json")

query_json=dbutils.widgets.get("query_json") 

payload_json=json.loads(payload_json) 
query_json=json.loads(query_json) 

# COMMAND ----------

# MAGIC %md
# MAGIC ----------------------------------------------------------------------------------------------

# COMMAND ----------

class Schema_Validation:

    def __init__(self,query_json: Generator[List, None, None], payload_json: Generator[List, None, None],storage_account: str,logger: DBFSLogger):
        self.payload_json=payload_json
        self.query_json=self.handling_null_values(query_json)
        self.storage_account=storage_account
        self.logger=logger
        self.json_metadata_path=self.payload_json["erwin_json_file"]       
        self.json_metadata=self.get_json_metadata()
        self.exploded_erwin_dF=self.get_exploded_erwin_dF()

        self.erwin_Unbundling=self.unbundling_criteria()
        self.erwin_dso_type=self.get_erwin_dso_type()
        self.erwin_filter_criteria_dict=self.get_erwin_filter_criteria_dict()
        self.exploded_erwin_tables_with_filter=self.get_tables_withFilters_df()
        self.tables_dict_erwin=self.get_tables_dict_erwin()
        self.messages=[]

    @staticmethod
    def handling_null_values(query_json: dict) -> dict:
        for key in query_json:
            for v in key:
                if not key.get(v):
                    key[v] = ""
        return query_json
    
    def get_json_metadata(self):
        json_metadata_path=get_erwin_json_path(self.payload_json)
        json_metadata=read_json_df(json_metadata_path)
        return json_metadata
    def get_exploded_erwin_dF(self):
        #table level erwin
        exploded_erwin_dF = self.json_metadata.withColumn('tables_f',explode(col('tables'))).drop('tables')  #.select("t.tableDefinition")
        return exploded_erwin_dF
    
    def unbundling_criteria(self):
        erwin_Unbundling='200' if self.json_metadata.select(explode('extendedProperties').alias('x'))\
                .select('x.value').filter(col('x.key').like('%EDH - Unbundling%'))=='Regulated' else '100'
        return erwin_Unbundling
    
    def get_erwin_dso_type(self):
        erwin_dso_type=self.json_metadata.select(explode("extendedProperties").alias("x")).select("x.value").filter(col("x.key").like("%EDH DSO Filter Criteria%"))     
        return str(erwin_dso_type.collect()[0][0])
    
    def get_erwin_filter_criteria_dict(self):
        if self.payload_json["source_system"]!="romaniaglobe-sap":
            erwin_filter_criteria=self.json_metadata.select(explode("extendedProperties").alias("x"))\
                .select("x.value").filter(col("x.key").like("%Source Company Code%")) if self.erwin_dso_type=="Multi-DSO" else "No filter required"
            erwin_filter_criteria=erwin_filter_criteria.toPandas().values[0][0]
        
            erwin_filter_criteria_dict=dict(pair.lower().split(":") for pair in erwin_filter_criteria.split(";"))
            return erwin_filter_criteria_dict
    
    def get_tables_withFilters_df(self):
        #table level erwin
        exploded_erwin_dF = self.json_metadata.withColumn('tables_f',explode(col('tables'))).drop('tables')  #.select("t.tableDefinition")
        #erwin at column levels 
        exploded_erwin_tables_with_filter=exploded_erwin_dF.select("tables_f.columns",col("tables_f.tableDefinition").alias("tableDefinition"),"tables_f.extendedProperties").select(explode("columns").alias("x"),"tableDefinition","extendedProperties")
        exploded_erwin_tables_with_filter=exploded_erwin_tables_with_filter.select("tableDefinition","x.tableName",explode("extendedProperties").alias("ext")).select("tableDefinition","tableName","ext.value").filter(col("ext.key").like("%Table Company Codes%")).dropDuplicates()

        return exploded_erwin_tables_with_filter
    
    def get_tables_dict_erwin(self):
        tables_dict_erwin=self.exploded_erwin_tables_with_filter.select("tableName","value").toPandas().to_dict()
        ls_temp_1=[v.lower() for v in tables_dict_erwin["tableName"].values()]
        ls_temp_2=[v.lower() for v in tables_dict_erwin["value"].values()] 

        tables_dict_erwin=dict(zip(ls_temp_1, ls_temp_2))
        # resulting one-level dictionary
        return tables_dict_erwin
    



    def validate_schema_landing(self):
        landing_zone_path  = get_landing_path(self.payload_json, self.storage_account)
        source_system = get_source_system(self.payload_json)

        if fileExists(landing_zone_path[0]) or fileExists(landing_zone_path):
            landing_zone_table_df=get_lz_tables_df(landing_zone_path[0])
            tables = get_table_list(landing_zone_table_df, source_system)
            
            for tableInfo in self.query_json:
                if self.payload_json["source_system"]!="romaniaglobe-sap":
                    for table_path in tables:   #landing storage account
                        if table_path.lower().find(tableInfo['tablename'])>0 and tableInfo['query']>4:
                            columnNames=list(tableInfo['query'].replace("select",'').split("from")[0].replace('"','').split(","))

                            df_temp=spark.read.options(header=True).format('parquet').load(table_path)
                            columns_landing=[x.lower() for x in df_temp.columns]
                            difference=set(columns_landing)-(set(columnNames))
                            if len(difference)>0:
                                self.logger.error(f'schema has been changed: column mismathes: {difference} found in {tableInfo["tablename"]}')
                                self.messages.append(f'schema has been changed: column mismathes: {difference} found in {tableInfo["tablename"]}')
                            else:
                                self.logger.info(f'all columns found in {tableInfo["tablename"]}')
                        else:
                            self.logger.info(f'{tableInfo["tablename"]} not in landing storage account')
                else: 
                    for table_path in tables:   #landing storage account
                        if table_path.lower().find(tableInfo['tablename'])>0 and tableInfo['rfctablefields']!='':
                            columnNames=list(tableInfo['rfctablefields'].split(","))

                            df_temp=spark.read.options(header=True).format('parquet').load(table_path)
                            columns_landing=[x.lower() for x in df_temp.columns]
                            difference=set(columns_landing)-(set(columnNames))
                            if len(difference)>0:
                                self.logger.error(f'schema has been changed: column mismathes: {difference} found in {tableInfo["tablename"]}')
                                self.messages.append(f'schema has been changed: column mismathes: {difference} found in {tableInfo["tablename"]}')
                            else:
                                self.logger.info(f'all columns found in {tableInfo["tablename"]}')
                        else:
                            self.logger.info(f'{tableInfo["tablename"]} not in landing storage account')  
        else: 
            self.logger.info(f"Storage account is empty or path not found: {landing_zone_path}") 


    def validate_unbundling(self):
        if self.erwin_dso_type=="Multi-DSO":            
            #erwin at column levels 
            exploded_erwin_tables_with_MANDT=self.exploded_erwin_dF.select("tables_f.columns", "tables_f.tableDefinition").select(explode("columns").alias("x"),"tableDefinition")\
                    .select("tableDefinition","x.tableName","x.foreignKeyTableName").filter(col("x.foreignKeyTableName").contains("MANDT"))
            table_ls_with_MANDT=exploded_erwin_tables_with_MANDT.select("tableName").collect()
            table_ls_with_MANDT=[x['tableName'].lower() for x in table_ls_with_MANDT]

            tablesCount=0          
            mandtCount=0
            unbundlingCount=0
            tables_missing_mandt=[]
            tables_with_incorrect_unbundling=[]
            tables_without_query=[]
            for tableInfo in query_json:
                if self.payload_json["source_system"]!="romaniaglobe-sap":
                    if tableInfo['query']!='' and tableInfo['query'].find('where')>0:
                        if tableInfo['query'].split('where')[1].find('mandt') or tableInfo['query'].split('where')[1].find('rclnt'):
                            mandtCount=mandtCount+1
                        else:
                            tables_missing_mandt.append(tableInfo['tablename'])
                        if tableInfo['query'].split('where')[1].find(self.erwin_Unbundling):
                            unbundlingCount=unbundlingCount+1
                        else:
                            tables_with_incorrect_unbundling.append(tableInfo['tablename'])
                    else:
                        tables_without_query.append(tableInfo['tablename'])
                else:
                    if tableInfo['rfctablefields']!='':
                        if tableInfo['rfctablefields'].find('mandt') or tableInfo['rfctablefields'].find('rclnt'):
                            mandtCount=mandtCount+1
                        else:
                            tables_missing_mandt.append(tableInfo['tablename'])
                    else:
                        tables_without_query.append(tableInfo['tablename'])


            if len(tables_missing_mandt)>0:
                self.logger.error(f'{len(tables_missing_mandt)} tables are missing MANDT in the query')
                self.messages.append(f'{len(tables_missing_mandt)} tables are missing MANDT in the query')
            elif len(tables_with_incorrect_unbundling)>0:
                self.logger.error(f'{len(tables_with_incorrect_unbundling)} tables have incorrect Unbundling in the query')
                self.messages.append(f'{len(tables_with_incorrect_unbundling)} tables have incorrect Unbundling in the query')
            elif len(tables_without_query)>0:
                self.logger.error(f'{tables_without_query} has no query from the {len(query_json)} tables' if self.payload_json["source_system"]!="romaniaglobe-sap" else f'{tables_without_query} has no rfctablefields from the {len(query_json)}')
                self.messages.append(f'{tables_without_query} has no query from the {len(query_json)} tables')
            else:
                self.logger.info(f'{mandtCount} tables have MANDT in the query')

        else:
            self.info(f'{self.erwin_dso_type} unbundling check not applicable')



    def validate_filter_criteria(self):
        if self.erwin_dso_type=="Multi-DSO":
            filterCount=0
            valueCount=0
            tables_missing_filter=[]
            tables_with_incorrect_filterValue=[]
            tables_without_filter=[]

            for tableInfo in self.query_json:
                if self.payload_json["source_system"]!="romaniaglobe-sap" and tableInfo['query']!='':
                    if tableInfo["tablename"] in self.tables_dict_erwin.keys()  and tableInfo['query'].find('where')>0:  
                        if tableInfo['query'].split('where')[1].find(self.tables_dict_erwin[tableInfo["tablename"]]):
                            filterCount=filterCount+1
                        else:
                            tables_missing_filter.append(tableInfo['tablename'])
                            
                        if tableInfo['query'].split('where')[1].find(self.erwin_filter_criteria_dict[self.tables_dict_erwin[tableInfo["tablename"]]]):
                            valueCount=valueCount+1
                        else:
                            tables_with_incorrect_filterValue.append(tableInfo['tablename'])
                elif self.payload_json["source_system"]=="romaniaglobe-sap":
                    if tableInfo["tablename"] in self.tables_dict_erwin.keys() and tableInfo['rfctableoptions']!='':                         
                        tables_dict_erwin_value=self.tables_dict_erwin.get(tableInfo["tablename"]).replace("'","").strip()
                        table_rfctableOption=tableInfo['rfctableoptions'].replace("'","").strip()
                        similarity_ratio = SequenceMatcher(None, tables_dict_erwin_value, table_rfctableOption).ratio()  
                        if similarity_ratio>0.9:
                            filterCount=filterCount+1
                        else:
                            tables_with_incorrect_filterValue.append(tableInfo['tablename'])
                    else:
                        tables_missing_filter.append(tableInfo['tablename'])
                else:
                    tables_without_filter.append(tableInfo['tablename'])

            if len(tables_missing_filter)>0:
                logger.error(f'{len(tables_missing_filter)} tables are missing and {filterCount} tables has correct filter criteria in the query')
                self.messages.append(f'{len(tables_missing_filter)} tables are missing and {filterCount} tables has correct filter criteria in the query')

            elif len(tables_with_incorrect_filterValue)>0 and payload_json["source_system"]!="romaniaglobe-sap":
                logger.error(f'{len(tables_with_incorrect_filterValue)} tables have incorrect filter criteria in the query')
                self.messages.append(f'{len(tables_with_incorrect_filterValue)} tables have incorrect filter criteria in the query')
            else:
                self.logger.info(f'{filterCount} tables have correct filter and {len(tables_without_filter)} has no filter from the {len(query_json)} tables')
        else:
            self.info(f'{self.erwin_dso_type} filter criteria check not applicable')


    


    


# COMMAND ----------

schema_valdation=Schema_Validation(query_json,payload_json,storage_account,logger)


# COMMAND ----------

schema_valdation.validate_schema_landing()
schema_valdation.validate_filter_criteria()
schema_valdation.validate_unbundling()

# COMMAND ----------

schema_valdation.messages

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC --------------------------------------------------------------------------

# COMMAND ----------

#send back the result to ADF
dbutils.notebook.exit(schema_valdation.messages)
