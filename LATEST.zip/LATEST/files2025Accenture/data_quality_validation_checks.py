# Databricks notebook source
# MAGIC %pip install great_expectations

# COMMAND ----------

# DBTITLE 1,Import modules
from src.data_quality.dq_checks import DataQualityChecks
from src.utils.config_handler import *
from src.utils.erwin_json import *
from src.utils.enums.data_quality_types import DQTypes
from src.utils.logger import DBFSLogger, logging
from functools import reduce

# COMMAND ----------

# DBTITLE 1,Get parameters


scd_flag='N' == 'Y'

metadata_path = "abfss:///erwin-landing-path@stedheneuwdis.dfs.core.windows.net/run/Hungary EN - ISUJP3 - PROD_2025-02-03_04:14:48.json"  
net_type = "en"
env = "run"
business_unit = "2444"
layer = "cons"
tables_list = "abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/BUT021_FS.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/ADR3.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/BCONT.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/BUT020.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/V_EGPL.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/ESERVICE.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/FKKMAZE.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/FKKMAKO.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/DFKKBPTAXNUM.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/DFKKLOCKS.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/DM_MR_PHODT.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/ETTIFN.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/BUT000.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/FKKVKP.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/BUT050.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/ERCH.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/ADRSTREET.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/QMSM.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/CS_C_POSIT.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/VIQMFE.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EGERR.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/V_SOUDADCP.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/NSCALE_DOC.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/TRACK_SM.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EASTL.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EQUI.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/TBE_DFKKLOC.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/CS_FV_LOG.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EDISCOBJH.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/DM_SZNY_EXT.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/ETRG.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/DFKKOP.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/DM_027_HEAD.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EFORMULAINSTPMI.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/MD_SMART_VT.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EANL.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/JEST.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/FO_V_VID.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EVBS.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EDISCOBJ.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/V_EHAU.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/ERDK.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EASTS.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EEDMSETTLUNITT.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/ADR6.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/ELPASS.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/FO_VID_F.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EPROFASS.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/CS_STAT_BW.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/VIQMEL.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EUITRANS.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EEDMSETTLUNIT.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/ADRCT.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EVER.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/ADR2.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/ETDZ.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/TR_INAKTDB.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/NSCALE_PROC.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/DM_UK_SZEG.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EFORMULAINSTPMO.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EANLH.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EASTE.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EGERH.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/ADRC.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EDISCDOC.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EUIINSTLN.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EUFASS.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/ERCHC.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/ADRCITY.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EUIGRID.parquet","abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/03/EEDMUISETTLUNIT.parquet".split(',')
source_system = "isujp3"


# COMMAND ----------

# DBTITLE 1,Setting credentials on storage account
config_directory = "dbfs:/libraries/edh-en-edz-eam/src/generalized_pipeline/scripts"

dbfs_logger = DBFSLogger(log_level=logging.INFO)
logger = dbfs_logger.get_logger()

(scope, client_id, client_secret, tenant_id) =  get_platform_config(config_directory, net_type, env)
metadata_storage_account = get_metadata_storage_account(net_type)
(landing_storage_account,std_account_name,cons_account_name) = get_account_names(net_type,business_unit,env)
storage_accounts = [metadata_storage_account, landing_storage_account, cons_account_name, std_account_name]

for account in storage_accounts:
    set_credentials(scope, account, client_id, client_secret, tenant_id)
    
account_name = std_account_name if layer == "std" else cons_account_name

# COMMAND ----------

# setting credentials on erwin storage account
(scope, client_id, client_secret, tenant_id) =  get_platform_config(config_directory, net_type, env)
metadata_storage_account = get_metadata_storage_account(net_type)
set_credentials(scope,metadata_storage_account,client_id,client_secret,tenant_id)

# COMMAND ----------

display(erwin_df)

# COMMAND ----------

# DBTITLE 1,Read metadata file and get columns

def get_table_attributes(table_name):
    df_relevant_table = get_edh_relevant_table_info(erwin_df, table_name)

    all_columns_relevant = len([row["tableName"] for row in df_relevant_table.where("key=='all columns relevant for edh ?'and value ==1").select("tableName").collect()]) >0

    exploded_erwin_col_df_val,ID_list_all = get_exploded_erwin_col_df(erwin_col_df,'.'+table_name,str(all_columns_relevant))

    if exploded_erwin_col_df_val.count() == 0:
        exploded_erwin_col_df_val,ID_list_all = get_exploded_erwin_col_df(erwin_col_df,table_name,str(all_columns_relevant))

    return exploded_erwin_col_df_val


json_metadata=read_json_df(metadata_path)
erwin_df = exploded_erwin_df(json_metadata)
erwin_col_df = exploded_erwin_col_df(erwin_df)

# COMMAND ----------

display(erwin_col_df)

# COMMAND ----------

# DBTITLE 1,GET paths and dfs
def get_table_input_path(table_landing_path, layer, table_name, std_account_name, source_system):
    if layer == "std":
        return table_landing_path
    else:
        return f"abfss://edh@{std_account_name}.dfs.core.windows.net/{source_system}/{table_name}"

def get_output_path(account_name, table_name, source_system):
    if layer == "std":
        return get_standard_path(account_name, source_system, table_name, scd_flag)
    else:
        return get_cons_path(source_system, account_name, table_name, scd_flag)

def get_input_table(input_table_path, layer):
    if layer == "std":
        return spark.read.parquet(input_table_path)
    else:
        return spark.read.format("delta").load(input_table_path)

def get_output_table(output_table_path):
    return spark.read.format("delta").load(output_table_path)

# COMMAND ----------

# DBTITLE 1,Define checks
def perform_check(check, logger):
    try:
        dq = DataQualityChecks(check["table"], check["table_name"], check["check_def"], logger)
        return dq.validate()
    except Exception as e:
        return f"Error performing data quality checks on {check['table_name']}: {str(e)}"


def add_checks(table_name, output_table, input_table, not_nullable_columns):
    pk_load=dbutils.jobs.taskValues.get(taskKey = "json_parser",  key= f"{table_name}_ID_list_load")
    (pk_columns,load_type) = (pk_load[0],pk_load[1])
    check_type = []
    if load_type != "delta_load":
        check_type.append({"dq_type": DQTypes.ROW_COUNT.value, "columns": None, "df_to_compare": input_table})
    if len(pk_columns) > 0:
        check_type.append({"dq_type": DQTypes.UNIQUE.value, "columns": pk_columns, "df_to_compare": None})
    if len(not_nullable_columns) > 0:
        check_type.append({"dq_type": DQTypes.NOT_NULL.value, "columns": not_nullable_columns, "df_to_compare": None})

    return {"table": output_table, "table_name":table_name, "check_def": check_type}

def get_table_attributes(table_name):
    # display(erwin_df)
    df_relevant_table = get_edh_relevant_table_info(erwin_df, table_name)
    
    all_columns_relevant = len([row["tableName"] for row in df_relevant_table.where("key=='all columns relevant for edh ?'and value ==1").select("tableName").collect()]) >0
    
    exploded_erwin_col_df_val,ID_list_all = get_exploded_erwin_col_df(erwin_col_df,'.'+table_name,str(all_columns_relevant))

    if exploded_erwin_col_df_val.count() == 0:
        exploded_erwin_col_df_val,ID_list_all = get_exploded_erwin_col_df(erwin_col_df,table_name,str(all_columns_relevant))

    return exploded_erwin_col_df_val

def validate_table(table_path, layer, std_account_name, source_system, account_name, logger):
        try:
            checks = []
            
            table_name = get_table_name(table_path)
            input_table_path = get_table_input_path(table_path, layer, table_name, std_account_name, source_system)
            input_table = get_input_table(input_table_path, layer)
            
            output_table_path = get_output_path(account_name, table_name, source_system)
            output_table = get_output_table(output_table_path)
            
            table_attributes_df = get_table_attributes(table_name)
            # display(table_attributes_df)
            # not_nullable_columns = filter_columns(table_attributes_df, "columnNullableFlag==False")
            # pii_columns = filter_columns(table_attributes_df, "sdiflag==True")
            # not_null_cols_non_pii = [col for col in not_nullable_columns if col not in pii_columns]
            # checks = add_checks(table_name, output_table, input_table, not_null_cols_non_pii)
            # errors.extend(perform_check(checks, logger))
        except Exception as e:
            logger.error(f"Error validating table {table_name}: {str(e)}")


# COMMAND ----------

# DBTITLE 1,Perform data_quality_checks
errors = []

errors.extend(filter(None, reduce(lambda acc, table: acc + [validate_table(table, layer, std_account_name, source_system, account_name, logger)], tables_list, [])))

# if len(errors) > 0:
#     raise Exception(f"Data Quality failed. The following checks failed: {errors}")
# else:
#     logger.info(f"Data Quality tests passed for {layer} layer.")


# COMMAND ----------


=======
   
>>>>>>> Stashed changes