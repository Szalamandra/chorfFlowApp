# Databricks notebook source
# MAGIC %pip install adal

# COMMAND ----------

import os
import requests
import json
import sys

from src.utils.config_handler import *

from src.utils.cluster_config import *

from src.utils.logger import DBFSLogger, logging
from src.utils.job_dispatcher import  *
from typing import Generator, Dict, Any
from src.utils.erwin_json import *

# COMMAND ----------

current_directory=os.getcwd()
if current_directory=="/databricks/driver":
    current_directory="/Workspace/Repos/release/edh-en-edz-eam/src/generalized_pipeline/scripts"
config_directory="dbfs:/libraries/edh-en-edz-eam/src/generalized_pipeline/scripts"
script_current_directory=current_directory.replace("/Workspace","")
# data_type_path=f"file:{current_directory}/config_files/s4u_data_type.json"
ws_url=spark.conf.get("spark.databricks.workspaceUrl")

# COMMAND ----------

# Get Configuration Variables
config_df =get_config_df(config_directory)
(env, net_type, token) = get_config_values(config_df,ws_url)
storage_account = get_storage_account(net_type,env)


# COMMAND ----------

#setup erwin json storage account credentials

# json_metadata_path=payload_json["erwin_json_file"]
# erwin_storage_account = json_metadata_path[2].split(".")[0]
# (scope, client_id, client_secret, tenant_id) =  get_platform_config(config_directory, net_type, env)
# set_credentials(scope,erwin_storage_account,client_id,client_secret,tenant_id)

# COMMAND ----------

# Setting Credentials using Platform Values
(scope, client_id, client_secret, tenant_id) =  get_platform_config(config_directory, net_type, env)
set_credentials(scope,storage_account,client_id,client_secret,tenant_id)

# COMMAND ----------


# # Getting Payload json from ADF
# dbutils.widgets.text("payload_json", "","") 
# dbutils.widgets.text("query_json", "","") 

# payload_json = dbutils.widgets.get("payload_json")

# query_json=dbutils.widgets.get("query_json") 

# payload_json=json.loads(payload_json) 
# query_json=json.loads(query_json) 

# COMMAND ----------

payload_json ={'table_path': 'ecount-oracle/miz/2024/12/19', 'source_system': 'ecount-oracle', 'business_unit': 'miz', 'erwin_json_file': 'https://stedheneuwdis.blob.core.windows.net/test-container-in/testreka/DE EnviaM - eCount - QA_2024-09-24_015330.json'}   

#su4 wez
payload_json ={"table_path":"s4u-sap/wez/2025/01/07","source_system":"s4u-sap","business_unit":"wez","erwin_json_file":"https://stedheneuwdis.blob.core.windows.net/test-container-in/testreka/DE Westnetz - S4U - DEV_2024-08-26_103730.json"}

# COMMAND ----------

query_json=[{'tablename': 'v_linienwerte_json_gp_eonk', 'query': 'select "zpt_id","met_code","name","web_bezeichnung","anschlussleistung","von","bis","wandlerfaktor","web_mitteilung","bemerkung","na_id","vtp_id_vnb","vtp_id_mandant","rzpa_id","rmea_id","stand","hoehe","geu_id","ec_row_id","rabrz_id","rspe_id_messung","anschlussleistung_eins","adr_id","rspe_id_entnahme","rzptb_id","id_num","linie","bezeichnung","web_lbezeichnung","rzwt_id","rdqt_id","rper_id","zrd_id","kunde_relevant","haendler_relevant","rper_id_dq","rlit_id","rkmg_id","kanal_nummer","rld_id","zfa_relevant","linie_norm","plausi","rzz_id_anzeige","plausi_offset_tage","werte_von","werte_bis","zrdaten" from "ec_eonk"."v_linienwerte_json_gp_eonk"'}, {'tablename': 'v_linienwerte_json_sp_eonk', 'query': 'select "zpt_id","met_code","name","web_bezeichnung","anschlussleistung","von","bis","wandlerfaktor","web_mitteilung","bemerkung","na_id","vtp_id_vnb","vtp_id_mandant","rzpa_id","rmea_id","stand","hoehe","geu_id","ec_row_id","rabrz_id","rspe_id_messung","anschlussleistung_eins","adr_id","rspe_id_entnahme","rzptb_id","id_num","linie","bezeichnung","web_lbezeichnung","rzwt_id","rdqt_id","rper_id","zrd_id","kunde_relevant","haendler_relevant","rper_id_dq","rlit_id","rkmg_id","kanal_nummer","rld_id","zfa_relevant","linie_norm","plausi","rzz_id_anzeige","plausi_offset_tage","werte_von","werte_bis","zrdaten" from "ec_eonk"."v_linienwerte_json_sp_eonk"'}, {'tablename': 'zrv_copy_on_write_event', 'query': 'select "id","aenderungsnummer","zrd_id","start_processing","finish_processing","zr_werte_json","start_zrv_processing","anz_val","db_audsid","comroll_j_n","split_nummer" from "ec_zrv"."zrv_copy_on_write_event"'}]

null=''

#s4u wez
query_json=[{"tablename":"/eon/dlca_v_jest","query":"select mandt,_dataaging,chgnr,inact,objnr,stat from sapabap1./eon/dlcasqjest where mandt = '200'"},{"tablename":"/eon/dlca_v_tj02t","query":"select istat,spras,txt04,txt30 from sapabap1./eon/dlcasqtj02t"},{"tablename":"/eon/dlca_v_tj30","query":"select mandt,stsma,estat,inist,stonr,hsonr,nsonr,linep,statp,bersl,crm_vrgng from sapabap1./eon/dlcasqtj30 where mandt = '200'"},{"tablename":"/eon/dlca_v_tj30t","query":"select mandt,stsma,estat,spras,txt04,txt30,ltext from sapabap1./eon/dlcasqtj30t where mandt = '200'"},{"tablename":"/eon/dlco_v_acdoca","query":null},{"tablename":"/eon/dlco_v_acdocp","query":"select rclnt,reqtsn,datapakid,record,ryear,rldnr,racct,rbukrs,awtyp,usnam,category,kprice,hprice,wprice,rmvct,bttype,aworg,awref,rwcur,rhcur,rkcur,rocur,rvcur,rbcur,rccur,rdcur,recur,rfcur,rgcur,rco_ocur,rvunit,rcntr,prctr,rfarea,rbusa,kokrs,segment,scntr,pprctr,sfarea,sbusa,rassc,psegment,wsl,hsl,ksl,osl,vsl,bsl,csl,dsl,esl,fsl,gsl,vmsl,kfsl,co_osl,poper,budat,periv,fiscyearper,ktopl,slalittype,kdauf,kdpos,matnr,werks,kunnr,sgtxt,co_belkz,ps_posid,ps_pspid,pernr,pbukrs,uprctr,accasty,lstar,aufnr,rsrce,paufnr,paccasty,plstar,pps_posid,pps_pspid,work_item_id,bemot,psknz,losgr,lsunit,ps_psp_pnr,ps_prj_pnr,pps_psp_pnr,pps_prj_pnr,acdoc_eew_dummy,dummy_incl_eew_cobl,fkart,vkorg,vtweg,spart,matnr_copa,matkl,kdgrp,land1,brsch,bzirk,kunre,kunwe,konzs,acdoc_copa_eew_dummy_pa,ww002_pa,ww011_pa,ww012_pa,ww013_pa,ww014_pa,ww015_pa,ww016_pa,ww017_pa,auart_pa,pstyv_pa,vkbur_pa,ww030_pa,ww031_pa,ww032_pa,ww033_pa,ww034_pa,ww103_pa,ww104_pa,ww105_pa,ww106_pa,ww100_pa,ww101_pa,ww102_pa,ww107_pa,ww108_pa,ww109_pa,ww110_pa,ww111_pa,ww112_pa,ww113_pa,ww114_pa,ww115_pa,ww116_pa,dummy_mrkt_sgmnt_eew_ps,fikrs,rfund,rgrant_nbr,rbudget_pd,budget_process,budget_subcategory,arbid,vornr,aufps,uvorn,equnr,tplnr,istru,ilart,plknz,artpr,priok,maufnr,matkl_mm,paufps,rsnum,rspos,rsart,packno,introw,afabe,anln1,anln2,movcat,anlkl,vname,egrup,recid,prodper,swenr,sgenr,sgrnr,smenr,recnnr,snksl,sempsl,dabrz from sapabap1./eon/dlcosqacdcp where kokrs = '102n' and rclnt = '200'"},{"tablename":"/eon/dlco_v_aufk","query":"select mandt,aufnr,auart,autyp,refnr,ernam,erdat,aenam,aedat,ktext,ltext,bukrs,werks,gsber,kokrs,cckey,kostv,stort,sowrk,astkz,waers,astnr,stdat,estnr,phas0,phas1,phas2,phas3,pdat1,pdat2,pdat3,idat1,idat2,idat3,objid,vogrp,loekz,plgkz,kvewe,kappl,kalsm,zschl,abkrs,kstar,kostl,saknr,setnm,cycle,sdate,seqnr,user0,user1,user2,user3,user4,user5,user6,user7,user8,user9,objnr,prctr,pspel,awsls,abgsl,eb_post,txjcd,func_area,scope,plint,kdauf,kdpos,aufex,ivpro,logsystem,flg_mltps,abukr,akstl,sizecl,izwek,umwkz,kstempf,zschm,pkosa,anfaufnr,procnr,proty,rsord,bemot,adrnra,erfzeit,aezeit,cstg_vrnt,costestnr,veraa_user,zzatl,zzasn,z_oty,zqmnum,zcsaufnr,zcswert,zcsjahr,/eon/inbdt,zzrcv_bukrs,zzrcv_acasty,zzrcv_accass,zzaction_id,zzcustomer,zzaccountsys,zzbukrs,zzswenr,zzsgenr,zzsnksl,zzsempsl,zzdabrz,zzpspel,zzhkont,zzebeln,zzebelp,zz_reason,eew_aufk_ps_dummy,vname,recid,etype,otype,jv_jibcl,jv_jibsa,jv_oco,cpd_updat,/cum/indcu,/cum/cmnum,/cum/auest,/cum/desnum,/mrss/pl_stru_id,/mrss/pl_man_typ,/mrss/order_prob,/mrss/act_type,/mrss/init_done,/mrss/datachange,/mrss/sales_org,/mrss/nw_booked,ad01profnr,vaplz,wawrk,ferc_ind,aufk_status,claim_control,update_needed,update_control from sapabap1./eon/dlcosqaufk where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlco_v_cobk","query":"select mandt,kokrs,belnr,gjahr,versn,vrgng,timestmp,perab,perbi,bldat,budat,cpudt,usnam,bltxt,stflg,stokz,refbt,refbn,refbk,refgj,blart,ldgrp,orgvg,sumbz,delbz,wsdat,kurst,varnr,kwaer,ctyp1,ctyp2,ctyp3,ctyp4,awtyp,aworg,logsystem,cputm,alebz,alebn,awsys,awref_rev,aworg_rev,awkey,valdt,kokrs_sender,belnr_sender,logsystem_sender,reprocessing_status_code from sapabap1./eon/dlcosqcobk where kokrs = '102n' and mandt = '200'"},{"tablename":"/eon/dlco_v_coej","query":"select mandt,kokrs,belnr,buzei,perbl,wtg001,wtg002,wtg003,wtg004,wtg005,wtg006,wtg007,wtg008,wtg009,wtg010,wtg011,wtg012,wtg013,wtg014,wtg015,wtg016,wog001,wog002,wog003,wog004,wog005,wog006,wog007,wog008,wog009,wog010,wog011,wog012,wog013,wog014,wog015,wog016,wkg001,wkg002,wkg003,wkg004,wkg005,wkg006,wkg007,wkg008,wkg009,wkg010,wkg011,wkg012,wkg013,wkg014,wkg015,wkg016,wkf001,wkf002,wkf003,wkf004,wkf005,wkf006,wkf007,wkf008,wkf009,wkf010,wkf011,wkf012,wkf013,wkf014,wkf015,wkf016,pag001,pag002,pag003,pag004,pag005,pag006,pag007,pag008,pag009,pag010,pag011,pag012,pag013,pag014,pag015,pag016,paf001,paf002,paf003,paf004,paf005,paf006,paf007,paf008,paf009,paf010,paf011,paf012,paf013,paf014,paf015,paf016,meg001,meg002,meg003,meg004,meg005,meg006,meg007,meg008,meg009,meg010,meg011,meg012,meg013,meg014,meg015,meg016,mef001,mef002,mef003,mef004,mef005,mef006,mef007,mef008,mef009,mef010,mef011,mef012,mef013,mef014,mef015,mef016,mbg001,mbg002,mbg003,mbg004,mbg005,mbg006,mbg007,mbg008,mbg009,mbg010,mbg011,mbg012,mbg013,mbg014,mbg015,mbg016,mbf001,mbf002,mbf003,mbf004,mbf005,mbf006,mbf007,mbf008,mbf009,mbf010,mbf011,mbf012,mbf013,mbf014,mbf015,mbf016,lednr,objnr,gjahr,wrttp,versn,kstar,hrkft,vrgng,parob,parob1,uspob,vbund,pargb,beknz,twaer,meinh,meinb,sgtxt,refbz,zlenr,bw_refbz,beltp,timestmp,paobjnr,fkber,pfkber,geber,pgeber,grant_nbr,pgrant_nbr,segment,psegment,budget_pd,pbudget_pd from sapabap1./eon/dlcosqcoej where kokrs = '102n' and mandt = '200'"},{"tablename":"/eon/dlco_v_coep","query":"select mandt,kokrs,belnr,buzei,perio,wtgbtr,wogbtr,wkgbtr,wkfbtr,pagbtr,pafbtr,megbtr,mefbtr,mbgbtr,mbfbtr,lednr,objnr,gjahr,wrttp,versn,kstar,hrkft,vrgng,parob,parob1,uspob,vbund,pargb,beknz,twaer,owaer,meinh,meinb,mvflg,sgtxt,refbz,zlenr,bw_refbz,gkont,gkoar,werks,matnr,rbest,ebeln,ebelp,zekkn,erlkz,pernr,btrkl,objnr_n1,objnr_n2,objnr_n3,paobjnr,beltp,bukrs,gsber,fkber,scope,logsyso,pkstar,pbukrs,pfkber,pscope,logsysp,dabrz,bwstrat,objnr_hk,timestmp,qmnum,geber,pgeber,grant_nbr,pgrant_nbr,refbz_fi,segment,psegment,posnr,prctr,pprct,budget_pd,pbudget_pd,prodper,awtyp,awkey,awsys,kwaer,accas,accasty,kostl,lstar,aufnr,autyp,pspnr,pspid,vbeln,vbposnr,ce4key,erkrs,paccas,paccasty,pkostl,plstar,paufnr,pautyp,ppspnr,ppspid,pvbeln,pvbposnr,pce4key,quant1,quant2,quant3,qunit1,qunit2,qunit3 from sapabap1./eon/dlcosqcoep where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlco_v_cooi","query":"select mandt,refbt,refbn,rfpos,rfknt,rftrm,rfart,lifnr,lednr,objnr,hrkft,rforg,rftyp,rfsys,vrgng,gjahr,wrttp,versn,sakto,vbund,pargb,beknz,twaer,uname,bldat,budat,perio,bukrs,kokrs,matnr,matkl,sgtxt,gesmng,meinh,megbtr,mbgbtr,meinb,wkurs,orgwth,whgbtr,orgwtk,wkgbtr,orgwtt,wtgbtr,orgwto,wogbtr,orgwtl,wlgbtr,loekz,dabrz,timestmp from sapabap1./eon/dlcosqcooi where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlco_v_cosp","query":"select mandt,lednr,objnr,gjahr,wrttp,versn,kstar,hrkft,vrgng,vbund,pargb,beknz,twaer,perbl,meinh,wtg001,wtg002,wtg003,wtg004,wtg005,wtg006,wtg007,wtg008,wtg009,wtg010,wtg011,wtg012,wtg013,wtg014,wtg015,wtg016,wog001,wog002,wog003,wog004,wog005,wog006,wog007,wog008,wog009,wog010,wog011,wog012,wog013,wog014,wog015,wog016,wkg001,wkg002,wkg003,wkg004,wkg005,wkg006,wkg007,wkg008,wkg009,wkg010,wkg011,wkg012,wkg013,wkg014,wkg015,wkg016,wkf001,wkf002,wkf003,wkf004,wkf005,wkf006,wkf007,wkf008,wkf009,wkf010,wkf011,wkf012,wkf013,wkf014,wkf015,wkf016,pag001,pag002,pag003,pag004,pag005,pag006,pag007,pag008,pag009,pag010,pag011,pag012,pag013,pag014,pag015,pag016,meg001,meg002,meg003,meg004,meg005,meg006,meg007,meg008,meg009,meg010,meg011,meg012,meg013,meg014,meg015,meg016,mef001,mef002,mef003,mef004,mef005,mef006,mef007,mef008,mef009,mef010,mef011,mef012,mef013,mef014,mef015,mef016,muv001,muv002,muv003,muv004,muv005,muv006,muv007,muv008,muv009,muv010,muv011,muv012,muv013,muv014,muv015,muv016,beltp,timestmp,bukrs,fkber,segment,geber,grant_nbr,budget_pd from sapabap1./eon/dlcosqcosp where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlco_v_coss","query":"select mandt,lednr,objnr,gjahr,wrttp,versn,kstar,hrkft,vrgng,parob,uspob,beknz,twaer,perbl,meinh,wtg001,wtg002,wtg003,wtg004,wtg005,wtg006,wtg007,wtg008,wtg009,wtg010,wtg011,wtg012,wtg013,wtg014,wtg015,wtg016,wog001,wog002,wog003,wog004,wog005,wog006,wog007,wog008,wog009,wog010,wog011,wog012,wog013,wog014,wog015,wog016,wkg001,wkg002,wkg003,wkg004,wkg005,wkg006,wkg007,wkg008,wkg009,wkg010,wkg011,wkg012,wkg013,wkg014,wkg015,wkg016,wkf001,wkf002,wkf003,wkf004,wkf005,wkf006,wkf007,wkf008,wkf009,wkf010,wkf011,wkf012,wkf013,wkf014,wkf015,wkf016,pag001,pag002,pag003,pag004,pag005,pag006,pag007,pag008,pag009,pag010,pag011,pag012,pag013,pag014,pag015,pag016,paf001,paf002,paf003,paf004,paf005,paf006,paf007,paf008,paf009,paf010,paf011,paf012,paf013,paf014,paf015,paf016,meg001,meg002,meg003,meg004,meg005,meg006,meg007,meg008,meg009,meg010,meg011,meg012,meg013,meg014,meg015,meg016,mef001,mef002,mef003,mef004,mef005,mef006,mef007,mef008,mef009,mef010,mef011,mef012,mef013,mef014,mef015,mef016,muv001,muv002,muv003,muv004,muv005,muv006,muv007,muv008,muv009,muv010,muv011,muv012,muv013,muv014,muv015,muv016,beltp,timestmp,bukrs,fkber,segment,geber,grant_nbr,budget_pd from sapabap1./eon/dlcosqcoss where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlco_v_covp","query":"select mandt,kokrs,belnr,buzei,perio,wtgbtr,wogbtr,wkgbtr,wkfbtr,pagbtr,pafbtr,megbtr,mefbtr,mbgbtr,mbfbtr,lednr,objnr,gjahr,wrttp,versn,kstar,hrkft,vrgng,parob,parob1,uspob,vbund,pargb,beknz,twaer,owaer,meinh,meinb,mvflg,sgtxt,refbz,zlenr,bw_refbz,gkont,gkoar,werks,matnr,rbest,ebeln,ebelp,zekkn,erlkz,pernr,btrkl,objnr_n1,objnr_n2,objnr_n3,paobjnr,beltp,bukrs,gsber,fkber,scope,logsyso,pkstar,pbukrs,pfkber,pscope,logsysp,dabrz,bwstrat,objnr_hk,timestmp,qmnum,geber,pgeber,grant_nbr,pgrant_nbr,refbz_fi,segment,psegment,prctr,pprct,budget_pd,pbudget_pd,prodper,perab,perbi,bldat,budat,cpudt,usnam,bltxt,stflg,stokz,refbt,refbn,refbk,refgj,blart,ldgrp,orgvg,sumbz,delbz,wsdat,kurst,varnr,kwaer,ctyp1,ctyp2,ctyp3,ctyp4,awtyp,aworg,logsystem,cputm,alebz,alebn,awsys,awref_rev,aworg_rev,awkey,valdt,kokrs_sender,belnr_sender,logsystem_sender,reprocessing_status_code,k_gjahr,k_versn,k_vrgng,k_timestmp,p_awtyp,p_awkey,p_awsys,p_kwaer,accas,accasty,kostl,lstar,aufnr,autyp,pspnr,vbeln,vbposnr,ce4key,erkrs,paccas,paccasty,pkostl,paufnr,pautyp,ppspnr,pce4key,plstar,pvbeln,pvbposnr,p_posnr,pspid,ppspid,quant1,quant2,quant3,qunit1,qunit2,qunit3 from sapabap1./eon/dlcosqcovp where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlco_v_cska_1","query":"select mandt,ktopl,kstar,ersda,usnam,stekz,zahkz,kstsn,func_area from sapabap1./eon/dlcosqcska where ktopl = 'ecoa' and mandt = '200'"},{"tablename":"/eon/dlco_v_cskb","query":"select mandt,aufnr,datab,datbi,deakt,eigen,ersda,katyp,kokrs,kostl,kstar,last_changed_ts,loevm,mgefl,msehi,plaor,plaus,plazu,recid,usnam from sapabap1./eon/dlcosqcskb where kokrs = '102n' and mandt = '200'"},{"tablename":"/eon/dlco_v_csks","query":"select mandt,abtei,afunk,anred,avc_active,avc_profile,bkzer,bkzkp,bkzks,bkzob,budget_carrying_cost_ctr,bukrs,cckey,cpd_templ,cpi_templ,datab,datbi,datlt,drnam,eew_csks_ps_dummy,ersda,etype,ferc_ind,func_area,func_area_fix_assigned,fund,fund_fix_assigned,funkt,grant_fix_assigned,grant_id,gsber,jv_jibcl,jv_jibsa,jv_otype,kalsm,kappl,khinr,kokrs,kompl,kosar,kostl,koszschl,kvewe,land1,logsystem,mgefl,name1,name2,name3,name4,nkost,objnr,ort01,ort02,pfach,pkzer,pkzkp,pkzks,prctr,pstl2,pstlz,recid,regio,scd_templ,sci_templ,skd_templ,ski_templ,spras,stakz,stras,telbx,telf1,telf2,telfx,teltx,telx1,txjcd,usnam,verak,verak_user,vmeth,vname,waers,werks,zzctx,zzenv,zzesg,zzgf1,zzgf2,zzgrl,zzins,zzisg,zzitu,zzli1,zzli2,zzmai,zzmks,zzorg,zzplt,zzprj,zzpro,zzreg,zzres,zzslr,zzunb from sapabap1./eon/dlcosqcsks where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlco_v_cskt","query":"select mandt,datbi,kokrs,kostl,ktext,ltext,mctxt,spras from sapabap1./eon/dlcosqcskt where kokrs = '102n' and mandt = '200'"},{"tablename":"/eon/dlco_v_csku","query":"select mandt,kstar,ktext,ktopl,ltext,mctxt,spras from sapabap1./eon/dlcosqcsku where ktopl = 'ecoa' and mandt = '200'"},{"tablename":"/eon/dlco_v_csla","query":"select mandt,auseh,ausfk,datab,datbi,ersda,fixvo,hrkft,kokrs,kstty,lark1,lark2,latyp,latypi,leinh,lstar,manist,manplan,sprkz,tarkz,tarkz_i,usnam,vksta,yrate from sapabap1./eon/dlcosqcsla where kokrs = '102n' and mandt = '200'"},{"tablename":"/eon/dlco_v_cslt","query":"select mandt,datbi,kokrs,ktext,lstar,ltext,mctxt,spras from sapabap1./eon/dlcosqcslt where kokrs = '102n' and mandt = '200'"},{"tablename":"/eon/dlco_v_cssl","query":"select mandt,kokrs,kostl,lstar,gjahr,cckey,latyp,leinh,ausfk,auseh,objnr,latypi from sapabap1./eon/dlcosqcssl where kokrs = '102n' and mandt = '200'"},{"tablename":"/eon/dlco_v_prhi","query":"select mandt,posnr,psphi,up,down from sapabap1./eon/dlcosqprhi where mandt = '200'"},{"tablename":"/eon/dlco_v_proj","query":"select mandt,pspnr,pspid,post1,objnr,ernam,erdat,aenam,aedat,kimsk,autod,stspd,stspr,vernr,verna,astnr,astna,vbukr,vgsbr,vkokr,prctr,pwhie,zuord,trmeq,plfaz,plsez,werks,kalid,vgplf,ewplf,zteht,nzanz,plnaw,vprof,profl,bprof,txtsp,kostl,ktrg,aedte,aedtp,berst,bertr,berko,berbu,spsnr,besta,scope,xstat,txjcd,zschm,scprf,imprf,fmprf,abgsl,postu,pprof,plint,loevm,inact,kzbws,smprf,flgvrg,grtop,pgprf,stort,logsystem,kzerb,pargr,func_area,vkorg,vtweg,spart,dppprof,vpkstu,pspid_edit,vname,recid,etype,otype,jibcl,jibsa,eew_proj_ps_dummy,schtyp,sprog,eprog,slwid,usr00,usr01,usr02,usr03,usr04,use04,usr05,use05,usr06,use06,usr07,use07,usr08,usr09,usr10,usr11,cpd_updat,ferc_ind,avc_profile,avc_active,cpcurr,proj_status from sapabap1./eon/dlcosqproj where vbukr = '2200' and mandt = '200'"},{"tablename":"/eon/dlco_v_prps","query":"select mandt,abgsl,abukr,adpsp,aedat,aenam,aennr,akokr,akstl,astna,astnr,belkz,berbu,berko,berst,bertr,cgpl_guid16,cgpl_logsys,cgpl_objtype,clasf,cpd_updat,eew_prps_ps_dummy,equnr,erdat,ernam,etype,evgew,fabkl,fakkz,ferc_ind,fkokr,fkstl,fplnr,func_area,func_area_fix_assigned,fund_fix_assign,grant_fix_assigned,grpkz,imprf,isize,iumkz,izwek,jibcl,jibsa,kalnr,kalsm,kappl,klvar,kostl,ktrg,kvewe,kzbws,loevm,logsystem,matnr,npfaz,objnr,otype,pbukr,pgprf,pgsbr,pkokr,plakz,plint,posid,posid_edit,poski,posnr_prps,post1,postu,prart,prctr,prps_status,psphi,pspkz,pspnr,pspnr_logs,pspri,pwpos,recid,rfippnt,rfund,rgrant_nbr,scope,slwid,sort1,sort2,sort3,sponsoredprog,spsnr,stort,stufe,subpr,tadat,tplnr,trmeq,txjcd,txtsp,use04,use05,use06,use07,usr00,usr01,usr02,usr03,usr04,usr05,usr06,usr07,usr08,usr09,usr10,usr11,vbeln_prps,verna,vernr,vlpkz,vlpsp,vname,werks,xstat,zschl,zschm,zuord,zzacl,zzasn,zzatl,zzcpx,zzctx,zzenv,zzesg,zzgf1,zzgf2,zzgrl,zzins,zzisg,zzitu,zzli1,zzli2,zzmai,zzmks,zzorg,zzplg,zzplt,zzprj,zzpro,zzprv,zzreg,zzres,zzslr,zzstl,zzunb from sapabap1./eon/dlcosqprps where pbukr = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_bkpf","query":"select mandt,bukrs,belnr,gjahr,blart,bldat,budat,monat,cpudt,cputm,aedat,upddt,wwert,usnam,tcode,bvorg,xblnr,dbblg,dbblg_gjahr,dbblg_bukrs,stblg,stjah,bktxt,waers,kursf,kzwrs,kzkrs,bstat,xnetb,frath,xrueb,glvor,grpid,dokid,arcid,iblar,awtyp,awkey,fikrs,hwaer,hwae2,hwae3,kurs2,kurs3,basw2,basw3,umrd2,umrd3,xstov,stodt,xmwst,curt2,curt3,kuty2,kuty3,xsnet,ausbk,xusvr,duefl,awsys,txkrs,ctxkrs,lotkz,xwvof,stgrd,ppnam,ppdat,pptme,pptcod,brnch,numpg,adisc,xref1_hd,xref2_hd,xreversal,reindat,rldnr,ldgrp,propmano,xblnr_alt,vatdate,fulfilldate,doccat,xsplit,cash_alloc,follow_on,xreorg,subset,kurst,kursx,kur2x,kur3x,xmca,resubmission,logsystem_sender,bukrs_sender,belnr_sender,gjahr_sender,intsubid,aworg_rev,awref_rev,xreversing,xreversed,glbtgrp,co_vrgng,co_refbt,co_alebn,co_valdt,co_belnr_sender,kokrs_sender,acc_principle,_dataaging,trava_pn,ldgrpspec_pn,afabespec_pn,xsecondary,reprocessing_status_code,trr_partial_ind,item_removal_status,penrc,glo_ref1_hd,glo_dat1_hd,glo_ref2_hd,glo_dat2_hd,glo_ref3_hd,glo_dat3_hd,glo_ref4_hd,glo_dat4_hd,glo_ref5_hd,glo_dat5_hd,glo_bp1_hd,glo_bp2_hd,ev_postng_ctrl,anxtype,anxamnt,anxperc,zvat_indc,/sapf15/status,psoty,psoak,psoks,psosg,psofn,intform,intdate,psobt,psozl,psodt,psotm,fm_umart,ccins,ccnum,ssblk,batch,sname,sampled,exclude_flag,blind,offset_status,offset_refer_dat,knumv,blo,cnt,pybastyp,pybasno,pybasdat,pyiban,inwarddt_hd from sapabap1./eon/dlfisqbkpf where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_bsad","query":"select mandt,bukrs,kunnr,umsks,umskz,augdt,augbl,zuonr,gjahr,belnr,buzei,budat,bldat,cpudt,waers,xblnr,blart,monat,bschl,zumsk,shkzg,gsber,tax_country,mwskz,dmbtr,wrbtr,mwsts,wmwst,lwsts,bdiff,bdif2,sgtxt,projn,aufnr,anln1,anln2,saknr,hkont,fkont,filkd,zfbdt,zterm,zbd1t,zbd2t,zbd3t,zbd1p,zbd2p,skfbt,sknto,wskto,zlsch,zlspr,zbfix,hbkid,bvtyp,rebzg,rebzj,rebzz,samnr,anfbn,anfbj,anfbu,anfae,mansp,mschl,madat,manst,maber,xnetb,xanet,xcpdd,xinve,xzahl,mwsk1,tax_country1,dmbt1,wrbt1,mwsk2,tax_country2,dmbt2,wrbt2,mwsk3,tax_country3,dmbt3,wrbt3,bstat,vbund,vbeln,rebzt,infae,stceg,egbld,eglld,rstgr,xnoza,vertt,vertn,vbewa,wverw,projk,fipos,nplnr,aufpl,aplzl,xegdr,dmbe2,dmbe3,dmb21,dmb22,dmb23,dmb31,dmb32,dmb33,bdif3,xragl,uzawe,xstov,mwst2,mwst3,sknt2,sknt3,xref1,xref2,xarch,pswsl,pswbt,lzbkz,landl,imkey,vbel2,vpos2,posn2,eten2,fistl,geber,dabrz,xnegp,kostl,rfzei,kkber,empfb,prctr,xref3,qsskz,zinkz,dtws1,dtws2,dtws3,dtws4,xpypr,kidno,absbt,ccbtc,pycur,pyamt,bupla,secco,cession_kz,ppdiff,ppdif2,ppdif3,kblnr,kblpos,grant_nbr,gmvkz,srtype,lotkz,fkber,intreno,pprct,buzid,auggj,hktid,budget_pd,pays_prov,pays_tran,mndid,_dataaging,vname,egrup,btype,propmano,gkont,gkart,ghkon from sapabap1./eon/dlfisqbsad where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_bsak","query":"select mandt,bukrs,lifnr,umsks,umskz,augdt,augbl,zuonr,gjahr,belnr,buzei,budat,bldat,cpudt,waers,xblnr,blart,monat,bschl,zumsk,shkzg,gsber,tax_country,mwskz,dmbtr,wrbtr,mwsts,wmwst,lwsts,bdiff,bdif2,sgtxt,projn,aufnr,anln1,anln2,ebeln,ebelp,saknr,hkont,fkont,filkd,zfbdt,zterm,zbd1t,zbd2t,zbd3t,zbd1p,zbd2p,skfbt,sknto,wskto,zlsch,zlspr,zbfix,hbkid,bvtyp,rebzg,rebzj,rebzz,samnr,zollt,zolld,lzbkz,landl,diekz,mansp,mschl,madat,manst,maber,xnetb,xanet,xcpdd,xesrd,xzahl,mwsk1,tax_country1,dmbt1,wrbt1,mwsk2,tax_country2,dmbt2,wrbt2,mwsk3,tax_country3,dmbt3,wrbt3,qsskz,qsshb,qbshb,bstat,anfbn,anfbj,anfbu,vbund,rebzt,stceg,egbld,eglld,qsznr,qsfbt,xinve,projk,fipos,nplnr,aufpl,aplzl,xegdr,dmbe2,dmbe3,dmb21,dmb22,dmb23,dmb31,dmb32,dmb33,mwst2,mwst3,sknt2,sknt3,bdif3,xragl,rstgr,uzawe,kostl,lnran,xstov,kzbtr,xref1,xref2,xarch,pswsl,pswbt,imkey,zekkn,fistl,geber,dabrz,xnegp,empfb,prctr,xref3,dtws1,dtws2,dtws3,dtws4,xpypr,kidno,pycur,pyamt,bupla,secco,ppdiff,ppdif2,ppdif3,penlc1,penlc2,penlc3,penfc,pendays,penrc,vertt,vertn,vbewa,kblnr,kblpos,grant_nbr,gmvkz,srtype,lotkz,zinkz,fkber,intreno,pprct,buzid,auggj,hktid,budget_pd,_dataaging,vname,egrup,btype,propmano,gkont,gkart,ghkon from sapabap1./eon/dlfisqbsak where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_bsas","query":"select mandt,bukrs,hkont,augdt,augbl,zuonr,gjahr,belnr,buzei,budat,bldat,waers,xblnr,blart,monat,bschl,shkzg,gsber,tax_country,mwskz,fkont,dmbtr,wrbtr,mwsts,wmwst,sgtxt,projn,aufnr,werks,kostl,zfbdt,xopvw,valut,bstat,bdiff,bdif2,vbund,pswsl,wverw,dmbe2,dmbe3,mwst2,mwst3,bdif3,rdif3,xragl,projk,prctr,xstov,xarch,pswbt,xnegp,rfzei,ccbtc,xref3,bupla,ppdiff,ppdif2,ppdif3,bewar,imkey,dabrz,intreno,grant_nbr,fkber,fipos,fistl,geber,pprct,buzid,auggj,uzawe,segment,psegment,pgeber,pgrant_nbr,measure,budget_pd,pbudget_pd,_dataaging,kidno,prodper,qsskz,propmano,gkont,gkart,ghkon from sapabap1./eon/dlfisqbsas where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_bseg","query":"select mandt,bukrs,belnr,gjahr,buzei,buzid,augdt,augcp,augbl,bschl,zumsk,gsber,tax_country,dmbtr,hwbas,fwbas,hwzuz,fwzuz,stekz,gbetr,bdiff,bdif2,zuonr,zinkz,altkt,fdlev,fdgrp,fdwbt,fdtag,fkont,aufnr,eten2,service_doc_type,service_doc_id,service_doc_item_id,anln1,anln2,anbwa,bzdat,hkont,filkd,gvtyp,hzuon,zfbdt,zterm,zbd1t,zbd2t,zbd3t,zbd1p,zbd2p,zlspr,zbfix,hbkid,bvtyp,tax_country1,dmbt1,tax_country2,dmbt2,tax_country3,dmbt3,zollt,zolld,diekz,abper,disbn,disbj,disbz,anfbn,anfbj,anfbu,anfae,blnbt,blnkz,blnpz,esrnr,esrre,esrpz,erfmg,erfme,bpmng,bprme,ebeln_logsys,ebeln,ebelp,zekkn,elikz,bwkey,bwtar,bustw,bonfb,bualt,egbld,eglld,vname,recid,egrup,vptnr,imkey,dabrz,fipos,aufpl,aplzl,btype,etype,hrkft,dmbe2,dmbe3,dmb21,dmb22,dmb23,dmb31,dmb32,dmb33,bdif3,hwmet,glupm,lokkt,fistl,geber,kblnr,kblpos,fkber,ccbtc,empfb,dtws1,dtws2,dtws3,dtws4,gricd,gityp,absbt,idxsp,linfv,agzei,bupla,cession_kz,prznr,grant_nbr,fkber_long,gmvkz,srtype,measure,auggj,ppa_ex_ind,docln,segment,psegment,hktid,pays_prov,pays_tran,awtyp,awkey,awsys,buzei_sender,h_bstat,h_budat,h_bldat,h_blart,h_hwaer,h_hwae2,h_hwae3,prctr_drvtn_source_type,_dataaging,fqftype,lqitem,gkont,gkart,ghkon,anln2_pn,bwasl_pn,bzdat_pn,anbtr_pn,acrobjtype,acrlogsys,acrobj_id,acrsobj_id,acritmtype,acrvaldat,sdm_version,glo_ref1,re_bukrs,re_account,pgeber,pgrant_nbr,budget_pd,pbudget_pd,j_1tpbupl,perop_beg,perop_end,fastpay,ignr_ivref,fmfgus_key,fmxdocnr,fmxyear,fmxdocln,fmxzekkn,prodper,gst_part,plc_sup,hsn_sac,recrf from sapabap1./eon/dlfisqbseg where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_bset","query":"select mandt,bukrs,belnr,gjahr,buzei,tax_country,mwskz,txdat_from,hkont,txgrp,shkzg,hwbas,fwbas,hwste,fwste,ktosl,knumh,stceg,egbld,eglld,txjcd,h2ste,h3ste,h2bas,h3bas,kschl,stmdt,stmti,mlddt,kbetr,stbkz,lstml,lwste,lwbas,txdat,bupla,txjdp,txjlv,taxps,txmod,_dataaging from sapabap1./eon/dlfisqbset where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_bsid","query":"select mandt,bukrs,kunnr,umsks,umskz,augdt,augbl,zuonr,gjahr,belnr,buzei,budat,bldat,cpudt,waers,xblnr,blart,monat,bschl,zumsk,shkzg,gsber,tax_country,mwskz,dmbtr,wrbtr,mwsts,wmwst,lwsts,bdiff,bdif2,sgtxt,projn,aufnr,anln1,anln2,saknr,hkont,fkont,filkd,zfbdt,zterm,zbd1t,zbd2t,zbd3t,zbd1p,zbd2p,skfbt,sknto,wskto,zlsch,zlspr,zbfix,hbkid,bvtyp,rebzg,rebzj,rebzz,samnr,anfbn,anfbj,anfbu,anfae,mansp,mschl,madat,manst,maber,xnetb,xanet,xcpdd,xinve,xzahl,mwsk1,tax_country1,dmbt1,wrbt1,mwsk2,tax_country2,dmbt2,wrbt2,mwsk3,tax_country3,dmbt3,wrbt3,bstat,vbund,vbeln,rebzt,stceg,egbld,eglld,rstgr,vertt,vertn,vbewa,wverw,projk,fipos,nplnr,aufpl,aplzl,xegdr,dmbe2,dmbe3,dmb21,dmb22,dmb23,dmb31,dmb32,dmb33,bdif3,xragl,uzawe,xstov,mwst2,mwst3,sknt2,sknt3,xref1,xref2,pswsl,pswbt,lzbkz,landl,imkey,vbel2,posn2,eten2,fistl,geber,dabrz,xnegp,kostl,rfzei,kkber,empfb,prctr,xref3,qsskz,zinkz,dtws1,dtws2,dtws3,dtws4,xpypr,kidno,absbt,ccbtc,pycur,pyamt,bupla,secco,cession_kz,ppdiff,ppdif2,ppdif3,kblnr,kblpos,grant_nbr,gmvkz,srtype,lotkz,fkber,intreno,pprct,buzid,auggj,hktid,budget_pd,bdgt_account,re_account,pays_prov,pays_tran,mndid,_dataaging,kontt,kontl,vname,egrup,btype,propmano,gkont,gkart,ghkon,awtyp,logsystem_sender,bukrs_sender,belnr_sender,gjahr_sender,buzei_sender from sapabap1./eon/dlfisqbsid where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_bsik","query":"select mandt,bukrs,lifnr,umsks,umskz,augdt,augbl,zuonr,gjahr,belnr,buzei,budat,bldat,cpudt,waers,xblnr,blart,monat,bschl,zumsk,shkzg,gsber,tax_country,mwskz,dmbtr,wrbtr,mwsts,wmwst,lwsts,bdiff,bdif2,sgtxt,projn,aufnr,anln1,anln2,ebeln,ebelp,saknr,hkont,fkont,filkd,zfbdt,zterm,zbd1t,zbd2t,zbd3t,zbd1p,zbd2p,skfbt,sknto,wskto,zlsch,zlspr,zbfix,hbkid,bvtyp,rebzg,rebzj,rebzz,samnr,zollt,zolld,lzbkz,landl,diekz,mansp,mschl,madat,manst,maber,xnetb,xanet,xcpdd,xzahl,mwsk1,tax_country1,dmbt1,wrbt1,mwsk2,tax_country2,dmbt2,wrbt2,mwsk3,tax_country3,dmbt3,wrbt3,qsskz,qsshb,qbshb,bstat,anfbn,anfbj,anfbu,vbund,rebzt,stceg,egbld,eglld,qsznr,qsfbt,xinve,projk,fipos,nplnr,aufpl,aplzl,xegdr,dmbe2,dmbe3,dmb21,dmb22,dmb23,dmb31,dmb32,dmb33,mwst2,mwst3,sknt2,sknt3,bdif3,xragl,rstgr,uzawe,kostl,lnran,xstov,kzbtr,xref1,xref2,pswsl,pswbt,imkey,zekkn,fistl,geber,dabrz,xnegp,empfb,prctr,xref3,dtws1,dtws2,dtws3,dtws4,xpypr,kidno,pycur,pyamt,bupla,secco,ppdiff,ppdif2,ppdif3,penlc1,penlc2,penlc3,penfc,pendays,penrc,vertt,vertn,vbewa,kblnr,kblpos,grant_nbr,gmvkz,srtype,lotkz,zinkz,fkber,intreno,pprct,buzid,auggj,hktid,budget_pd,bdgt_account,re_account,_dataaging,kontt,kontl,vname,egrup,btype,propmano,gkont,gkart,ghkon,pernr,vorgn,awtyp,logsystem_sender,bukrs_sender,belnr_sender,gjahr_sender,buzei_sender from sapabap1./eon/dlfisqbsik where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_bsis","query":"select mandt,bukrs,hkont,augdt,augbl,zuonr,gjahr,belnr,buzei,budat,bldat,waers,xblnr,blart,monat,bschl,shkzg,gsber,tax_country,mwskz,fkont,dmbtr,wrbtr,mwsts,wmwst,sgtxt,projn,aufnr,werks,kostl,zfbdt,xopvw,valut,bstat,bdiff,bdif2,vbund,pswsl,wverw,dmbe2,dmbe3,mwst2,mwst3,bdif3,rdif3,xragl,projk,prctr,xstov,xarch,pswbt,xnegp,rfzei,ccbtc,xref3,bupla,ppdiff,ppdif2,ppdif3,bewar,imkey,dabrz,intreno,grant_nbr,fkber,fipos,fistl,geber,pprct,buzid,auggj,uzawe,segment,psegment,pgeber,pgrant_nbr,measure,budget_pd,pbudget_pd,_dataaging,kidno,prodper,qsskz,propmano,gkont,gkart,ghkon from sapabap1./eon/dlfisqbsis where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_bvor","query":"select mandt,bvorg,bukrs,gjahr,belnr,xarch,_dataaging from sapabap1./eon/dlfisqbvor where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_setheader","query":"select mandt,setclass,subclass,setname,settype,xdynamic,authgr,xuniq,rvalue,creuser,credate,cretime,upduser,upddate,updtime,saprl,tabname,fieldname,rollname,set_olangu,no_rwsheader,no_rwsline,no_setlinet from sapabap1./eon/dlfisqsethd where mandt = '200'"},{"tablename":"/eon/dlfi_v_setleaf","query":"select mandt,setclass,subclass,setname,lineid,valsign,valoption,valfrom,valto,seqnr from sapabap1./eon/dlfisqsetlf where mandt = '200'"},{"tablename":"/eon/dlfi_v_ska1","query":"select mandt,/eon/attr_con,/eon/attr_per,/eon/inc_type,/eon/investa,/eon/maturity,/eon/move_type,/eon/partnera,/eon/tran_type,bilkt,erdat,ernam,func_area,glaccount_subtype,glaccount_type,gvtyp,ktoks,ktopl,last_changed_ts,main_saknr,mcod1,mustr,sakan,saknr,vbund,xbilk,xloev,xspea,xspeb,xspep from sapabap1./eon/dlfisqska1 where ktopl = 'ecoa' and mandt = '200'"},{"tablename":"/eon/dlfi_v_skat","query":"select mandt,ktopl,last_changed_ts,mcod1,saknr,spras,txt20,txt50 from sapabap1./eon/dlfisqskat where ktopl = 'ecoa' and mandt = '200'"},{"tablename":"/eon/dlfi_v_skb1","query":"select mandt,altkt,begru,bewgp,bukrs,busab,cochanged,datlz,erdat,ernam,fdgrv,fdlev,fipls,fipos,fstag,hbkid,hktid,infky,kdfsl,last_changed_ts,mcakey,mitkz,mwskz,recid,saknr,stext,togru,vzskz,waers,wmeth,x_uj_clr,xgkon,xintb,xkres,xlgclr,xloeb,xmitk,xmwno,xnkon,xopvw,xsalh,xspeb,zindt,zinrt,zuawa from sapabap1./eon/dlfisqskb1 where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_t001","query":"select mandt,bukrs,butxt,ort01,land1,waers,spras,ktopl,waabw,periv,kokfi,rcomp,adrnr,stceg,fikrs,xfmco,xfmcb,xfmca,txjcd,fmhrdate,xtemplt,buvar,fdbuk,xfdis,xvalv,xskfn,kkber,xmwsn,mregl,xgsbe,xgjrv,xkdft,xprod,xeink,xjvaa,xvvwa,xslta,xfdmm,xfdsd,xextb,ebukr,ktop2,umkrs,bukrs_glob,fstva,opvar,xcovr,txkrs,wfvar,xbbbf,xbbbe,xbbba,xbbko,xstdt,mwskv,mwska,impda,xnegp,xkkbi,wt_newwt,pp_pdate,infmt,fstvare,kopim,dkweg,offsacct,bapovar,xcos,xcession,xsplt,surccm,dtprov,dtamtc,dttaxc,dttdsp,dtaxr,xvatdate,pst_per_var,xbbsc,f_obsolete,fm_derive_acc from sapabap1./eon/dlfisqt001 where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dllo_v_knb1","query":"select mandt,kunnr,bukrs,pernr,knb1_eew_cc,erdat,ernam,sperr,loevm,zuawa,busab,akont,begru,knrze,knrzb,zamim,zamiv,zamir,zamib,zamio,zwels,xverr,zahls,zterm,wakon,vzskz,zindt,zinrt,eikto,zsabe,kverm,fdgrv,vrbkz,vlibb,vrszl,vrspr,vrsnr,verdt,perkz,xdezv,xausz,webtr,remit,datlz,xzver,togru,kultg,hbkid,xpore,blnkz,altkn,zgrup,urlid,mgrup,lockb,uzawe,ekvbd,sregl,xedip,frgrp,vrsdg,tlfxs,intad,xknzb,guzte,gricd,gridt,wbrsl,confs,updat,uptim,nodel,tlfns,cession_kz,avsnd,ad_hash,qland,cvp_xblck_b,ciiucode,/eon/avimail,gmvkzd from sapabap1./eon/dllosqknb1 where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dllo_v_knvp","query":"select mandt,kunnr,vkorg,vtweg,spart,parvw,parza,kunn2,lifnr,pernr,parnr,knref,defpa from sapabap1./eon/dllosqknvp where mandt = '200'"},{"tablename":"/eon/dllo_v_lfa1_1","query":"select mandt,lifnr,land1,name1,name2,name3,name4,ort01,ort02,pfach,pstl2,pstlz,regio,sortl,stras,adrnr,mcod1,mcod2,mcod3,anred,bahns,bbbnr,bbsnr,begru,brsch,bubkz,datlt,dtams,dtaws,erdat,ernam,esrnr,konzs,ktokk,kunnr,lnrza,loevm,sperr,sperm,spras,stcd1,stcd2,stkza,stkzu,telbx,telf1,telf2,telfx,teltx,telx1,xcpdk,xzemp,vbund,fiskn,stceg,stkzn,sperq,gbort,gbdat,sexkz,kraus,revdb,qssys,ktock,pfort,werks,ltsna,werkr,plkal,duefl,txjcd,sperz,scacd,sfrgr,lzone,xlfza,dlgrp,fityp,stcdt,regss,actss,stcd3,stcd4,stcd5,stcd6,ipisp,taxbs,profs,stgdl,emnfr,lfurl,j_1kfrepre,j_1kftbus,j_1kftind,confs,updat,uptim,nodel,qssysdat,podkzb,fisku,stenr,carrier_conf,min_comp,term_li,crc_num,cvp_xblck,weora,rg,exp,uf,rgdate,ric,rne,rnedate,cnae,legalnat,crtn,icmstaxpay,indtyp,tdt,comsize,decregpc,allowance_type,lfa1_eew_supp,j_sc_capital,j_sc_currency,alc,pmt_office,ppa_relevant,psofg,psois,pson1,pson2,pson3,psovn,psotl,psohs,psost,borgr_datun,borgr_yeaun,au_carrying_ent,au_ind_under_18,au_payment_not_exceed_75,au_wholly_inp_taxed,au_partner_without_gain,au_not_entitled_abn,au_payment_exempt,au_private_hobby,au_domestic_nature,addr2_street,addr2_house_num,addr2_post,addr2_city,addr2_country,categ,partner_name,partner_utr,status,vfnum,vfnid,j_1iexcd,j_1iexrn,j_1iexrg,j_1iexdi,j_1iexco,j_1icstno,j_1ilstno,j_1ipanno,j_1iexcive,j_1issist,j_1ivtyp,j_1ivencre,aedat,usnam,j_1isern,j_1ipanref,j_1ipanvaldt,j_1i_customs,j_1idedref,ven_class,entpub,escrit,dvalss,frmcss,codcae,ausdiv,transport_chain,staging_time,scheduling_type,submi_relevant,zzamsst from sapabap1./eon/dllosqlfa1 where mandt = '200'"},{"tablename":"/eon/dllo_v_lfb1","query":"select mandt,lifnr,bukrs,pernr,erdat,ernam,sperr,loevm,zuawa,akont,begru,vzskz,zwels,xverr,zahls,zterm,eikto,zsabe,kverm,fdgrv,busab,lnrze,lnrzb,zindt,zinrt,datlz,xdezv,webtr,kultg,reprf,togru,hbkid,xpore,qsznr,qszdt,qsskz,blnkz,mindk,altkn,zgrup,mgrup,uzawe,qsrec,qsbgr,qland,xedip,frgrp,togrr,tlfxs,intad,xlfzb,guzte,gricd,gridt,xausz,cerdt,confs,updat,uptim,nodel,tlfns,avsnd,ad_hash,cvp_xblck_b,ciiucode,paymentclearinggrpid,paytrsn,lfb1_eew_cc,zbokd,zqsskz,zqszdt,zqsznr,zmindat,j_sc_subcontype,j_sc_compdate,j_sc_offsm,j_sc_offsr,basis_pnt,gmvkzk,brsch,wrbtr,waers,forgn,notes,active,us_rec_country,us_rec_dob,us_w8_recvdate,us_w9_recvdate,us_tin_notice,us_partnership_ind,us_fatca_ind,prepay_relevant,assign_test from sapabap1./eon/dllosqlfb1 where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlmm_v_eban","query":"select mandt,banfn,bnfpo,bukrs,bsart,bstyp,bsakz,loekz,statu,estkz,frgkz,frgzu,frgst,ekgrp,ernam,erdat,afnam,txz01,matnr,ematn,werks,lgort,bednr,matkl,reswk,menge,meins,bumng,badat,lpein,lfdat,frgdt,webaz,preis,peinh,pstyp,knttp,kzvbr,kflag,vrtkz,twrkz,wepos,weunb,repos,lifnr,flief,ekorg,vrtyp,konnr,ktpnr,infnr,zugba,qunum,qupos,dispo,sernr,bvdat,batol,bvdrk,ebeln,ebelp,bedat,bsmng,lblni,bwtar,xoblr,ebakz,rsnum,sobkz,arsnr,arsps,fixkz,bmein,revlv,vorab,packno,kanba,bpueb,cuobj,frggr,frgrl,aktnr,charg,umsok,verid,fipos,fistl,geber,kzkfg,satnr,mng02,dat01,attyp,adrnr,adrn2,kunnr,emlif,lblkz,kzbws,waers,idnlf,gsfrg,mprof,kzfme,spras,techs,mfrpn,mfrnr,emnfr,fordn,fordp,plifz,berid,uzeit,fkber,grant_nbr,memory,banpr,rlwrt,blckd,revno,blckt,beswk,eprofile,eprefdoc,eprefitm,gmmng,wrtkz,reslo,kblnr,kblpos,prio_urg,prio_req,memorytype,anzsn,mhdrz,iprkz,nodisp,srm_contract_id,srm_contract_itm,budget_pd,eldat,expert_mode,central_purreqn_proc,spe_crm_ref_so,spe_crm_ref_item,dummy_eban_incl_eew_ps,/eon/bname,/eon/hseri,/eon/dprot,/eon/dummy,storenetworkid,storesupplierid,creationdate,creationtime,producttype,serviceperformer,iseopblocked,ext_rev_tmstmp,fmfgus_key,startdate,enddate,extmaterialforpurg,extfixedsupplierforpurg,extdesiredsupplierforpurg,extcontractforpurg,extcontractitemforpurg,extinforecordforpurg,extplantforpurg,extcompanycodeforpurg,extpurgorgforpurg,ext_be_prchangeindicator,extdoctypeforpurg,extapprovalstatus,purchasereqnitemuniqueid,lastchangedatetime,isonbehalfcart,sdm_version,sakto,kostl,expected_value,limit_amount,isoutline,parent_item_no,outline_type,advcode,stacode,banfn_cs,bnfpo_cs,item_cs,bsmng_snd,no_mard_data,admoi,adpri,lprio,adacn,addns,serru,disub_sobkz,disub_pspnr,disub_kunnr,disub_vbeln,disub_posnr,disub_owner,fldlogssupplyprocess,fldlogsdelivisheldonshore,fsh_season_year,fsh_season,fsh_collection,fsh_theme,fsh_vas_rel,fsh_vas_prnt_id,fsh_transaction,fsh_item_group,fsh_item,iuid_relevant,sc_catalogid,sc_author,sgt_scat,sgt_rcat,wrf_charstc1,wrf_charstc2,wrf_charstc3 from sapabap1./eon/dlmmsqeban where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlmm_v_ekko","query":"select mandt,ebeln,bukrs,bstyp,bsart,bsakz,loekz,statu,aedat,ernam,lastchangedatetime,pincr,lponr,lifnr,spras,zterm,zbd1t,zbd2t,zbd3t,zbd1p,zbd2p,ekorg,ekgrp,waers,wkurs,kufix,bedat,kdatb,kdate,bwbdt,angdt,bnddt,gwldt,ausnr,angnr,ihran,ihrez,verkf,telf1,llief,kunnr,active_id,konnr,abgru,autlf,weakt,reswk,lblif,inco1,inco2,ktwrt,distributiontype,submi,knumv,kalsm,stafo,lifre,exnum,unsez,logsy,upinc,stako,frggr,frgsx,frgke,frgzu,frgrl,lands,lphis,adrnr,stceg_l,stceg,absgr,addnr,kornr,memory,procstat,process_indicator,rlwrt,cr_stat,revno,scmproc,reason_code,memorytype,rettp,retpc,dptyp,dppct,dpamt,dpdat,msr_id,hierarchy_exists,grouping_id,parent_id,threshold_exists,legal_contract,description,release_date,vsart,handoverloc,shipcond,incov,inco2_l,inco3_l,grwcu,intra_rel,intra_excl,qtn_erlst_submsn_date,followon_doc_cat,followon_doc_type,dummy_ekko_incl_eew_ps,/eon/uex_relevant,externalsystem,externalreferenceid,ext_rev_tmstmp,iseopblocked,isaged,force_id,force_cnt,reloc_id,reloc_seq_id,source_logsys,fsh_transaction,fsh_item_group,fsh_vas_last_item,fsh_os_stg_change,tms_ref_uuid,/eon/vgkri,/eon/vsana,/eon/vsanv,/eon/anzan,/eon/strfx,/eon/abgrz,/eon/envid,zapcgk,apcgk_extend,zbas_date,zadattyp,zstart_dat,z_dev,zindanx,zlimit_dat,numerator,hashcal_bdat,hashcal,negative,hashcal_exists,known_index,postat,vzskz,fsh_snst_status,proce,conc,cont,comp,outr,desp,desp_dat,desp_cargo,pare,pare_dat,pare_cargo,pfm_contract,pohf_type,eq_eindt,eq_werks,fixpo,ekgrp_allow,werks_allow,contract_allow,pstyp_allow,fixpo_allow,key_id_allow,aurel_allow,delper_allow,eindt_allow,ltsnr_allow,otb_level,otb_cond_type,key_id,otb_value,otb_curr,otb_res_value,otb_spec_value,spr_rsn_profile,budg_type,otb_status,otb_reason,check_type,con_otb_req,con_prebook_lev,con_distr_lev from sapabap1./eon/dlmmsqekko where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlmm_v_ekpo","query":null},{"tablename":"/eon/dlsd_v_vbak","query":"select vbeln,erdat,erzet,ernam,angdt,bnddt,audat,vbtyp,trvog,auart,augru,gwldt,submi,lifsk,faksk,netwr,waerk,vkorg,vtweg,spart,vkgrp,vkbur,gsber,gskst,guebg,gueen,knumv,vdatu,delivery_date_type_rule,vprgr,autlf,vbkla,vbklt,kalsm,vsbed,fkara,awahr,ktext,bstnk,bsark,bstdk,bstzd,ihrez,bname,telf1,mahza,mahdt,kunnr,kostl,stafo,stwae,aedat,kvgr1,kvgr2,kvgr3,kvgr4,kvgr5,knuma,kokrs,ps_psp_pnr,kurst,kkber,knkli,grupp,sbgrp,ctlpc,cmwae,cmfre,cmnup,cmngv,amtbl,hityp_pr,abrvw,abdis,vgbel,objnr,bukrs_vf,taxk1,taxk2,taxk3,taxk4,taxk5,taxk6,taxk7,taxk8,taxk9,xblnr,zuonr,vgtyp,kalsm_ch,agrzr,aufnr,qmnum,vbeln_grp,scheme_grp,abruf_part,abhod,abhov,abhob,rplnr,vzeit,stceg_l,landtx,xegdr,enqueue_grp,dat_fzau,fmbdat,vsnmr_v,handle,proli,cont_dg,crm_guid,upd_tmstmp,msr_id,oipbl,last_changed_by_user,handoverloc,ext_bus_syst_id,ext_ref_doc_id,ext_rev_tmstmp,apm_approval_status,apm_approval_reason,apm_rejection_reason,solution_order_id,ext_comm_syst_type,retro_purchdoc_creation,crossitem_prc_date,_dataaging,abstk,bestk,cmpsc,cmpsd,cmpsi,cmpsj,cmpsk,cmps_cm,cmps_te,cmgst,costa,dcstk,fksak,fmstk,fsstk,gbstk,lfgsk,lfstk,lsstk,manek,rfgsk,rfstk,spstg,trsta,uvall,uvals,uvfak,uvfas,uvprs,uvvlk,uvvls,uvk01,uvk02,uvk03,uvk04,uvk05,uvs01,uvs02,uvs03,uvs04,uvs05,wbstk,total_emcst,total_slcst,total_lccst,total_pcsta,total_dgsta,total_sdssta,bob_status,dp_clear_sta_hdr,b2b_msg_processing_status,total_deliv_reltd_billg_sta,sdm_version,dummy_salesdoc_incl_eew_ps,/igy/sdsf_qnum,glo_log_ref1_hd,/dmbe/dealnumber,/dmbe/evgidrenewal,/dmbe/evgidcancel,/eon/itcig,/eon/itcup,/eon/conv_num,/eon/conv_date,/eon/rec_num,/eon/rec_date,/eon/agr,/eon/doc_date,/eon/doc_id,zapcgkh,apcgk_extendh,zabdath,ad01fareg,ad01basdoc,lastvchr,psm_budat,fsh_kvgr6,fsh_kvgr7,fsh_kvgr8,fsh_kvgr9,fsh_kvgr10,fsh_rereg,fsh_cq_check,fsh_vrsn_status,fsh_transaction,fsh_vas_cg,fsh_candate,fsh_ss,fsh_os_stg_change,j_3gkbaul,mill_appl_id,tas,betc,mod_allow,cancel_allow,pay_method,bpn,rep_freq,logsysb,kalcd,multi,sppaym,wtysc_clm_hdr,mandt from sapabap1./eon/dlsdsqvbak where kokrs = '102n' and mandt = '200'"},{"tablename":"/eon/dlsd_v_vbap","query":null},{"tablename":"/eon/dlsd_v_vbfa","query":"select mandt,ruuid,vbelv,posnv,vbeln,posnn,vbtyp_n,rfmng,meins,rfwrt,waers,vbtyp_v,plmin,taqui,erdat,erzet,matnr,bwart,bdart,plart,lgnum,aedat,fktyp,brgew,gewei,volum,voleh,fplnr,fpltr,rfmng_flo,rfmng_flt,vrkme,abges,sobkz,sonum,kzbef,ntgew,logsys,wbsta,cmeth,mjahr,stufe,_dataaging from sapabap1./eon/dlsdsqvbfa where mandt = '200'"},{"tablename":"/eon/dlsd_v_vbrk","query":"select mandt,vbeln,fkart,fktyp,vbtyp,waerk,vkorg,vtweg,kalsm,knumv,vsbed,fkdat,belnr,gjahr,poper,konda,kdgrp,bzirk,pltyp,inco1,inco2,rfbsk,mrnkz,kurrf,cpkur,valtg,valdt,zterm,zlsch,ktgrd,land1,regio,counc,cityc,bukrs,taxk1,taxk2,taxk3,taxk4,taxk5,taxk6,taxk7,taxk8,taxk9,netwr,zukri,ernam,erzet,erdat,stafo,kunrg,kunag,maber,stwae,stceg,aedat,sfakn,knuma,fkart_rl,fkdat_rl,kurst,mschl,mansp,spart,kkber,knkli,cmwae,cmkuf,hityp_pr,bstnk_vf,vbund,fkart_ab,kappl,landtx,stceg_h,stceg_l,xblnr,zuonr,mwsbk,logsys,fksto,xegdr,rplnr,j_1afitp,kurrf_dat,kidno,bvtyp,numpg,bupla,vkont,fkk_docstat,nrzas,spe_billing_ind,vtref,fk_source_sys,fktyp_crm,stgrd,changed_on,expkz,exnum,akwae,akkur,lcnum,_dataaging,buchk,gbstk,relik,uvals,uvprs,clrst,fksak,fkara,vf_status,vf_todo,bdr_status,bdr_ref,bdr_ref_logsys,bdr_ref_vbtyp,pbd_status,abstk,draft,activedocument,grwcu,blart,intra_rel,intra_excl,accrrel,pspsd,apm_approval_status,apm_approval_reason,srcedoc_ext_comm_syst_type,ico_lifnr,j_1tpbupl,incov,inco2_l,inco3_l,sdm_version,dummy_billingdoc_incl_eew_ps,glo_log_ref1_hd,zapcgkh,apcgk_extendh,zabdath,dpc_rel,ad01basdoc,ad01fareg,vchrnmbr,j_3gkbaul,j_3gkenie,kunwe,mndid,pay_type,sepon,mndvg,sppaym,sppord from sapabap1./eon/dlsdsqvbrk where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlsd_v_vbrp","query":"select vbeln,posnr,uepos,fkimg,vrkme,umvkz,umvkn,meins,smeng,fklmg,lmeng,ntgew,brgew,gewei,volum,voleh,gsber,prsdt,fbuda,kursk,netwr,vbelv,posnv,vgbel,vgpos,vgtyp,aubel,aupos,auref,matnr,arktx,pmatn,charg,matkl,pstyv,posar,prodh,vstel,atpkz,spart,pospa,werks,aland,wkreg,wkcou,wkcty,taxm1,taxm2,taxm3,taxm4,taxm5,taxm6,taxm7,taxm8,taxm9,kowrr,prsfd,sktof,skfbp,kondm,ktgrm,kostl,bonus,provg,eannr,vkgrp,vkbur,spara,shkzg,ernam,erdat,erzet,bwtar,lgort,stafo,wavwr,kzwi1,kzwi2,kzwi3,kzwi4,kzwi5,kzwi6,stcur,uvprs,uvall,ean11,prctr,kvgr1,kvgr2,kvgr3,kvgr4,kvgr5,mvgr1,mvgr2,mvgr3,mvgr4,mvgr5,matwa,bonba,kokrs,paobjnr,ps_psp_pnr,aufnr,txjcd,cmpre,cmpnt,cuobj,cuobj_ch,koupd,uecha,xchar,abrvw,sernr,bzirk_auft,kdgrp_auft,konda_auft,lland_auft,mprok,pltyp_auft,regio_auft,vkorg_auft,vtweg_auft,abrbg,prosa,uepvw,autyp,stadat,fplnr,fpltr,aktnr,knuma_pi,knuma_ag,mwsbp,augru_auft,fareg,upmat,ukonm,cmpre_flt,abfor,abges,j_1arfz,j_1aregio,j_1agicd,j_1adtyp,j_1atxrel,j_1bcfop,j_1btaxlw1,j_1btaxlw2,j_1btxsdc,brtwr,wktnr,wktps,rplnr,kursk_dat,wgru1,wgru2,kdkg1,kdkg2,kdkg3,kdkg4,kdkg5,vkaus,j_1aindxp,j_1aidatep,kzfme,mwskz,vertt,vertn,sgtxt,delco,bemot,rrrel,wminr,vgbel_ex,vgpos_ex,logsys,vgtyp_ex,j_1btaxlw3,j_1btaxlw4,j_1btaxlw5,msr_id,msr_refund_code,msr_ret_reason,nrab_knumh,nrab_value,dispute_case,fund_usage_item,farr_reltype,claims_taxation,kurrf_dat_orig,sgt_rcat,sgt_scat,prefe,akkur,waerk,draft,activedocument,grwrt,fksaa,absta,abgru,mwsk1,pbd_id,pbd_item_id,cats_overtime_category,contr_dp_settl,prodh_univ_sales_parnt_nodid,transit_plant,vcm_chain_category,vcm_chain_uuid,reason_code,_dataaging,spe_herkl,spe_herkr,itm_comco,vtkey,vtpos,srcdoc_process_type,t2ccode_crcy_conv_factor,t2cntry_crcy_conv_factor,dummy_billgdocitem_incl_eew_ps,service_doc_type,service_doc_id,service_doc_item_id,solution_order_id,solution_order_item_id,/cwm/menge,/cwm/meins,vbtyp_ana,fkart_ana,vkorg_ana,vtweg_ana,konda_ana,kdgrp_ana,land1_ana,regio_ana,cityc_ana,bzirk_ana,gbstk_ana,vf_status_ana,kunag_ana,kunrg_ana,fkdat_ana,bukrs_ana,counc_ana,knuma_ana,fktyp_ana,knumv_ana,sfakn_ana,kunwe_ana,kunre_ana,perve_ana,perzm_ana,glo_log_ref1_it,txs_business_transaction,txs_usage_purpose,zapcgki,apcgk_extendi,zabdati,aufpl,aplzl,dpcnr,dcpnr,dpnrb,bosfar,dp_belnr,dp_bukrs,dp_gjahr,dp_buzei,packno,perop_beg,perop_end,fmfgus_key,fsh_season_year,fsh_season,fsh_collection,fsh_theme,fonds,fistl,fkber,grant_nbr,budget_pd,j_3gbelnri,j_3gpmaufe,j_3gpmaufv,j_3getypa,j_3getype,j_3gorgueb,prs_work_period,pprctr,pargb,aufpl_oaa,aplzl_oaa,campaign,compreas,wrf_charstc1,wrf_charstc2,wrf_charstc3,mandt from sapabap1./eon/dlsdsqvbrp where kokrs = '102n' and mandt = '200'"}]

# COMMAND ----------

# #handling null values in the dictionry:
# def handling_null_values(query_json: dict) -> dict:
#     for tableInfo in query_json:
#         if not tableInfo.get("query") or tableInfo.get("tablenam"):
#             tableInfo["query"] = ""
#             tableInfo["tablename"] = ""
#     return query_json

# handling_null_values(query_json)

#handling null values in the dictionry:
def handling_null_values(query_json: dict) -> dict:
    for key in query_json:
        for v in key:
            if not key.get(v):
                key[v] = ""
    return query_json

# handling_null_values(query_json)

# print(query_json)
    
   

# COMMAND ----------

def schema_validation_landing(query_json: Generator[Dict[str, Any], None, None], payload_json: Generator[Dict[str, Any], None, None],storage_account: str,logger: DBFSLogger):
    landing_zone_path  = get_landing_path(payload_json, storage_account)
    source_system = get_source_system(payload_json)
    # erwin_json_path = get_erwin_json_path(payload_json)

    try:
        landing_zone_table_df=get_lz_tables_df(landing_zone_path[0])
        tables = get_table_list(landing_zone_table_df, source_system)
        handling_null_values(query_json)

        for tableInfo in query_json:
            for table_path in tables:   #landing storage account
                #handling null values:


                if table_path.lower().find(tableInfo['tablename'])>0 and tableInfo['query']>4:
                    columnNames=list(tableInfo['query'].replace("select",'').split("from")[0].replace('"','').split(","))

                    df_temp=spark.read.options(header=True).format('parquet').load(table_path)
                    columns_landing=[x.lower() for x in df_temp.columns]
                    difference=set(columns_landing)-(set(columnNames))
                    if difference!=0:
                        logger.error(f'schema has been changed: column mismathes: {difference} found in {tableInfo["tablename"]}')
                        # logger.debug(f'schema has been changed: column mismathes: {difference} found in {tableInfo["tablename"]} ')
                    else:
                        logger.info(f'all columns found in {tableInfo["tablename"]}')
                        # logger.debug(f'all columns found in {tableInfo["tablename"]}')
                else:
                    logger.info(f'{tableInfo["tablename"]} not in landing storage account')
                    # logger.debug(f'{tableInfo["tablename"]} not in landing storage account')
        
    
    
    
    except requests.RequestException as e: 
        raise Exception (f"Storage account is empty: {e}") 

    
                    
                


# COMMAND ----------

schema_validation_landing(query_json, payload_json, storage_account,logger)

# COMMAND ----------

# MAGIC %md
# MAGIC ----------------------------------------------------------------------------------------------

# COMMAND ----------

# setting credentials on erwin storage account
(scope, client_id, client_secret, tenant_id) =  get_platform_config(config_directory, net_type, env)
metadata_storage_account = get_metadata_storage_account(net_type)
set_credentials(scope,metadata_storage_account,client_id,client_secret,tenant_id)

# COMMAND ----------

#ezt majd az erwi storage account connection ala rakni

json_metadata_path=payload_json["erwin_json_file"]

# json_metadata=spark.read.format('delta').load(json_metadata_path)

json_metadata_path='abfss://test-container-in@stedheneuwdis.dfs.core.windows.net/testreka/DE EnviaM - eCount - QA_2024-09-24_015330.json'
json_metadata_path='abfss://test-container-in@stedheneuwdis.dfs.core.windows.net/DE Westnetz - telefoniedb - PROD_2024-02-15_09:11:08.json'
json_metadata_path='abfss://test-container-in@stedheneuwdis.dfs.core.windows.net/testreka/DE Westnetz - S4U - DEV_2024-08-26_103730.json'


json_metadata_path=get_erwin_json_path(payload_json)
print(json_metadata_path)

# COMMAND ----------

# def exploded_erwin_df(json_metadata_df):
#     exploded_erwin_dF = json_metadata_df.withColumn('tables_f',explode(col('tables'))).drop('tables')
#     return exploded_erwin_dF

# # exploded erwin json at column levels  

# def exploded_erwin_col_df(exploded_erwin_df):
#     exploded_erwin_col_df=exploded_erwin_df.select("tables_f.columns").select(explode("columns").alias("x"))\
#             .select("x.primaryKeyFlag","x.tableName","x.columnName","x.sdiflag","x.columnDatatype","x.extendedProperties","x.foreignKeyTableName")
#     return exploded_erwin_col_df

# COMMAND ----------

# reading erwin json file
json_metadata=read_json_df(json_metadata_path)
# display(json_metadata)

# COMMAND ----------

# MAGIC %md
# MAGIC unbundling vaidation

# COMMAND ----------

class schema_validation:
    def __init__(self,payload_json, query_json):
        self.payload_json=payload_json
        self.query_json=query_json
        self.json_metadata_path=self.payload_json["erwin_json_file"]       #!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!  ezt megcsinalni
        self.json_metadata=spark.read.json(self.json_metadata_path)
        self.erwin_Unbundling='200' if self.json_metadata.select(explode("extendedProperties").alias("x"))\
                .select("x.value").filter(col("x.key").like("%EDH - Unbundling%") & col("x.value")=='Regulated') else '100'
        self.erwin_dso_type=self.json_metadata.select(explode("extendedProperties").alias("x")).select("x.value").filter(col("x.key").like("%EDH DSO Filter Criteria%"))
        
        self.erwin_filter_criteria=self.json_metadata.select(explode("extendedProperties").alias("x"))\
                .select("x.value").filter(col("x.key").like("%Source Company Code%")) if self.erwin_dso_type=="Multi DSO" else "No filter required"
    
    
    
    def validate_schema(self):
        pass


    def validate_unbundling(self):
        pass


    def validate_filter_criteria(self):
        pass

    def handling_null_values(self, query_json):
        pass

# COMMAND ----------

erwin_Unbundling='200' if json_metadata.select(explode("extendedProperties").alias("x"))\
            .select("x.value").filter(col("x.key").like("%EDH - Unbundling%") & col("x.value")=='Regulated') else '100'
display(erwin_Unbundling)



# COMMAND ----------

# #table level erwin
# exploded_erwin_dF = json_metadata.withColumn('tables_f',explode(col('tables'))).drop('tables')  #.select("t.tableDefinition")

# #erwin at column levels  

# exploded_erwin_tables_with_MANDT=exploded_erwin_dF.select("tables_f.columns", "tables_f.tableDefinition").select(explode("columns").alias("x"),"tableDefinition")\
#             .select("tableDefinition","x.tableName","x.foreignKeyTableName").filter(col("x.foreignKeyTableName").contains("MANDT"))
                
#                 #"x.tableName","x.columnName","x.sdiflag","x.columnDatatype","x.extendedProperties","x.foreignKeyTableName")

# display(exploded_erwin_tables_with_MANDT)



# COMMAND ----------

# table_ls_with_MANDT=exploded_erwin_tables_with_MANDT.select("tableDefinition").collect()
# table_ls_with_MANDT=[x['tableDefinition'].lower() for x in table_ls_with_MANDT]
# table_ls_with_MANDT

# COMMAND ----------

# null='null'

query_json=[{"tablename":"/eon/dlca_v_jest","query":"select mandt,_dataaging,chgnr,inact,objnr,stat from sapabap1./eon/dlcasqjest where mandt = '200'"},{"tablename":"/eon/dlca_v_tj02t","query":"select istat,spras,txt04,txt30 from sapabap1./eon/dlcasqtj02t"},{"tablename":"/eon/dlca_v_tj30","query":"select mandt,stsma,estat,inist,stonr,hsonr,nsonr,linep,statp,bersl,crm_vrgng from sapabap1./eon/dlcasqtj30 where mandt = '200'"},{"tablename":"/eon/dlca_v_tj30t","query":"select mandt,stsma,estat,spras,txt04,txt30,ltext from sapabap1./eon/dlcasqtj30t where mandt = '200'"},{"tablename":"/eon/dlco_v_acdoca","query":null},{"tablename":"/eon/dlco_v_acdocp","query":"select rclnt,reqtsn,datapakid,record,ryear,rldnr,racct,rbukrs,awtyp,usnam,category,kprice,hprice,wprice,rmvct,bttype,aworg,awref,rwcur,rhcur,rkcur,rocur,rvcur,rbcur,rccur,rdcur,recur,rfcur,rgcur,rco_ocur,rvunit,rcntr,prctr,rfarea,rbusa,kokrs,segment,scntr,pprctr,sfarea,sbusa,rassc,psegment,wsl,hsl,ksl,osl,vsl,bsl,csl,dsl,esl,fsl,gsl,vmsl,kfsl,co_osl,poper,budat,periv,fiscyearper,ktopl,slalittype,kdauf,kdpos,matnr,werks,kunnr,sgtxt,co_belkz,ps_posid,ps_pspid,pernr,pbukrs,uprctr,accasty,lstar,aufnr,rsrce,paufnr,paccasty,plstar,pps_posid,pps_pspid,work_item_id,bemot,psknz,losgr,lsunit,ps_psp_pnr,ps_prj_pnr,pps_psp_pnr,pps_prj_pnr,acdoc_eew_dummy,dummy_incl_eew_cobl,fkart,vkorg,vtweg,spart,matnr_copa,matkl,kdgrp,land1,brsch,bzirk,kunre,kunwe,konzs,acdoc_copa_eew_dummy_pa,ww002_pa,ww011_pa,ww012_pa,ww013_pa,ww014_pa,ww015_pa,ww016_pa,ww017_pa,auart_pa,pstyv_pa,vkbur_pa,ww030_pa,ww031_pa,ww032_pa,ww033_pa,ww034_pa,ww103_pa,ww104_pa,ww105_pa,ww106_pa,ww100_pa,ww101_pa,ww102_pa,ww107_pa,ww108_pa,ww109_pa,ww110_pa,ww111_pa,ww112_pa,ww113_pa,ww114_pa,ww115_pa,ww116_pa,dummy_mrkt_sgmnt_eew_ps,fikrs,rfund,rgrant_nbr,rbudget_pd,budget_process,budget_subcategory,arbid,vornr,aufps,uvorn,equnr,tplnr,istru,ilart,plknz,artpr,priok,maufnr,matkl_mm,paufps,rsnum,rspos,rsart,packno,introw,afabe,anln1,anln2,movcat,anlkl,vname,egrup,recid,prodper,swenr,sgenr,sgrnr,smenr,recnnr,snksl,sempsl,dabrz from sapabap1./eon/dlcosqacdcp where kokrs = '102n' and rclnt = '200'"},{"tablename":"/eon/dlco_v_aufk","query":"select mandt,aufnr,auart,autyp,refnr,ernam,erdat,aenam,aedat,ktext,ltext,bukrs,werks,gsber,kokrs,cckey,kostv,stort,sowrk,astkz,waers,astnr,stdat,estnr,phas0,phas1,phas2,phas3,pdat1,pdat2,pdat3,idat1,idat2,idat3,objid,vogrp,loekz,plgkz,kvewe,kappl,kalsm,zschl,abkrs,kstar,kostl,saknr,setnm,cycle,sdate,seqnr,user0,user1,user2,user3,user4,user5,user6,user7,user8,user9,objnr,prctr,pspel,awsls,abgsl,eb_post,txjcd,func_area,scope,plint,kdauf,kdpos,aufex,ivpro,logsystem,flg_mltps,abukr,akstl,sizecl,izwek,umwkz,kstempf,zschm,pkosa,anfaufnr,procnr,proty,rsord,bemot,adrnra,erfzeit,aezeit,cstg_vrnt,costestnr,veraa_user,zzatl,zzasn,z_oty,zqmnum,zcsaufnr,zcswert,zcsjahr,/eon/inbdt,zzrcv_bukrs,zzrcv_acasty,zzrcv_accass,zzaction_id,zzcustomer,zzaccountsys,zzbukrs,zzswenr,zzsgenr,zzsnksl,zzsempsl,zzdabrz,zzpspel,zzhkont,zzebeln,zzebelp,zz_reason,eew_aufk_ps_dummy,vname,recid,etype,otype,jv_jibcl,jv_jibsa,jv_oco,cpd_updat,/cum/indcu,/cum/cmnum,/cum/auest,/cum/desnum,/mrss/pl_stru_id,/mrss/pl_man_typ,/mrss/order_prob,/mrss/act_type,/mrss/init_done,/mrss/datachange,/mrss/sales_org,/mrss/nw_booked,ad01profnr,vaplz,wawrk,ferc_ind,aufk_status,claim_control,update_needed,update_control from sapabap1./eon/dlcosqaufk where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlco_v_cobk","query":"select mandt,kokrs,belnr,gjahr,versn,vrgng,timestmp,perab,perbi,bldat,budat,cpudt,usnam,bltxt,stflg,stokz,refbt,refbn,refbk,refgj,blart,ldgrp,orgvg,sumbz,delbz,wsdat,kurst,varnr,kwaer,ctyp1,ctyp2,ctyp3,ctyp4,awtyp,aworg,logsystem,cputm,alebz,alebn,awsys,awref_rev,aworg_rev,awkey,valdt,kokrs_sender,belnr_sender,logsystem_sender,reprocessing_status_code from sapabap1./eon/dlcosqcobk where kokrs = '102n' and mandt = '200'"},{"tablename":"/eon/dlco_v_coej","query":"select mandt,kokrs,belnr,buzei,perbl,wtg001,wtg002,wtg003,wtg004,wtg005,wtg006,wtg007,wtg008,wtg009,wtg010,wtg011,wtg012,wtg013,wtg014,wtg015,wtg016,wog001,wog002,wog003,wog004,wog005,wog006,wog007,wog008,wog009,wog010,wog011,wog012,wog013,wog014,wog015,wog016,wkg001,wkg002,wkg003,wkg004,wkg005,wkg006,wkg007,wkg008,wkg009,wkg010,wkg011,wkg012,wkg013,wkg014,wkg015,wkg016,wkf001,wkf002,wkf003,wkf004,wkf005,wkf006,wkf007,wkf008,wkf009,wkf010,wkf011,wkf012,wkf013,wkf014,wkf015,wkf016,pag001,pag002,pag003,pag004,pag005,pag006,pag007,pag008,pag009,pag010,pag011,pag012,pag013,pag014,pag015,pag016,paf001,paf002,paf003,paf004,paf005,paf006,paf007,paf008,paf009,paf010,paf011,paf012,paf013,paf014,paf015,paf016,meg001,meg002,meg003,meg004,meg005,meg006,meg007,meg008,meg009,meg010,meg011,meg012,meg013,meg014,meg015,meg016,mef001,mef002,mef003,mef004,mef005,mef006,mef007,mef008,mef009,mef010,mef011,mef012,mef013,mef014,mef015,mef016,mbg001,mbg002,mbg003,mbg004,mbg005,mbg006,mbg007,mbg008,mbg009,mbg010,mbg011,mbg012,mbg013,mbg014,mbg015,mbg016,mbf001,mbf002,mbf003,mbf004,mbf005,mbf006,mbf007,mbf008,mbf009,mbf010,mbf011,mbf012,mbf013,mbf014,mbf015,mbf016,lednr,objnr,gjahr,wrttp,versn,kstar,hrkft,vrgng,parob,parob1,uspob,vbund,pargb,beknz,twaer,meinh,meinb,sgtxt,refbz,zlenr,bw_refbz,beltp,timestmp,paobjnr,fkber,pfkber,geber,pgeber,grant_nbr,pgrant_nbr,segment,psegment,budget_pd,pbudget_pd from sapabap1./eon/dlcosqcoej where kokrs = '102n' and mandt = '200'"},{"tablename":"/eon/dlco_v_coep","query":"select mandt,kokrs,belnr,buzei,perio,wtgbtr,wogbtr,wkgbtr,wkfbtr,pagbtr,pafbtr,megbtr,mefbtr,mbgbtr,mbfbtr,lednr,objnr,gjahr,wrttp,versn,kstar,hrkft,vrgng,parob,parob1,uspob,vbund,pargb,beknz,twaer,owaer,meinh,meinb,mvflg,sgtxt,refbz,zlenr,bw_refbz,gkont,gkoar,werks,matnr,rbest,ebeln,ebelp,zekkn,erlkz,pernr,btrkl,objnr_n1,objnr_n2,objnr_n3,paobjnr,beltp,bukrs,gsber,fkber,scope,logsyso,pkstar,pbukrs,pfkber,pscope,logsysp,dabrz,bwstrat,objnr_hk,timestmp,qmnum,geber,pgeber,grant_nbr,pgrant_nbr,refbz_fi,segment,psegment,posnr,prctr,pprct,budget_pd,pbudget_pd,prodper,awtyp,awkey,awsys,kwaer,accas,accasty,kostl,lstar,aufnr,autyp,pspnr,pspid,vbeln,vbposnr,ce4key,erkrs,paccas,paccasty,pkostl,plstar,paufnr,pautyp,ppspnr,ppspid,pvbeln,pvbposnr,pce4key,quant1,quant2,quant3,qunit1,qunit2,qunit3 from sapabap1./eon/dlcosqcoep where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlco_v_cooi","query":"select mandt,refbt,refbn,rfpos,rfknt,rftrm,rfart,lifnr,lednr,objnr,hrkft,rforg,rftyp,rfsys,vrgng,gjahr,wrttp,versn,sakto,vbund,pargb,beknz,twaer,uname,bldat,budat,perio,bukrs,kokrs,matnr,matkl,sgtxt,gesmng,meinh,megbtr,mbgbtr,meinb,wkurs,orgwth,whgbtr,orgwtk,wkgbtr,orgwtt,wtgbtr,orgwto,wogbtr,orgwtl,wlgbtr,loekz,dabrz,timestmp from sapabap1./eon/dlcosqcooi where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlco_v_cosp","query":"select mandt,lednr,objnr,gjahr,wrttp,versn,kstar,hrkft,vrgng,vbund,pargb,beknz,twaer,perbl,meinh,wtg001,wtg002,wtg003,wtg004,wtg005,wtg006,wtg007,wtg008,wtg009,wtg010,wtg011,wtg012,wtg013,wtg014,wtg015,wtg016,wog001,wog002,wog003,wog004,wog005,wog006,wog007,wog008,wog009,wog010,wog011,wog012,wog013,wog014,wog015,wog016,wkg001,wkg002,wkg003,wkg004,wkg005,wkg006,wkg007,wkg008,wkg009,wkg010,wkg011,wkg012,wkg013,wkg014,wkg015,wkg016,wkf001,wkf002,wkf003,wkf004,wkf005,wkf006,wkf007,wkf008,wkf009,wkf010,wkf011,wkf012,wkf013,wkf014,wkf015,wkf016,pag001,pag002,pag003,pag004,pag005,pag006,pag007,pag008,pag009,pag010,pag011,pag012,pag013,pag014,pag015,pag016,meg001,meg002,meg003,meg004,meg005,meg006,meg007,meg008,meg009,meg010,meg011,meg012,meg013,meg014,meg015,meg016,mef001,mef002,mef003,mef004,mef005,mef006,mef007,mef008,mef009,mef010,mef011,mef012,mef013,mef014,mef015,mef016,muv001,muv002,muv003,muv004,muv005,muv006,muv007,muv008,muv009,muv010,muv011,muv012,muv013,muv014,muv015,muv016,beltp,timestmp,bukrs,fkber,segment,geber,grant_nbr,budget_pd from sapabap1./eon/dlcosqcosp where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlco_v_coss","query":"select mandt,lednr,objnr,gjahr,wrttp,versn,kstar,hrkft,vrgng,parob,uspob,beknz,twaer,perbl,meinh,wtg001,wtg002,wtg003,wtg004,wtg005,wtg006,wtg007,wtg008,wtg009,wtg010,wtg011,wtg012,wtg013,wtg014,wtg015,wtg016,wog001,wog002,wog003,wog004,wog005,wog006,wog007,wog008,wog009,wog010,wog011,wog012,wog013,wog014,wog015,wog016,wkg001,wkg002,wkg003,wkg004,wkg005,wkg006,wkg007,wkg008,wkg009,wkg010,wkg011,wkg012,wkg013,wkg014,wkg015,wkg016,wkf001,wkf002,wkf003,wkf004,wkf005,wkf006,wkf007,wkf008,wkf009,wkf010,wkf011,wkf012,wkf013,wkf014,wkf015,wkf016,pag001,pag002,pag003,pag004,pag005,pag006,pag007,pag008,pag009,pag010,pag011,pag012,pag013,pag014,pag015,pag016,paf001,paf002,paf003,paf004,paf005,paf006,paf007,paf008,paf009,paf010,paf011,paf012,paf013,paf014,paf015,paf016,meg001,meg002,meg003,meg004,meg005,meg006,meg007,meg008,meg009,meg010,meg011,meg012,meg013,meg014,meg015,meg016,mef001,mef002,mef003,mef004,mef005,mef006,mef007,mef008,mef009,mef010,mef011,mef012,mef013,mef014,mef015,mef016,muv001,muv002,muv003,muv004,muv005,muv006,muv007,muv008,muv009,muv010,muv011,muv012,muv013,muv014,muv015,muv016,beltp,timestmp,bukrs,fkber,segment,geber,grant_nbr,budget_pd from sapabap1./eon/dlcosqcoss where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlco_v_covp","query":"select mandt,kokrs,belnr,buzei,perio,wtgbtr,wogbtr,wkgbtr,wkfbtr,pagbtr,pafbtr,megbtr,mefbtr,mbgbtr,mbfbtr,lednr,objnr,gjahr,wrttp,versn,kstar,hrkft,vrgng,parob,parob1,uspob,vbund,pargb,beknz,twaer,owaer,meinh,meinb,mvflg,sgtxt,refbz,zlenr,bw_refbz,gkont,gkoar,werks,matnr,rbest,ebeln,ebelp,zekkn,erlkz,pernr,btrkl,objnr_n1,objnr_n2,objnr_n3,paobjnr,beltp,bukrs,gsber,fkber,scope,logsyso,pkstar,pbukrs,pfkber,pscope,logsysp,dabrz,bwstrat,objnr_hk,timestmp,qmnum,geber,pgeber,grant_nbr,pgrant_nbr,refbz_fi,segment,psegment,prctr,pprct,budget_pd,pbudget_pd,prodper,perab,perbi,bldat,budat,cpudt,usnam,bltxt,stflg,stokz,refbt,refbn,refbk,refgj,blart,ldgrp,orgvg,sumbz,delbz,wsdat,kurst,varnr,kwaer,ctyp1,ctyp2,ctyp3,ctyp4,awtyp,aworg,logsystem,cputm,alebz,alebn,awsys,awref_rev,aworg_rev,awkey,valdt,kokrs_sender,belnr_sender,logsystem_sender,reprocessing_status_code,k_gjahr,k_versn,k_vrgng,k_timestmp,p_awtyp,p_awkey,p_awsys,p_kwaer,accas,accasty,kostl,lstar,aufnr,autyp,pspnr,vbeln,vbposnr,ce4key,erkrs,paccas,paccasty,pkostl,paufnr,pautyp,ppspnr,pce4key,plstar,pvbeln,pvbposnr,p_posnr,pspid,ppspid,quant1,quant2,quant3,qunit1,qunit2,qunit3 from sapabap1./eon/dlcosqcovp where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlco_v_cska_1","query":"select mandt,ktopl,kstar,ersda,usnam,stekz,zahkz,kstsn,func_area from sapabap1./eon/dlcosqcska where ktopl = 'ecoa' and mandt = '200'"},{"tablename":"/eon/dlco_v_cskb","query":"select mandt,aufnr,datab,datbi,deakt,eigen,ersda,katyp,kokrs,kostl,kstar,last_changed_ts,loevm,mgefl,msehi,plaor,plaus,plazu,recid,usnam from sapabap1./eon/dlcosqcskb where kokrs = '102n' and mandt = '200'"},{"tablename":"/eon/dlco_v_csks","query":"select mandt,abtei,afunk,anred,avc_active,avc_profile,bkzer,bkzkp,bkzks,bkzob,budget_carrying_cost_ctr,bukrs,cckey,cpd_templ,cpi_templ,datab,datbi,datlt,drnam,eew_csks_ps_dummy,ersda,etype,ferc_ind,func_area,func_area_fix_assigned,fund,fund_fix_assigned,funkt,grant_fix_assigned,grant_id,gsber,jv_jibcl,jv_jibsa,jv_otype,kalsm,kappl,khinr,kokrs,kompl,kosar,kostl,koszschl,kvewe,land1,logsystem,mgefl,name1,name2,name3,name4,nkost,objnr,ort01,ort02,pfach,pkzer,pkzkp,pkzks,prctr,pstl2,pstlz,recid,regio,scd_templ,sci_templ,skd_templ,ski_templ,spras,stakz,stras,telbx,telf1,telf2,telfx,teltx,telx1,txjcd,usnam,verak,verak_user,vmeth,vname,waers,werks,zzctx,zzenv,zzesg,zzgf1,zzgf2,zzgrl,zzins,zzisg,zzitu,zzli1,zzli2,zzmai,zzmks,zzorg,zzplt,zzprj,zzpro,zzreg,zzres,zzslr,zzunb from sapabap1./eon/dlcosqcsks where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlco_v_cskt","query":"select mandt,datbi,kokrs,kostl,ktext,ltext,mctxt,spras from sapabap1./eon/dlcosqcskt where kokrs = '102n' and mandt = '200'"},{"tablename":"/eon/dlco_v_csku","query":"select mandt,kstar,ktext,ktopl,ltext,mctxt,spras from sapabap1./eon/dlcosqcsku where ktopl = 'ecoa' and mandt = '200'"},{"tablename":"/eon/dlco_v_csla","query":"select mandt,auseh,ausfk,datab,datbi,ersda,fixvo,hrkft,kokrs,kstty,lark1,lark2,latyp,latypi,leinh,lstar,manist,manplan,sprkz,tarkz,tarkz_i,usnam,vksta,yrate from sapabap1./eon/dlcosqcsla where kokrs = '102n' and mandt = '200'"},{"tablename":"/eon/dlco_v_cslt","query":"select mandt,datbi,kokrs,ktext,lstar,ltext,mctxt,spras from sapabap1./eon/dlcosqcslt where kokrs = '102n' and mandt = '200'"},{"tablename":"/eon/dlco_v_cssl","query":"select mandt,kokrs,kostl,lstar,gjahr,cckey,latyp,leinh,ausfk,auseh,objnr,latypi from sapabap1./eon/dlcosqcssl where kokrs = '102n' and mandt = '200'"},{"tablename":"/eon/dlco_v_prhi","query":"select mandt,posnr,psphi,up,down from sapabap1./eon/dlcosqprhi where mandt = '200'"},{"tablename":"/eon/dlco_v_proj","query":"select mandt,pspnr,pspid,post1,objnr,ernam,erdat,aenam,aedat,kimsk,autod,stspd,stspr,vernr,verna,astnr,astna,vbukr,vgsbr,vkokr,prctr,pwhie,zuord,trmeq,plfaz,plsez,werks,kalid,vgplf,ewplf,zteht,nzanz,plnaw,vprof,profl,bprof,txtsp,kostl,ktrg,aedte,aedtp,berst,bertr,berko,berbu,spsnr,besta,scope,xstat,txjcd,zschm,scprf,imprf,fmprf,abgsl,postu,pprof,plint,loevm,inact,kzbws,smprf,flgvrg,grtop,pgprf,stort,logsystem,kzerb,pargr,func_area,vkorg,vtweg,spart,dppprof,vpkstu,pspid_edit,vname,recid,etype,otype,jibcl,jibsa,eew_proj_ps_dummy,schtyp,sprog,eprog,slwid,usr00,usr01,usr02,usr03,usr04,use04,usr05,use05,usr06,use06,usr07,use07,usr08,usr09,usr10,usr11,cpd_updat,ferc_ind,avc_profile,avc_active,cpcurr,proj_status from sapabap1./eon/dlcosqproj where vbukr = '2200' and mandt = '200'"},{"tablename":"/eon/dlco_v_prps","query":"select mandt,abgsl,abukr,adpsp,aedat,aenam,aennr,akokr,akstl,astna,astnr,belkz,berbu,berko,berst,bertr,cgpl_guid16,cgpl_logsys,cgpl_objtype,clasf,cpd_updat,eew_prps_ps_dummy,equnr,erdat,ernam,etype,evgew,fabkl,fakkz,ferc_ind,fkokr,fkstl,fplnr,func_area,func_area_fix_assigned,fund_fix_assign,grant_fix_assigned,grpkz,imprf,isize,iumkz,izwek,jibcl,jibsa,kalnr,kalsm,kappl,klvar,kostl,ktrg,kvewe,kzbws,loevm,logsystem,matnr,npfaz,objnr,otype,pbukr,pgprf,pgsbr,pkokr,plakz,plint,posid,posid_edit,poski,posnr_prps,post1,postu,prart,prctr,prps_status,psphi,pspkz,pspnr,pspnr_logs,pspri,pwpos,recid,rfippnt,rfund,rgrant_nbr,scope,slwid,sort1,sort2,sort3,sponsoredprog,spsnr,stort,stufe,subpr,tadat,tplnr,trmeq,txjcd,txtsp,use04,use05,use06,use07,usr00,usr01,usr02,usr03,usr04,usr05,usr06,usr07,usr08,usr09,usr10,usr11,vbeln_prps,verna,vernr,vlpkz,vlpsp,vname,werks,xstat,zschl,zschm,zuord,zzacl,zzasn,zzatl,zzcpx,zzctx,zzenv,zzesg,zzgf1,zzgf2,zzgrl,zzins,zzisg,zzitu,zzli1,zzli2,zzmai,zzmks,zzorg,zzplg,zzplt,zzprj,zzpro,zzprv,zzreg,zzres,zzslr,zzstl,zzunb from sapabap1./eon/dlcosqprps where pbukr = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_bkpf","query":"select mandt,bukrs,belnr,gjahr,blart,bldat,budat,monat,cpudt,cputm,aedat,upddt,wwert,usnam,tcode,bvorg,xblnr,dbblg,dbblg_gjahr,dbblg_bukrs,stblg,stjah,bktxt,waers,kursf,kzwrs,kzkrs,bstat,xnetb,frath,xrueb,glvor,grpid,dokid,arcid,iblar,awtyp,awkey,fikrs,hwaer,hwae2,hwae3,kurs2,kurs3,basw2,basw3,umrd2,umrd3,xstov,stodt,xmwst,curt2,curt3,kuty2,kuty3,xsnet,ausbk,xusvr,duefl,awsys,txkrs,ctxkrs,lotkz,xwvof,stgrd,ppnam,ppdat,pptme,pptcod,brnch,numpg,adisc,xref1_hd,xref2_hd,xreversal,reindat,rldnr,ldgrp,propmano,xblnr_alt,vatdate,fulfilldate,doccat,xsplit,cash_alloc,follow_on,xreorg,subset,kurst,kursx,kur2x,kur3x,xmca,resubmission,logsystem_sender,bukrs_sender,belnr_sender,gjahr_sender,intsubid,aworg_rev,awref_rev,xreversing,xreversed,glbtgrp,co_vrgng,co_refbt,co_alebn,co_valdt,co_belnr_sender,kokrs_sender,acc_principle,_dataaging,trava_pn,ldgrpspec_pn,afabespec_pn,xsecondary,reprocessing_status_code,trr_partial_ind,item_removal_status,penrc,glo_ref1_hd,glo_dat1_hd,glo_ref2_hd,glo_dat2_hd,glo_ref3_hd,glo_dat3_hd,glo_ref4_hd,glo_dat4_hd,glo_ref5_hd,glo_dat5_hd,glo_bp1_hd,glo_bp2_hd,ev_postng_ctrl,anxtype,anxamnt,anxperc,zvat_indc,/sapf15/status,psoty,psoak,psoks,psosg,psofn,intform,intdate,psobt,psozl,psodt,psotm,fm_umart,ccins,ccnum,ssblk,batch,sname,sampled,exclude_flag,blind,offset_status,offset_refer_dat,knumv,blo,cnt,pybastyp,pybasno,pybasdat,pyiban,inwarddt_hd from sapabap1./eon/dlfisqbkpf where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_bsad","query":"select mandt,bukrs,kunnr,umsks,umskz,augdt,augbl,zuonr,gjahr,belnr,buzei,budat,bldat,cpudt,waers,xblnr,blart,monat,bschl,zumsk,shkzg,gsber,tax_country,mwskz,dmbtr,wrbtr,mwsts,wmwst,lwsts,bdiff,bdif2,sgtxt,projn,aufnr,anln1,anln2,saknr,hkont,fkont,filkd,zfbdt,zterm,zbd1t,zbd2t,zbd3t,zbd1p,zbd2p,skfbt,sknto,wskto,zlsch,zlspr,zbfix,hbkid,bvtyp,rebzg,rebzj,rebzz,samnr,anfbn,anfbj,anfbu,anfae,mansp,mschl,madat,manst,maber,xnetb,xanet,xcpdd,xinve,xzahl,mwsk1,tax_country1,dmbt1,wrbt1,mwsk2,tax_country2,dmbt2,wrbt2,mwsk3,tax_country3,dmbt3,wrbt3,bstat,vbund,vbeln,rebzt,infae,stceg,egbld,eglld,rstgr,xnoza,vertt,vertn,vbewa,wverw,projk,fipos,nplnr,aufpl,aplzl,xegdr,dmbe2,dmbe3,dmb21,dmb22,dmb23,dmb31,dmb32,dmb33,bdif3,xragl,uzawe,xstov,mwst2,mwst3,sknt2,sknt3,xref1,xref2,xarch,pswsl,pswbt,lzbkz,landl,imkey,vbel2,vpos2,posn2,eten2,fistl,geber,dabrz,xnegp,kostl,rfzei,kkber,empfb,prctr,xref3,qsskz,zinkz,dtws1,dtws2,dtws3,dtws4,xpypr,kidno,absbt,ccbtc,pycur,pyamt,bupla,secco,cession_kz,ppdiff,ppdif2,ppdif3,kblnr,kblpos,grant_nbr,gmvkz,srtype,lotkz,fkber,intreno,pprct,buzid,auggj,hktid,budget_pd,pays_prov,pays_tran,mndid,_dataaging,vname,egrup,btype,propmano,gkont,gkart,ghkon from sapabap1./eon/dlfisqbsad where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_bsak","query":"select mandt,bukrs,lifnr,umsks,umskz,augdt,augbl,zuonr,gjahr,belnr,buzei,budat,bldat,cpudt,waers,xblnr,blart,monat,bschl,zumsk,shkzg,gsber,tax_country,mwskz,dmbtr,wrbtr,mwsts,wmwst,lwsts,bdiff,bdif2,sgtxt,projn,aufnr,anln1,anln2,ebeln,ebelp,saknr,hkont,fkont,filkd,zfbdt,zterm,zbd1t,zbd2t,zbd3t,zbd1p,zbd2p,skfbt,sknto,wskto,zlsch,zlspr,zbfix,hbkid,bvtyp,rebzg,rebzj,rebzz,samnr,zollt,zolld,lzbkz,landl,diekz,mansp,mschl,madat,manst,maber,xnetb,xanet,xcpdd,xesrd,xzahl,mwsk1,tax_country1,dmbt1,wrbt1,mwsk2,tax_country2,dmbt2,wrbt2,mwsk3,tax_country3,dmbt3,wrbt3,qsskz,qsshb,qbshb,bstat,anfbn,anfbj,anfbu,vbund,rebzt,stceg,egbld,eglld,qsznr,qsfbt,xinve,projk,fipos,nplnr,aufpl,aplzl,xegdr,dmbe2,dmbe3,dmb21,dmb22,dmb23,dmb31,dmb32,dmb33,mwst2,mwst3,sknt2,sknt3,bdif3,xragl,rstgr,uzawe,kostl,lnran,xstov,kzbtr,xref1,xref2,xarch,pswsl,pswbt,imkey,zekkn,fistl,geber,dabrz,xnegp,empfb,prctr,xref3,dtws1,dtws2,dtws3,dtws4,xpypr,kidno,pycur,pyamt,bupla,secco,ppdiff,ppdif2,ppdif3,penlc1,penlc2,penlc3,penfc,pendays,penrc,vertt,vertn,vbewa,kblnr,kblpos,grant_nbr,gmvkz,srtype,lotkz,zinkz,fkber,intreno,pprct,buzid,auggj,hktid,budget_pd,_dataaging,vname,egrup,btype,propmano,gkont,gkart,ghkon from sapabap1./eon/dlfisqbsak where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_bsas","query":"select mandt,bukrs,hkont,augdt,augbl,zuonr,gjahr,belnr,buzei,budat,bldat,waers,xblnr,blart,monat,bschl,shkzg,gsber,tax_country,mwskz,fkont,dmbtr,wrbtr,mwsts,wmwst,sgtxt,projn,aufnr,werks,kostl,zfbdt,xopvw,valut,bstat,bdiff,bdif2,vbund,pswsl,wverw,dmbe2,dmbe3,mwst2,mwst3,bdif3,rdif3,xragl,projk,prctr,xstov,xarch,pswbt,xnegp,rfzei,ccbtc,xref3,bupla,ppdiff,ppdif2,ppdif3,bewar,imkey,dabrz,intreno,grant_nbr,fkber,fipos,fistl,geber,pprct,buzid,auggj,uzawe,segment,psegment,pgeber,pgrant_nbr,measure,budget_pd,pbudget_pd,_dataaging,kidno,prodper,qsskz,propmano,gkont,gkart,ghkon from sapabap1./eon/dlfisqbsas where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_bseg","query":"select mandt,bukrs,belnr,gjahr,buzei,buzid,augdt,augcp,augbl,bschl,zumsk,gsber,tax_country,dmbtr,hwbas,fwbas,hwzuz,fwzuz,stekz,gbetr,bdiff,bdif2,zuonr,zinkz,altkt,fdlev,fdgrp,fdwbt,fdtag,fkont,aufnr,eten2,service_doc_type,service_doc_id,service_doc_item_id,anln1,anln2,anbwa,bzdat,hkont,filkd,gvtyp,hzuon,zfbdt,zterm,zbd1t,zbd2t,zbd3t,zbd1p,zbd2p,zlspr,zbfix,hbkid,bvtyp,tax_country1,dmbt1,tax_country2,dmbt2,tax_country3,dmbt3,zollt,zolld,diekz,abper,disbn,disbj,disbz,anfbn,anfbj,anfbu,anfae,blnbt,blnkz,blnpz,esrnr,esrre,esrpz,erfmg,erfme,bpmng,bprme,ebeln_logsys,ebeln,ebelp,zekkn,elikz,bwkey,bwtar,bustw,bonfb,bualt,egbld,eglld,vname,recid,egrup,vptnr,imkey,dabrz,fipos,aufpl,aplzl,btype,etype,hrkft,dmbe2,dmbe3,dmb21,dmb22,dmb23,dmb31,dmb32,dmb33,bdif3,hwmet,glupm,lokkt,fistl,geber,kblnr,kblpos,fkber,ccbtc,empfb,dtws1,dtws2,dtws3,dtws4,gricd,gityp,absbt,idxsp,linfv,agzei,bupla,cession_kz,prznr,grant_nbr,fkber_long,gmvkz,srtype,measure,auggj,ppa_ex_ind,docln,segment,psegment,hktid,pays_prov,pays_tran,awtyp,awkey,awsys,buzei_sender,h_bstat,h_budat,h_bldat,h_blart,h_hwaer,h_hwae2,h_hwae3,prctr_drvtn_source_type,_dataaging,fqftype,lqitem,gkont,gkart,ghkon,anln2_pn,bwasl_pn,bzdat_pn,anbtr_pn,acrobjtype,acrlogsys,acrobj_id,acrsobj_id,acritmtype,acrvaldat,sdm_version,glo_ref1,re_bukrs,re_account,pgeber,pgrant_nbr,budget_pd,pbudget_pd,j_1tpbupl,perop_beg,perop_end,fastpay,ignr_ivref,fmfgus_key,fmxdocnr,fmxyear,fmxdocln,fmxzekkn,prodper,gst_part,plc_sup,hsn_sac,recrf from sapabap1./eon/dlfisqbseg where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_bset","query":"select mandt,bukrs,belnr,gjahr,buzei,tax_country,mwskz,txdat_from,hkont,txgrp,shkzg,hwbas,fwbas,hwste,fwste,ktosl,knumh,stceg,egbld,eglld,txjcd,h2ste,h3ste,h2bas,h3bas,kschl,stmdt,stmti,mlddt,kbetr,stbkz,lstml,lwste,lwbas,txdat,bupla,txjdp,txjlv,taxps,txmod,_dataaging from sapabap1./eon/dlfisqbset where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_bsid","query":"select mandt,bukrs,kunnr,umsks,umskz,augdt,augbl,zuonr,gjahr,belnr,buzei,budat,bldat,cpudt,waers,xblnr,blart,monat,bschl,zumsk,shkzg,gsber,tax_country,mwskz,dmbtr,wrbtr,mwsts,wmwst,lwsts,bdiff,bdif2,sgtxt,projn,aufnr,anln1,anln2,saknr,hkont,fkont,filkd,zfbdt,zterm,zbd1t,zbd2t,zbd3t,zbd1p,zbd2p,skfbt,sknto,wskto,zlsch,zlspr,zbfix,hbkid,bvtyp,rebzg,rebzj,rebzz,samnr,anfbn,anfbj,anfbu,anfae,mansp,mschl,madat,manst,maber,xnetb,xanet,xcpdd,xinve,xzahl,mwsk1,tax_country1,dmbt1,wrbt1,mwsk2,tax_country2,dmbt2,wrbt2,mwsk3,tax_country3,dmbt3,wrbt3,bstat,vbund,vbeln,rebzt,stceg,egbld,eglld,rstgr,vertt,vertn,vbewa,wverw,projk,fipos,nplnr,aufpl,aplzl,xegdr,dmbe2,dmbe3,dmb21,dmb22,dmb23,dmb31,dmb32,dmb33,bdif3,xragl,uzawe,xstov,mwst2,mwst3,sknt2,sknt3,xref1,xref2,pswsl,pswbt,lzbkz,landl,imkey,vbel2,posn2,eten2,fistl,geber,dabrz,xnegp,kostl,rfzei,kkber,empfb,prctr,xref3,qsskz,zinkz,dtws1,dtws2,dtws3,dtws4,xpypr,kidno,absbt,ccbtc,pycur,pyamt,bupla,secco,cession_kz,ppdiff,ppdif2,ppdif3,kblnr,kblpos,grant_nbr,gmvkz,srtype,lotkz,fkber,intreno,pprct,buzid,auggj,hktid,budget_pd,bdgt_account,re_account,pays_prov,pays_tran,mndid,_dataaging,kontt,kontl,vname,egrup,btype,propmano,gkont,gkart,ghkon,awtyp,logsystem_sender,bukrs_sender,belnr_sender,gjahr_sender,buzei_sender from sapabap1./eon/dlfisqbsid where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_bsik","query":"select mandt,bukrs,lifnr,umsks,umskz,augdt,augbl,zuonr,gjahr,belnr,buzei,budat,bldat,cpudt,waers,xblnr,blart,monat,bschl,zumsk,shkzg,gsber,tax_country,mwskz,dmbtr,wrbtr,mwsts,wmwst,lwsts,bdiff,bdif2,sgtxt,projn,aufnr,anln1,anln2,ebeln,ebelp,saknr,hkont,fkont,filkd,zfbdt,zterm,zbd1t,zbd2t,zbd3t,zbd1p,zbd2p,skfbt,sknto,wskto,zlsch,zlspr,zbfix,hbkid,bvtyp,rebzg,rebzj,rebzz,samnr,zollt,zolld,lzbkz,landl,diekz,mansp,mschl,madat,manst,maber,xnetb,xanet,xcpdd,xzahl,mwsk1,tax_country1,dmbt1,wrbt1,mwsk2,tax_country2,dmbt2,wrbt2,mwsk3,tax_country3,dmbt3,wrbt3,qsskz,qsshb,qbshb,bstat,anfbn,anfbj,anfbu,vbund,rebzt,stceg,egbld,eglld,qsznr,qsfbt,xinve,projk,fipos,nplnr,aufpl,aplzl,xegdr,dmbe2,dmbe3,dmb21,dmb22,dmb23,dmb31,dmb32,dmb33,mwst2,mwst3,sknt2,sknt3,bdif3,xragl,rstgr,uzawe,kostl,lnran,xstov,kzbtr,xref1,xref2,pswsl,pswbt,imkey,zekkn,fistl,geber,dabrz,xnegp,empfb,prctr,xref3,dtws1,dtws2,dtws3,dtws4,xpypr,kidno,pycur,pyamt,bupla,secco,ppdiff,ppdif2,ppdif3,penlc1,penlc2,penlc3,penfc,pendays,penrc,vertt,vertn,vbewa,kblnr,kblpos,grant_nbr,gmvkz,srtype,lotkz,zinkz,fkber,intreno,pprct,buzid,auggj,hktid,budget_pd,bdgt_account,re_account,_dataaging,kontt,kontl,vname,egrup,btype,propmano,gkont,gkart,ghkon,pernr,vorgn,awtyp,logsystem_sender,bukrs_sender,belnr_sender,gjahr_sender,buzei_sender from sapabap1./eon/dlfisqbsik where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_bsis","query":"select mandt,bukrs,hkont,augdt,augbl,zuonr,gjahr,belnr,buzei,budat,bldat,waers,xblnr,blart,monat,bschl,shkzg,gsber,tax_country,mwskz,fkont,dmbtr,wrbtr,mwsts,wmwst,sgtxt,projn,aufnr,werks,kostl,zfbdt,xopvw,valut,bstat,bdiff,bdif2,vbund,pswsl,wverw,dmbe2,dmbe3,mwst2,mwst3,bdif3,rdif3,xragl,projk,prctr,xstov,xarch,pswbt,xnegp,rfzei,ccbtc,xref3,bupla,ppdiff,ppdif2,ppdif3,bewar,imkey,dabrz,intreno,grant_nbr,fkber,fipos,fistl,geber,pprct,buzid,auggj,uzawe,segment,psegment,pgeber,pgrant_nbr,measure,budget_pd,pbudget_pd,_dataaging,kidno,prodper,qsskz,propmano,gkont,gkart,ghkon from sapabap1./eon/dlfisqbsis where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_bvor","query":"select mandt,bvorg,bukrs,gjahr,belnr,xarch,_dataaging from sapabap1./eon/dlfisqbvor where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_setheader","query":"select mandt,setclass,subclass,setname,settype,xdynamic,authgr,xuniq,rvalue,creuser,credate,cretime,upduser,upddate,updtime,saprl,tabname,fieldname,rollname,set_olangu,no_rwsheader,no_rwsline,no_setlinet from sapabap1./eon/dlfisqsethd where mandt = '200'"},{"tablename":"/eon/dlfi_v_setleaf","query":"select mandt,setclass,subclass,setname,lineid,valsign,valoption,valfrom,valto,seqnr from sapabap1./eon/dlfisqsetlf where mandt = '200'"},{"tablename":"/eon/dlfi_v_ska1","query":"select mandt,/eon/attr_con,/eon/attr_per,/eon/inc_type,/eon/investa,/eon/maturity,/eon/move_type,/eon/partnera,/eon/tran_type,bilkt,erdat,ernam,func_area,glaccount_subtype,glaccount_type,gvtyp,ktoks,ktopl,last_changed_ts,main_saknr,mcod1,mustr,sakan,saknr,vbund,xbilk,xloev,xspea,xspeb,xspep from sapabap1./eon/dlfisqska1 where ktopl = 'ecoa' and mandt = '200'"},{"tablename":"/eon/dlfi_v_skat","query":"select mandt,ktopl,last_changed_ts,mcod1,saknr,spras,txt20,txt50 from sapabap1./eon/dlfisqskat where ktopl = 'ecoa' and mandt = '200'"},{"tablename":"/eon/dlfi_v_skb1","query":"select mandt,altkt,begru,bewgp,bukrs,busab,cochanged,datlz,erdat,ernam,fdgrv,fdlev,fipls,fipos,fstag,hbkid,hktid,infky,kdfsl,last_changed_ts,mcakey,mitkz,mwskz,recid,saknr,stext,togru,vzskz,waers,wmeth,x_uj_clr,xgkon,xintb,xkres,xlgclr,xloeb,xmitk,xmwno,xnkon,xopvw,xsalh,xspeb,zindt,zinrt,zuawa from sapabap1./eon/dlfisqskb1 where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlfi_v_t001","query":"select mandt,bukrs,butxt,ort01,land1,waers,spras,ktopl,waabw,periv,kokfi,rcomp,adrnr,stceg,fikrs,xfmco,xfmcb,xfmca,txjcd,fmhrdate,xtemplt,buvar,fdbuk,xfdis,xvalv,xskfn,kkber,xmwsn,mregl,xgsbe,xgjrv,xkdft,xprod,xeink,xjvaa,xvvwa,xslta,xfdmm,xfdsd,xextb,ebukr,ktop2,umkrs,bukrs_glob,fstva,opvar,xcovr,txkrs,wfvar,xbbbf,xbbbe,xbbba,xbbko,xstdt,mwskv,mwska,impda,xnegp,xkkbi,wt_newwt,pp_pdate,infmt,fstvare,kopim,dkweg,offsacct,bapovar,xcos,xcession,xsplt,surccm,dtprov,dtamtc,dttaxc,dttdsp,dtaxr,xvatdate,pst_per_var,xbbsc,f_obsolete,fm_derive_acc from sapabap1./eon/dlfisqt001 where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dllo_v_knb1","query":"select mandt,kunnr,bukrs,pernr,knb1_eew_cc,erdat,ernam,sperr,loevm,zuawa,busab,akont,begru,knrze,knrzb,zamim,zamiv,zamir,zamib,zamio,zwels,xverr,zahls,zterm,wakon,vzskz,zindt,zinrt,eikto,zsabe,kverm,fdgrv,vrbkz,vlibb,vrszl,vrspr,vrsnr,verdt,perkz,xdezv,xausz,webtr,remit,datlz,xzver,togru,kultg,hbkid,xpore,blnkz,altkn,zgrup,urlid,mgrup,lockb,uzawe,ekvbd,sregl,xedip,frgrp,vrsdg,tlfxs,intad,xknzb,guzte,gricd,gridt,wbrsl,confs,updat,uptim,nodel,tlfns,cession_kz,avsnd,ad_hash,qland,cvp_xblck_b,ciiucode,/eon/avimail,gmvkzd from sapabap1./eon/dllosqknb1 where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dllo_v_knvp","query":"select mandt,kunnr,vkorg,vtweg,spart,parvw,parza,kunn2,lifnr,pernr,parnr,knref,defpa from sapabap1./eon/dllosqknvp where mandt = '200'"},{"tablename":"/eon/dllo_v_lfa1_1","query":"select mandt,lifnr,land1,name1,name2,name3,name4,ort01,ort02,pfach,pstl2,pstlz,regio,sortl,stras,adrnr,mcod1,mcod2,mcod3,anred,bahns,bbbnr,bbsnr,begru,brsch,bubkz,datlt,dtams,dtaws,erdat,ernam,esrnr,konzs,ktokk,kunnr,lnrza,loevm,sperr,sperm,spras,stcd1,stcd2,stkza,stkzu,telbx,telf1,telf2,telfx,teltx,telx1,xcpdk,xzemp,vbund,fiskn,stceg,stkzn,sperq,gbort,gbdat,sexkz,kraus,revdb,qssys,ktock,pfort,werks,ltsna,werkr,plkal,duefl,txjcd,sperz,scacd,sfrgr,lzone,xlfza,dlgrp,fityp,stcdt,regss,actss,stcd3,stcd4,stcd5,stcd6,ipisp,taxbs,profs,stgdl,emnfr,lfurl,j_1kfrepre,j_1kftbus,j_1kftind,confs,updat,uptim,nodel,qssysdat,podkzb,fisku,stenr,carrier_conf,min_comp,term_li,crc_num,cvp_xblck,weora,rg,exp,uf,rgdate,ric,rne,rnedate,cnae,legalnat,crtn,icmstaxpay,indtyp,tdt,comsize,decregpc,allowance_type,lfa1_eew_supp,j_sc_capital,j_sc_currency,alc,pmt_office,ppa_relevant,psofg,psois,pson1,pson2,pson3,psovn,psotl,psohs,psost,borgr_datun,borgr_yeaun,au_carrying_ent,au_ind_under_18,au_payment_not_exceed_75,au_wholly_inp_taxed,au_partner_without_gain,au_not_entitled_abn,au_payment_exempt,au_private_hobby,au_domestic_nature,addr2_street,addr2_house_num,addr2_post,addr2_city,addr2_country,categ,partner_name,partner_utr,status,vfnum,vfnid,j_1iexcd,j_1iexrn,j_1iexrg,j_1iexdi,j_1iexco,j_1icstno,j_1ilstno,j_1ipanno,j_1iexcive,j_1issist,j_1ivtyp,j_1ivencre,aedat,usnam,j_1isern,j_1ipanref,j_1ipanvaldt,j_1i_customs,j_1idedref,ven_class,entpub,escrit,dvalss,frmcss,codcae,ausdiv,transport_chain,staging_time,scheduling_type,submi_relevant,zzamsst from sapabap1./eon/dllosqlfa1 where mandt = '200'"},{"tablename":"/eon/dllo_v_lfb1","query":"select mandt,lifnr,bukrs,pernr,erdat,ernam,sperr,loevm,zuawa,akont,begru,vzskz,zwels,xverr,zahls,zterm,eikto,zsabe,kverm,fdgrv,busab,lnrze,lnrzb,zindt,zinrt,datlz,xdezv,webtr,kultg,reprf,togru,hbkid,xpore,qsznr,qszdt,qsskz,blnkz,mindk,altkn,zgrup,mgrup,uzawe,qsrec,qsbgr,qland,xedip,frgrp,togrr,tlfxs,intad,xlfzb,guzte,gricd,gridt,xausz,cerdt,confs,updat,uptim,nodel,tlfns,avsnd,ad_hash,cvp_xblck_b,ciiucode,paymentclearinggrpid,paytrsn,lfb1_eew_cc,zbokd,zqsskz,zqszdt,zqsznr,zmindat,j_sc_subcontype,j_sc_compdate,j_sc_offsm,j_sc_offsr,basis_pnt,gmvkzk,brsch,wrbtr,waers,forgn,notes,active,us_rec_country,us_rec_dob,us_w8_recvdate,us_w9_recvdate,us_tin_notice,us_partnership_ind,us_fatca_ind,prepay_relevant,assign_test from sapabap1./eon/dllosqlfb1 where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlmm_v_eban","query":"select mandt,banfn,bnfpo,bukrs,bsart,bstyp,bsakz,loekz,statu,estkz,frgkz,frgzu,frgst,ekgrp,ernam,erdat,afnam,txz01,matnr,ematn,werks,lgort,bednr,matkl,reswk,menge,meins,bumng,badat,lpein,lfdat,frgdt,webaz,preis,peinh,pstyp,knttp,kzvbr,kflag,vrtkz,twrkz,wepos,weunb,repos,lifnr,flief,ekorg,vrtyp,konnr,ktpnr,infnr,zugba,qunum,qupos,dispo,sernr,bvdat,batol,bvdrk,ebeln,ebelp,bedat,bsmng,lblni,bwtar,xoblr,ebakz,rsnum,sobkz,arsnr,arsps,fixkz,bmein,revlv,vorab,packno,kanba,bpueb,cuobj,frggr,frgrl,aktnr,charg,umsok,verid,fipos,fistl,geber,kzkfg,satnr,mng02,dat01,attyp,adrnr,adrn2,kunnr,emlif,lblkz,kzbws,waers,idnlf,gsfrg,mprof,kzfme,spras,techs,mfrpn,mfrnr,emnfr,fordn,fordp,plifz,berid,uzeit,fkber,grant_nbr,memory,banpr,rlwrt,blckd,revno,blckt,beswk,eprofile,eprefdoc,eprefitm,gmmng,wrtkz,reslo,kblnr,kblpos,prio_urg,prio_req,memorytype,anzsn,mhdrz,iprkz,nodisp,srm_contract_id,srm_contract_itm,budget_pd,eldat,expert_mode,central_purreqn_proc,spe_crm_ref_so,spe_crm_ref_item,dummy_eban_incl_eew_ps,/eon/bname,/eon/hseri,/eon/dprot,/eon/dummy,storenetworkid,storesupplierid,creationdate,creationtime,producttype,serviceperformer,iseopblocked,ext_rev_tmstmp,fmfgus_key,startdate,enddate,extmaterialforpurg,extfixedsupplierforpurg,extdesiredsupplierforpurg,extcontractforpurg,extcontractitemforpurg,extinforecordforpurg,extplantforpurg,extcompanycodeforpurg,extpurgorgforpurg,ext_be_prchangeindicator,extdoctypeforpurg,extapprovalstatus,purchasereqnitemuniqueid,lastchangedatetime,isonbehalfcart,sdm_version,sakto,kostl,expected_value,limit_amount,isoutline,parent_item_no,outline_type,advcode,stacode,banfn_cs,bnfpo_cs,item_cs,bsmng_snd,no_mard_data,admoi,adpri,lprio,adacn,addns,serru,disub_sobkz,disub_pspnr,disub_kunnr,disub_vbeln,disub_posnr,disub_owner,fldlogssupplyprocess,fldlogsdelivisheldonshore,fsh_season_year,fsh_season,fsh_collection,fsh_theme,fsh_vas_rel,fsh_vas_prnt_id,fsh_transaction,fsh_item_group,fsh_item,iuid_relevant,sc_catalogid,sc_author,sgt_scat,sgt_rcat,wrf_charstc1,wrf_charstc2,wrf_charstc3 from sapabap1./eon/dlmmsqeban where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlmm_v_ekko","query":"select mandt,ebeln,bukrs,bstyp,bsart,bsakz,loekz,statu,aedat,ernam,lastchangedatetime,pincr,lponr,lifnr,spras,zterm,zbd1t,zbd2t,zbd3t,zbd1p,zbd2p,ekorg,ekgrp,waers,wkurs,kufix,bedat,kdatb,kdate,bwbdt,angdt,bnddt,gwldt,ausnr,angnr,ihran,ihrez,verkf,telf1,llief,kunnr,active_id,konnr,abgru,autlf,weakt,reswk,lblif,inco1,inco2,ktwrt,distributiontype,submi,knumv,kalsm,stafo,lifre,exnum,unsez,logsy,upinc,stako,frggr,frgsx,frgke,frgzu,frgrl,lands,lphis,adrnr,stceg_l,stceg,absgr,addnr,kornr,memory,procstat,process_indicator,rlwrt,cr_stat,revno,scmproc,reason_code,memorytype,rettp,retpc,dptyp,dppct,dpamt,dpdat,msr_id,hierarchy_exists,grouping_id,parent_id,threshold_exists,legal_contract,description,release_date,vsart,handoverloc,shipcond,incov,inco2_l,inco3_l,grwcu,intra_rel,intra_excl,qtn_erlst_submsn_date,followon_doc_cat,followon_doc_type,dummy_ekko_incl_eew_ps,/eon/uex_relevant,externalsystem,externalreferenceid,ext_rev_tmstmp,iseopblocked,isaged,force_id,force_cnt,reloc_id,reloc_seq_id,source_logsys,fsh_transaction,fsh_item_group,fsh_vas_last_item,fsh_os_stg_change,tms_ref_uuid,/eon/vgkri,/eon/vsana,/eon/vsanv,/eon/anzan,/eon/strfx,/eon/abgrz,/eon/envid,zapcgk,apcgk_extend,zbas_date,zadattyp,zstart_dat,z_dev,zindanx,zlimit_dat,numerator,hashcal_bdat,hashcal,negative,hashcal_exists,known_index,postat,vzskz,fsh_snst_status,proce,conc,cont,comp,outr,desp,desp_dat,desp_cargo,pare,pare_dat,pare_cargo,pfm_contract,pohf_type,eq_eindt,eq_werks,fixpo,ekgrp_allow,werks_allow,contract_allow,pstyp_allow,fixpo_allow,key_id_allow,aurel_allow,delper_allow,eindt_allow,ltsnr_allow,otb_level,otb_cond_type,key_id,otb_value,otb_curr,otb_res_value,otb_spec_value,spr_rsn_profile,budg_type,otb_status,otb_reason,check_type,con_otb_req,con_prebook_lev,con_distr_lev from sapabap1./eon/dlmmsqekko where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlmm_v_ekpo","query":null},{"tablename":"/eon/dlsd_v_vbak","query":"select vbeln,erdat,erzet,ernam,angdt,bnddt,audat,vbtyp,trvog,auart,augru,gwldt,submi,lifsk,faksk,netwr,waerk,vkorg,vtweg,spart,vkgrp,vkbur,gsber,gskst,guebg,gueen,knumv,vdatu,delivery_date_type_rule,vprgr,autlf,vbkla,vbklt,kalsm,vsbed,fkara,awahr,ktext,bstnk,bsark,bstdk,bstzd,ihrez,bname,telf1,mahza,mahdt,kunnr,kostl,stafo,stwae,aedat,kvgr1,kvgr2,kvgr3,kvgr4,kvgr5,knuma,kokrs,ps_psp_pnr,kurst,kkber,knkli,grupp,sbgrp,ctlpc,cmwae,cmfre,cmnup,cmngv,amtbl,hityp_pr,abrvw,abdis,vgbel,objnr,bukrs_vf,taxk1,taxk2,taxk3,taxk4,taxk5,taxk6,taxk7,taxk8,taxk9,xblnr,zuonr,vgtyp,kalsm_ch,agrzr,aufnr,qmnum,vbeln_grp,scheme_grp,abruf_part,abhod,abhov,abhob,rplnr,vzeit,stceg_l,landtx,xegdr,enqueue_grp,dat_fzau,fmbdat,vsnmr_v,handle,proli,cont_dg,crm_guid,upd_tmstmp,msr_id,oipbl,last_changed_by_user,handoverloc,ext_bus_syst_id,ext_ref_doc_id,ext_rev_tmstmp,apm_approval_status,apm_approval_reason,apm_rejection_reason,solution_order_id,ext_comm_syst_type,retro_purchdoc_creation,crossitem_prc_date,_dataaging,abstk,bestk,cmpsc,cmpsd,cmpsi,cmpsj,cmpsk,cmps_cm,cmps_te,cmgst,costa,dcstk,fksak,fmstk,fsstk,gbstk,lfgsk,lfstk,lsstk,manek,rfgsk,rfstk,spstg,trsta,uvall,uvals,uvfak,uvfas,uvprs,uvvlk,uvvls,uvk01,uvk02,uvk03,uvk04,uvk05,uvs01,uvs02,uvs03,uvs04,uvs05,wbstk,total_emcst,total_slcst,total_lccst,total_pcsta,total_dgsta,total_sdssta,bob_status,dp_clear_sta_hdr,b2b_msg_processing_status,total_deliv_reltd_billg_sta,sdm_version,dummy_salesdoc_incl_eew_ps,/igy/sdsf_qnum,glo_log_ref1_hd,/dmbe/dealnumber,/dmbe/evgidrenewal,/dmbe/evgidcancel,/eon/itcig,/eon/itcup,/eon/conv_num,/eon/conv_date,/eon/rec_num,/eon/rec_date,/eon/agr,/eon/doc_date,/eon/doc_id,zapcgkh,apcgk_extendh,zabdath,ad01fareg,ad01basdoc,lastvchr,psm_budat,fsh_kvgr6,fsh_kvgr7,fsh_kvgr8,fsh_kvgr9,fsh_kvgr10,fsh_rereg,fsh_cq_check,fsh_vrsn_status,fsh_transaction,fsh_vas_cg,fsh_candate,fsh_ss,fsh_os_stg_change,j_3gkbaul,mill_appl_id,tas,betc,mod_allow,cancel_allow,pay_method,bpn,rep_freq,logsysb,kalcd,multi,sppaym,wtysc_clm_hdr,mandt from sapabap1./eon/dlsdsqvbak where kokrs = '102n' and mandt = '200'"},{"tablename":"/eon/dlsd_v_vbap","query":null},{"tablename":"/eon/dlsd_v_vbfa","query":"select mandt,ruuid,vbelv,posnv,vbeln,posnn,vbtyp_n,rfmng,meins,rfwrt,waers,vbtyp_v,plmin,taqui,erdat,erzet,matnr,bwart,bdart,plart,lgnum,aedat,fktyp,brgew,gewei,volum,voleh,fplnr,fpltr,rfmng_flo,rfmng_flt,vrkme,abges,sobkz,sonum,kzbef,ntgew,logsys,wbsta,cmeth,mjahr,stufe,_dataaging from sapabap1./eon/dlsdsqvbfa where mandt = '200'"},{"tablename":"/eon/dlsd_v_vbrk","query":"select mandt,vbeln,fkart,fktyp,vbtyp,waerk,vkorg,vtweg,kalsm,knumv,vsbed,fkdat,belnr,gjahr,poper,konda,kdgrp,bzirk,pltyp,inco1,inco2,rfbsk,mrnkz,kurrf,cpkur,valtg,valdt,zterm,zlsch,ktgrd,land1,regio,counc,cityc,bukrs,taxk1,taxk2,taxk3,taxk4,taxk5,taxk6,taxk7,taxk8,taxk9,netwr,zukri,ernam,erzet,erdat,stafo,kunrg,kunag,maber,stwae,stceg,aedat,sfakn,knuma,fkart_rl,fkdat_rl,kurst,mschl,mansp,spart,kkber,knkli,cmwae,cmkuf,hityp_pr,bstnk_vf,vbund,fkart_ab,kappl,landtx,stceg_h,stceg_l,xblnr,zuonr,mwsbk,logsys,fksto,xegdr,rplnr,j_1afitp,kurrf_dat,kidno,bvtyp,numpg,bupla,vkont,fkk_docstat,nrzas,spe_billing_ind,vtref,fk_source_sys,fktyp_crm,stgrd,changed_on,expkz,exnum,akwae,akkur,lcnum,_dataaging,buchk,gbstk,relik,uvals,uvprs,clrst,fksak,fkara,vf_status,vf_todo,bdr_status,bdr_ref,bdr_ref_logsys,bdr_ref_vbtyp,pbd_status,abstk,draft,activedocument,grwcu,blart,intra_rel,intra_excl,accrrel,pspsd,apm_approval_status,apm_approval_reason,srcedoc_ext_comm_syst_type,ico_lifnr,j_1tpbupl,incov,inco2_l,inco3_l,sdm_version,dummy_billingdoc_incl_eew_ps,glo_log_ref1_hd,zapcgkh,apcgk_extendh,zabdath,dpc_rel,ad01basdoc,ad01fareg,vchrnmbr,j_3gkbaul,j_3gkenie,kunwe,mndid,pay_type,sepon,mndvg,sppaym,sppord from sapabap1./eon/dlsdsqvbrk where bukrs = '2200' and mandt = '200'"},{"tablename":"/eon/dlsd_v_vbrp","query":"select vbeln,posnr,uepos,fkimg,vrkme,umvkz,umvkn,meins,smeng,fklmg,lmeng,ntgew,brgew,gewei,volum,voleh,gsber,prsdt,fbuda,kursk,netwr,vbelv,posnv,vgbel,vgpos,vgtyp,aubel,aupos,auref,matnr,arktx,pmatn,charg,matkl,pstyv,posar,prodh,vstel,atpkz,spart,pospa,werks,aland,wkreg,wkcou,wkcty,taxm1,taxm2,taxm3,taxm4,taxm5,taxm6,taxm7,taxm8,taxm9,kowrr,prsfd,sktof,skfbp,kondm,ktgrm,kostl,bonus,provg,eannr,vkgrp,vkbur,spara,shkzg,ernam,erdat,erzet,bwtar,lgort,stafo,wavwr,kzwi1,kzwi2,kzwi3,kzwi4,kzwi5,kzwi6,stcur,uvprs,uvall,ean11,prctr,kvgr1,kvgr2,kvgr3,kvgr4,kvgr5,mvgr1,mvgr2,mvgr3,mvgr4,mvgr5,matwa,bonba,kokrs,paobjnr,ps_psp_pnr,aufnr,txjcd,cmpre,cmpnt,cuobj,cuobj_ch,koupd,uecha,xchar,abrvw,sernr,bzirk_auft,kdgrp_auft,konda_auft,lland_auft,mprok,pltyp_auft,regio_auft,vkorg_auft,vtweg_auft,abrbg,prosa,uepvw,autyp,stadat,fplnr,fpltr,aktnr,knuma_pi,knuma_ag,mwsbp,augru_auft,fareg,upmat,ukonm,cmpre_flt,abfor,abges,j_1arfz,j_1aregio,j_1agicd,j_1adtyp,j_1atxrel,j_1bcfop,j_1btaxlw1,j_1btaxlw2,j_1btxsdc,brtwr,wktnr,wktps,rplnr,kursk_dat,wgru1,wgru2,kdkg1,kdkg2,kdkg3,kdkg4,kdkg5,vkaus,j_1aindxp,j_1aidatep,kzfme,mwskz,vertt,vertn,sgtxt,delco,bemot,rrrel,wminr,vgbel_ex,vgpos_ex,logsys,vgtyp_ex,j_1btaxlw3,j_1btaxlw4,j_1btaxlw5,msr_id,msr_refund_code,msr_ret_reason,nrab_knumh,nrab_value,dispute_case,fund_usage_item,farr_reltype,claims_taxation,kurrf_dat_orig,sgt_rcat,sgt_scat,prefe,akkur,waerk,draft,activedocument,grwrt,fksaa,absta,abgru,mwsk1,pbd_id,pbd_item_id,cats_overtime_category,contr_dp_settl,prodh_univ_sales_parnt_nodid,transit_plant,vcm_chain_category,vcm_chain_uuid,reason_code,_dataaging,spe_herkl,spe_herkr,itm_comco,vtkey,vtpos,srcdoc_process_type,t2ccode_crcy_conv_factor,t2cntry_crcy_conv_factor,dummy_billgdocitem_incl_eew_ps,service_doc_type,service_doc_id,service_doc_item_id,solution_order_id,solution_order_item_id,/cwm/menge,/cwm/meins,vbtyp_ana,fkart_ana,vkorg_ana,vtweg_ana,konda_ana,kdgrp_ana,land1_ana,regio_ana,cityc_ana,bzirk_ana,gbstk_ana,vf_status_ana,kunag_ana,kunrg_ana,fkdat_ana,bukrs_ana,counc_ana,knuma_ana,fktyp_ana,knumv_ana,sfakn_ana,kunwe_ana,kunre_ana,perve_ana,perzm_ana,glo_log_ref1_it,txs_business_transaction,txs_usage_purpose,zapcgki,apcgk_extendi,zabdati,aufpl,aplzl,dpcnr,dcpnr,dpnrb,bosfar,dp_belnr,dp_bukrs,dp_gjahr,dp_buzei,packno,perop_beg,perop_end,fmfgus_key,fsh_season_year,fsh_season,fsh_collection,fsh_theme,fonds,fistl,fkber,grant_nbr,budget_pd,j_3gbelnri,j_3gpmaufe,j_3gpmaufv,j_3getypa,j_3getype,j_3gorgueb,prs_work_period,pprctr,pargb,aufpl_oaa,aplzl_oaa,campaign,compreas,wrf_charstc1,wrf_charstc2,wrf_charstc3,mandt from sapabap1./eon/dlsdsqvbrp where kokrs = '102n' and  = '200'"}]

# COMMAND ----------

def unbundling_criteria(json_metadata):
    erwin_Unbundling='200' if json_metadata.select(explode("extendedProperties").alias("x"))\
            .select("x.value").filter(col("x.key").like("%EDH - Unbundling%") & col("x.value")=='Regulated') else '100'
    return erwin_Unbundling

# COMMAND ----------

# query_json=handling_null_values(query_json)

# mandtCount=0
# unbundlingCount=0
# tables_missing_mandt=[]
# tables_with_incorrect_unbundling=[]
# tables_without_query=[]
# for tableInfo in query_json:
    
#     if tableInfo['query']!='' and tableInfo['query'].find('where')>0:
#         if tableInfo['query'].split('where')[1].find('mandt') or tableInfo['query'].split('where')[1].find('rclnt'):
#             mandtCount=mandtCount+1
#         else:
#             tables_missing_mandt.append(tableInfo['tablename'])
#         if tableInfo['query'].split('where')[1].find('erwin_Unbundling'):
#             unbundlingCount=unbundlingCount+1
#         else:
#             tables_with_incorrect_unbundling.append(tableInfo['tablename'])
#     else:
#         tables_without_query.append(tableInfo['tablename'])

# if len(tables_missing_mandt)>0:
#     print(f'{len(tables_missing_mandt)} tables are missing MANDT in the query')
# elif len(tables_with_incorrect_unbundling)>0:
#     print(f'{len(tables_with_incorrect_unbundling)} tables have incorrect Unbundling in the query')
# elif len(tables_without_query)>0:
#     print(f'{tables_without_query} has no query from the {len(query_json)} tables')
# else:
#     print(f'{mandtCount} tables have MANDT in the query')
   

# COMMAND ----------

tables_missing_mandt

# COMMAND ----------

def unbundling_validation(query_json: Generator[Dict[str, Any], None, None], payload_json: Generator[Dict[str, Any], None, None],logger: DBFSLogger):

    json_metadata_path=get_erwin_json_path(payload_json)
    json_metadata=spark.read.json(json_metadata_path)
    try:
        #table level erwin
        exploded_erwin_dF = json_metadata.withColumn('tables_f',explode(col('tables'))).drop('tables')  #.select("t.tableDefinition")
        #erwin at column levels 
        exploded_erwin_tables_with_MANDT=exploded_erwin_dF.select("tables_f.columns", "tables_f.tableDefinition").select(explode("columns").alias("x"),"tableDefinition")\
                .select("tableDefinition","x.tableName","x.foreignKeyTableName").filter(col("x.foreignKeyTableName").contains("MANDT"))
        
        # table_ls_with_MANDT=exploded_erwin_tables_with_MANDT.select("tableDefinition").collect()
        # table_ls_with_MANDT=[x['tableDefinition'].lower() for x in table_ls_with_MANDT]
        table_ls_with_MANDT=exploded_erwin_tables_with_MANDT.select("tableName").collect()
        table_ls_with_MANDT=[x['tableName'].lower() for x in table_ls_with_MANDT]
        tablesCount=0
        erwin_Unbundling=unbundling_criteria(json_metadata)
        
        mandtCount=0
        unbundlingCount=0
        tables_missing_mandt=[]
        tables_with_incorrect_unbundling=[]
        tables_without_query=[]
        for tableInfo in query_json:
            
            if tableInfo['query']!='' and tableInfo['query'].find('where')>0:
                if tableInfo['query'].split('where')[1].find('mandt') or tableInfo['query'].split('where')[1].find('rclnt'):
                    mandtCount=mandtCount+1
                else:
                    tables_missing_mandt.append(tableInfo['tablename'])
                if tableInfo['query'].split('where')[1].find('erwin_Unbundling'):
                    unbundlingCount=unbundlingCount+1
                else:
                    tables_with_incorrect_unbundling.append(tableInfo['tablename'])
            else:
                tables_without_query.append(tableInfo['tablename'])

        if len(tables_missing_mandt)>0:
            logger.error(f'{len(tables_missing_mandt)} tables are missing MANDT in the query')
        elif len(tables_with_incorrect_unbundling)>0:
            logger.error(f'{len(tables_with_incorrect_unbundling)} tables have incorrect Unbundling in the query')
        elif len(tables_without_query)>0:
            logger.error(f'{tables_without_query} has no query from the {len(query_json)} tables')
        else:
            logger.info(f'{mandtCount} tables have MANDT in the query')

    except Exception as e:
        logger.error(f'Error in unbundling check: {e}')

# COMMAND ----------

unbundling_validation(query_json, payload_json,logger)

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC FILTer criteria valiation

# COMMAND ----------



# erwin_dso_type=json_metadata.select(explode("extendedProperties").alias("x")).select("x.value").filter(col("x.key").like("%EDH DSO Filter Criteria%"))
# erwin_filter_criteria=json_metadata.select(explode("extendedProperties").alias("x"))\
#             .select("x.value").filter(col("x.key").like("%Source Company Code%")) if erwin_dso_type=="%Multi-DSO%" else "No filter required"

# display(erwin_filter_criteria)
# display(erwin_dso_type)

# COMMAND ----------

def get_json_metadata(payload_json):
    json_metadata_path=get_erwin_json_path(payload_json)
    json_metadata=read_json_df(json_metadata_path)
    return json_metadata

# json_metadata=json_metadata(payload_json)


# COMMAND ----------

json_metadata=get_json_metadata(payload_json)

# COMMAND ----------

json_metadata

# COMMAND ----------

def get_erwin_dso_type(payload_json):
    json_metadata=get_json_metadata(payload_json)
    erwin_dso_type=json_metadata.select(explode("extendedProperties").alias("x")).select("x.value").filter(col("x.key").like("%EDH DSO Filter Criteria%"))
    
    return str(erwin_dso_type.collect()[0][0])
# erwin_dso_type=get_erwin_dso_type(payload_json)
# display(erwin_dso_type)

# COMMAND ----------

# def exploded_erwin_tables_with_filter(json_metadata_df):
#     exploded_erwin_tables_with_filter=exploded_erwin_dF.select("tables_f.columns",col("tables_f.tableDefinition").alias("tableDefinition"),"tables_f.extendedProperties").select(explode("columns").alias("x"),"tableDefinition",explode("extendedProperties").alias("ext")).select("tableDefinition","x.tableName","ext.value").filter(col("ext.key").like("%Table Company Codes%")).dropDuplicates()

# COMMAND ----------

# exploded_erwin_tables_with_filter=exploded_erwin_dF.select("tables_f.columns",col("tables_f.tableDefinition").alias("tableDefinition"),"tables_f.extendedProperties").select(explode("columns").alias("x"),"tableDefinition",explode("extendedProperties").alias("ext")).select("tableDefinition","x.tableName","ext.value").filter(col("ext.key").like("%Table Company Codes%")).dropDuplicates()

# #.select("tableDefinition","tableName","ext.key")#.filter(col("ext.key").like("%Table Company Codes%")) #.filter(col("x.Table Company Codes").isNotNull())
# display(exploded_erwin_tables_with_filter)

# COMMAND ----------

# exploded_erwin_tables_with_filter=exploded_erwin_dF.select("tables_f.columns",col("tables_f.tableDefinition").alias("tableDefinition")).select(explode("columns").alias("x"),"tableDefinition").select("tableDefinition","x.tableName",explode("x.extendedProperties").alias("ext")).select("tableDefinition","tableName","ext.key")#.filter(col("ext.key").like("%Table Company Codes%")) #.filter(col("x.Table Company Codes").isNotNull())
# display(exploded_erwin_tables_with_filter)

# COMMAND ----------

def get_tables_withFilters_df(payload_json):
    json_metadata=get_json_metadata(payload_json)
    

    #table level erwin
    exploded_erwin_dF = json_metadata.withColumn('tables_f',explode(col('tables'))).drop('tables')  #.select("t.tableDefinition")
    #erwin at column levels 
    exploded_erwin_tables_with_filter=exploded_erwin_dF.select("tables_f.columns",col("tables_f.tableDefinition").alias("tableDefinition"),"tables_f.extendedProperties").select(explode("columns").alias("x"),"tableDefinition",explode("extendedProperties").alias("ext")).select("tableDefinition","x.tableName","ext.value").filter(col("ext.key").like("%Table Company Codes%")).dropDuplicates()


    return exploded_erwin_tables_with_filter





# COMMAND ----------

# erwin_dso_type=erwin_dso_type(payload_json)

def get_erwin_filter_criteria_dict(payload_json:dict, erwin_dso_type:str):
    
    json_metadata=get_json_metadata(payload_json)
    erwin_filter_criteria=json_metadata.select(explode("extendedProperties").alias("x"))\
            .select("x.value").filter(col("x.key").like("%Source Company Code%")) if erwin_dso_type=="Multi-DSO" else "No filter required"
    erwin_filter_criteria=erwin_filter_criteria.toPandas().values[0][0]
    
    erwin_filter_criteria_dict=dict(pair.lower().split(":") for pair in erwin_filter_criteria.split(";"))
    return erwin_filter_criteria_dict

erwin_filter_criteria=get_erwin_filter_criteria_dict(payload_json, erwin_dso_type)
print(erwin_filter_criteria)

# COMMAND ----------

# MAGIC %md
# MAGIC --------------------------------------------------------------------------

# COMMAND ----------

json_metadata=get_json_metadata(payload_json)
# erwin_dso_type=get_erwin_dso_type(payload_json)
# erwin_dso_type='Multi-DSO'
erwin_filter_criteria_dict=get_erwin_filter_criteria_dict(payload_json, erwin_dso_type)
tables_withFIlters_df=get_tables_withFilters_df(payload_json)

tables_dict_erwin=tables_withFIlters_df.select("tableName","value").toPandas().to_dict()

# COMMAND ----------

# tables_dict_erwin=tables_withFIlters_df.select("tableName","value").toPandas().to_dict()
# ls_temp_1=[v.lower() for v in tables_dict_erwin["tableName"].values()]
# ls_temp_2=[v.lower() for v in tables_dict_erwin["value"].values()] 

# tables_dict_erwin=dict(zip(ls_temp_1, ls_temp_2))
# # Print the resulting one-level dictionary
# print(tables_dict_erwin)

# COMMAND ----------

def get_tables_dict_erwin(tables_withFIlters_df):
    tables_dict_erwin=tables_withFIlters_df.select("tableName","value").toPandas().to_dict()
    ls_temp_1=[v.lower() for v in tables_dict_erwin["tableName"].values()]
    ls_temp_2=[v.lower() for v in tables_dict_erwin["value"].values()] 

    tables_dict_erwin=dict(zip(ls_temp_1, ls_temp_2))
    # resulting one-level dictionary
    return tables_dict_erwin


# COMMAND ----------

filterCount=0
valueCount=0
tables_missing_filter=[]
tables_with_incorrect_filterValue=[]
tables_without_filter=[]
for tableInfo in query_json:
    
    if tableInfo["tablename"] in tables_dict_erwin.keys() and tableInfo['query']!='' and tableInfo['query'].find('where')>0:
        
        if tableInfo['query'].split('where')[1].find(tables_dict_erwin[tableInfo["tablename"]]):
            filterCount=filterCount+1
        else:
            tables_missing_filter.append(tableInfo['tablename'])
        if tableInfo['query'].split('where')[1].find(erwin_filter_criteria[tables_dict_erwin[tableInfo["tablename"]]]):
            valueCount=valueCount+1
        else:
            tables_with_incorrect_filterValue.append(tableInfo['tablename'])
    else:
        # print(tableInfo['tablename'])
        tables_without_filter.append(tableInfo['tablename'])

if len(tables_missing_filter)>0:
    print(f'{len(tables_missing_filter)} tables are missing filter in the query')
elif len(tables_with_incorrect_filterValue)>0:
    print(f'{len(tables_with_incorrect_filterValue)} tables have incorrect filter criteria in the query')
# elif len(tables_without_filter)>0:
#     print(f'{len(tables_without_filter)} has no filter from the {len(query_json)} tables')
else:
    print(f'{filterCount} tables have correct filter and {len(tables_without_filter)} has no filter from the {len(query_json)} tables')

# COMMAND ----------


ls_temp_1=[v for v in tables_dict_erwin["tableName"].values()]
ls_temp_2=[v for v in tables_dict_erwin["value"].values()]
print(ls_temp_2)
dict

# COMMAND ----------

tables_dict_erwin

# COMMAND ----------

# erwin_dso_type='Multi-DSO'

def filter_criteria_check(payload_json:dict, query_json:dict):
    json_metadata=get_json_metadata(payload_json)
    erwin_dso_type=get_erwin_dso_type(payload_json)
    # erwin_dso_type='Multi-DSO'
    erwin_filter_criteria_dict=get_erwin_filter_criteria_dict(payload_json, erwin_dso_type)
    tables_withFilters_df=get_tables_withFilters_df(payload_json)

    tables_dict_erwin=get_tables_dict_erwin(tables_withFilters_df)

    filterCount=0
    valueCount=0
    tables_missing_filter=[]
    tables_with_incorrect_filterValue=[]
    tables_without_filter=[]
    for tableInfo in query_json:
        
        if tableInfo["tablename"] in tables_dict_erwin.keys() and tableInfo['query']!='' and tableInfo['query'].find('where')>0:
            
            if tableInfo['query'].split('where')[1].find(tables_dict_erwin[tableInfo["tablename"]]):
                filterCount=filterCount+1
            else:
                tables_missing_filter.append(tableInfo['tablename'])
            if tableInfo['query'].split('where')[1].find(erwin_filter_criteria[tables_dict_erwin[tableInfo["tablename"]]]):
                valueCount=valueCount+1
            else:
                tables_with_incorrect_filterValue.append(tableInfo['tablename'])
        else:
            tables_without_filter.append(tableInfo['tablename'])

    if len(tables_missing_filter)>0:
        print(f'{len(tables_missing_filter)} tables are missing filter in the query')
    elif len(tables_with_incorrect_filterValue)>0:
        print(f'{len(tables_with_incorrect_filterValue)} tables have incorrect filter criteria in the query')
    # elif len(tables_without_filter)>0:
    #     print(f'{len(tables_without_filter)} has no filter from the {len(query_json)} tables')
    else:
        print(f'{filterCount} tables have correct filter and {len(tables_without_filter)} has no filter from the {len(query_json)} tables')



    


    

filter_criteria_check(payload_json, query_json)


# COMMAND ----------

dbutils.fs.ls('abfss://test-container-in@stedheneuwdis.dfs.core.windows.net/testreka')  #f'abfss://s4utilities@{storage_account}.dfs.core.windows.net/NonPII/{table}/'

# COMMAND ----------

json_metadata=spark.read.format('delta').load(json_metadata_path)
display(json_metadata)

# COMMAND ----------

# reading erwin json file
# json_metadata=read_json_df(json_metadata_path)
json_metadata=spark.read.json(json_metadata_path)


# json file at table level
# exploded_erwin_df = exploded_erwin_df(json_metadata)
exploded_erwin_df=json_metadata.withColumn('tables_f',explode(col('tables'))).drop('tables')


# erwin json file dataframe in column level
# exploded_erwin_col_df = exploded_erwin_col_df(exploded_erwin_df)
exploded_erwin_col_df=exploded_erwin_df.select("tables_f.columns").select(explode("columns").alias("x"))\
            .select("x.primaryKeyFlag","x.tableName","x.columnName","x.sdiflag","x.columnDatatype","x.extendedProperties","x.foreignKeyTableName")

# COMMAND ----------

# display(exploded_erwin_col_df)
# display(exploded_erwin_df)
display(json_metadata)

# COMMAND ----------

# MAGIC %md
# MAGIC ----------------------------------------------------------------------------------------------------------------------------------------------

# COMMAND ----------

print(query_json)
print(type(query_json))
print(payload_json)

# COMMAND ----------


landing_zone_path  = get_landing_path(payload_json, storage_account)
source_system = get_source_system(payload_json)
erwin_json_path = get_erwin_json_path(payload_json)

try:
    landing_zone_table_df=get_lz_tables_df(landing_zone_path[0])
    tables = get_table_list(landing_zone_table_df, source_system)
    schema_validation_landing(query_json, tables)
except:
    exit

# COMMAND ----------

tables

# COMMAND ----------

print("config dataframe below")
display(config_df)

# COMMAND ----------

for tableInfo in query_json:
    for table_path in tables:   #landing storage account
        if table_path.lower().find(tableInfo['tablename'])>0:
            columnNames=list(tableInfo['query'].replace("select",'').split("from")[0].replace('"','').split(","))
            print(columnNames)
            df_temp=spark.read.options(header=True).format('parquet').load(table_path)
            columns_landing=[x.lower() for x in df_temp.columns]
            difference=set(columns_landing)-(set(columnNames))
            if difference!=0:
                print(f'schema has been changed: column mismathes: {difference} found in {tableInfo["tablename"]}')
            else:
                print('all columns in table')
        else:
            print('table not in landing storage account')

# COMMAND ----------

df_ever=spark.read.options(header=True, delimiter="|").format('csv').load(f'abfss://test@stedhenis01landdev.dfs.core.windows.net/hen/2024/07/17/EVER.parquet')

df_ever.createOrReplaceTempView(f'ever_t')
print('ever_t')
# spark.sql(f'select ".NODE1", count(*) as cnt from ever group by ".NODE1" having cnt>1').display()

spark.sql(f'select count(*) from ever_t').display()
spark.sql(f'select distinct * from ever_t').display()