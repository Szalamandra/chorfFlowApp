# Databricks notebook source
# MAGIC %sql
# MAGIC DROP SCHEMA IF EXISTS edh_en_consumption_qas.2444_isujp3 CASCADE

# COMMAND ----------

# DBTITLE 1,Import modules
from src.data_quality.dq_checks import DataQualityChecks
from src.utils.config_handler import *
from src.utils.erwin_json import *
from src.utils.enums.data_quality_types import DQTypes
from src.utils.logger import DBFSLogger, logging
from src.utils.utils import fileExists
from functools import reduce

# COMMAND ----------

# DBTITLE 1,Clear widgets
dbutils.widgets.removeAll()

# COMMAND ----------

# DBTITLE 1,Set parameters
# Set parameters for Databricks widgets
dbutils.widgets.text("metadata_path", "test_json_metadata_path")
dbutils.widgets.text("net_type", "en")
dbutils.widgets.text("env", "dev")
dbutils.widgets.text("business_unit", "test_business_unit")
dbutils.widgets.text("layer", "test_layer")

#please use only the table names not the entire path
dbutils.widgets.text("tables_list", "table1,table2,table3")
dbutils.widgets.text("source_system", "test_source_system")

# lending path without table_name
dbutils.widgets.text("landing_path", "abfss://landing_path")

#select only the relevant checks
dbutils.widgets.multiselect("checks", "UniqueValues", ["UniqueValues", "NotNullValues", "EmptyTable", "PIICheck"])
#scd_flag by default is false, please change it according to the source system
dbutils.widgets.text("scd_flag", "False")

# COMMAND ----------

# DBTITLE 1,Get parameters

# Fetch parameters from Databricks widgets
metadata_path = dbutils.widgets.get("metadata_path")
net_type = dbutils.widgets.get("net_type")
env = dbutils.widgets.get("env")
business_unit = dbutils.widgets.get("business_unit")
layer = dbutils.widgets.get("layer").lower()
tables_list = dbutils.widgets.get("tables_list").replace(" ", '').split(',')
source_system = dbutils.widgets.get("source_system")
landing_path = dbutils.widgets.get("landing_path")
selected_checks = dbutils.widgets.get("checks").split(',')
scd_flag = dbutils.widgets.get("scd_flag") == 'True'

# COMMAND ----------


tables_list ='BUT021_FS,ADR3,BCONT,BUT020,V_EGPL,ESERVICE,FKKMAZE,FKKMAKO,DFKKBPTAXNUM,DFKKLOCKS,DM_MR_PHODT,ETTIFN,BUT000,FKKVKP,BUT050,ERCH,ADRSTREET,QMSM,CS_C_POSIT,VIQMFE,EGERR,V_SOUDADCP,NSCALE_DOC,TRACK_SM,EASTL,EQUI,TBE_DFKKLOC,CS_FV_LOG,EDISCOBJH,DM_SZNY_EXT,ETRG,DFKKOP,DM_027_HEAD,EFORMULAINSTPMI,MD_SMART_VT,EANL,JEST,FO_V_VID,EVBS,EDISCOBJ,V_EHAU,ERDK,EASTS,EEDMSETTLUNITT,ADR6,ELPASS,FO_VID_F,EPROFASS,CS_STAT_BW,VIQMEL,EUITRANS,EEDMSETTLUNIT,ADRCT,EVER,ADR2,ETDZ,TR_INAKTDB,NSCALE_PROC,DM_UK_SZEG,EFORMULAINSTPMO,EANLH,EASTE,EGERH,ADRC,EDISCDOC,EUIINSTLN,EUFASS,ERCHC,ADRCITY,EUIGRID,EEDMUISETTLUNIT'
# Fetch parameters from Databricks widgets
metadata_path = 'abfss://erwin-landing-path@stedheneuwdis.dfs.core.windows.net/qas/Hungary EN - ISUJP3 - QA_2025-02-17_11:35:25.json'
net_type = 'en'
env = 'qas'
business_unit = "2444"
layer = "cons"
tables_list = tables_list.replace(" ", '').split(',')
source_system = "isujp3"
landing_path = "abfss://isujp3-sqlserver@stedhenis01landrun.dfs.core.windows.net/hen/2025/02/17/"
selected_checks = ['UniqueValues', 'EmptyTable', 'PIICheck']
scd_flag = "False" == 'True'

# COMMAND ----------

selected_checks

# COMMAND ----------

# DBTITLE 1,Setting credentials on storage account
config_directory = "dbfs:/libraries/edh-en-edz-eam/src/generalized_pipeline/scripts"

# Initialize logger
dbfs_logger = DBFSLogger(log_level=logging.INFO)
logger = dbfs_logger.get_logger()

# Fetch credentials and storage accounts
(scope, client_id, client_secret, tenant_id) = get_platform_config(config_directory, net_type, env)
metadata_storage_account = get_metadata_storage_account(net_type)
(landing_storage_account, std_account_name, cons_account_name) = get_account_names(net_type, business_unit, env)
storage_accounts = [metadata_storage_account, landing_storage_account, cons_account_name, std_account_name]

# Set credentials for storage accounts
for account in storage_accounts:
    set_credentials(scope, account, client_id, client_secret, tenant_id)

# Determine the account name based on the layer
account_name = std_account_name if layer == "std" else cons_account_name

# COMMAND ----------

# DBTITLE 1,Read metadata file and get columns

def get_table_attributes(table_name):
    """
    Fetch table attributes from the metadata.
    """
    df_relevant_table = get_edh_relevant_table_info(erwin_df, table_name)

    all_columns_relevant = len([row["tableName"] for row in df_relevant_table.where("key=='all columns relevant for edh ?'and value ==1").select("tableName").collect()]) > 0
    try:       
        load_type = [row["value"] for row in df_relevant_table.where("key=='data loading mechanism'").select("value").collect()]
        
        load_type = ''.join(load_type).replace(' ', '_')

    except Exception as e:
        load_type = "full_load"
        logger.info(f"Failed to load data from table {df_relevant_table}, with load type set to: {load_type}.")
    
    if load_type == "":
        load_type = "full_load"
    elif load_type == "SAP CDC":
        load_type = "SAP_CDC"

    exploded_erwin_col_df_val, ID_list_all = get_exploded_erwin_col_df(erwin_col_df, '.' + table_name, str(all_columns_relevant))

    if exploded_erwin_col_df_val.count() == 0:
        exploded_erwin_col_df_val, ID_list_all = get_exploded_erwin_col_df(erwin_col_df, table_name, str(all_columns_relevant))

    return exploded_erwin_col_df_val, load_type


# Read metadata JSON and explode into DataFrames
json_metadata = read_json_df(metadata_path)
erwin_df = exploded_erwin_df(json_metadata)
erwin_col_df = exploded_erwin_col_df(erwin_df)

# COMMAND ----------

# DBTITLE 1,GET paths and dfs

def get_prev_layer_path(table_landing_path, layer, table_name, source_system, std_account_name):
    """
    Get the input path for the table based on the layer.
    """
    if layer == "std":
        return table_landing_path + table_name+ ".parquet"
    else:
        return f"abfss://edh@{std_account_name}.dfs.core.windows.net/{source_system}/{table_name}"


def get_table_path(account_name, table_name, source_system, layer, scd_flag):
    """
    Get the output path for the table based on the layer.
    """
    if layer == "std":
        return get_standard_path(account_name, source_system, table_name, scd_flag)
    else:
        return get_cons_path(source_system, account_name, table_name, scd_flag)


def get_table(table_path, layer, previous = False):
    """
    Read the input table based on the layer.
    """
    if layer == "std" and previous:
        return spark.read.parquet(table_path)
    else:
        return spark.read.format("delta").load(table_path)

# COMMAND ----------

# DBTITLE 1,Define checks

def perform_check(check, logger):
    """
    Perform data quality checks on a table.
    """
    try:
        dq = DataQualityChecks(check["table"], check["table_name"], check["check_def"], logger)
        dq.validate()
        return dq.errors
    except Exception as e:
        return f"Error performing data quality checks on {check['table_name']}: {str(e)}"


def add_checks(table_name, table, prev_table, not_nullable_columns, pk_columns, pii_columns, load_type, layer):
    """
    Define data quality checks for a table.
    """
    check_type = []
    if DQTypes.EMPTY_TABLE.value in selected_checks:
        check_type.append({"dq_type": DQTypes.EMPTY_TABLE.value, "columns":None, "df_to_compare": None})
    if layer == "cons" and DQTypes.PII_CHECK.value in selected_checks:
        check_type.append({"dq_type": DQTypes.PII_CHECK.value, "columns": pii_columns, "df_to_compare": None})
    # if load_type != "delta_load":
    #     check_type.append({"dq_type": DQTypes.ROW_COUNT.value, "columns": None, "df_to_compare": prev_table})
    if len(pk_columns) > 0 and DQTypes.UNIQUE.value in selected_checks:
        check_type.append({"dq_type": DQTypes.UNIQUE.value, "columns": pk_columns, "df_to_compare": None})
    if len(not_nullable_columns) > 0 and DQTypes.NOT_NULL.value in selected_checks:
        check_type.append({"dq_type": DQTypes.NOT_NULL.value, "columns": not_nullable_columns, "df_to_compare": None})

    return {"table": table, "table_name": table_name, "check_def": check_type}


def validate_table(table_name, layer, source_system, account_name, logger, std_account_name, scd_flag, landing_path):
    """
    Validate a table by performing data quality checks.
    """
    try:
        prev_layer_path = get_prev_layer_path(landing_path, layer, table_name, source_system, std_account_name)
        table_path = get_table_path(account_name, table_name, source_system, layer, scd_flag)
        
        if not fileExists(prev_layer_path) or not fileExists(table_path):
            logger.info(f"Previous layer path {prev_layer_path} or table path {table_path} does not exist. Table {table_name} will be skipped from validation.")
            return None
        
        prev_table = get_table(prev_layer_path, layer, True)
        table_df = get_table(table_path, layer)

        if DQTypes.EMPTY_TABLE.value not in selected_checks and table_df.isEmpty():
            logger.info(f"Table {table_name} is empty. Table will be skipped from validation.")
            return None
        table_attributes_df, load_type = get_table_attributes(table_name)
        not_nullable_columns = filter_columns(table_attributes_df, "columnNullableFlag==False")
        pii_columns = filter_columns(table_attributes_df, "sdiflag==True")
        pk_columns = filter_columns(table_attributes_df, "primaryKeyFlag==True")
        not_null_cols_non_pii = [col for col in not_nullable_columns if col not in pii_columns]
        checks = add_checks(table_name, table_df, prev_table, not_null_cols_non_pii, pk_columns, pii_columns, load_type, layer)
        return perform_check(checks, logger)
    except Exception as e:
        return logger.error(f"Error validating table {table_name}: {str(e)}")

# COMMAND ----------

# DBTITLE 1,Perform data_quality_checks

# Perform data quality checks for each table
errors = []
errors.extend(filter(None, list(map(lambda table: validate_table(table, layer, source_system, account_name, logger, std_account_name, scd_flag, landing_path), tables_list))))

# Log results
if len(errors) > 0:
    raise Exception(f"Data Quality failed. The following checks failed: {errors}")
else:
    logger.info(f"Data Quality tests passed for {layer} layer.")