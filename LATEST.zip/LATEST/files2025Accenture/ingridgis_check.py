# Databricks notebook source


# COMMAND ----------

import os
import json


from src.utils.config_handler import * 

from src.utils.cluster_config import *
from src.utils.utils import fileExists

from src.utils.erwin_json import read_json_df
from pyspark.sql.functions import explode, col

from pyspark.sql import DataFrame
import hashlib
import json

# COMMAND ----------

current_directory=os.getcwd()
if current_directory=="/databricks/driver":
    current_directory="/Workspace/Repos/release/edh-en-edz-eam/src/generalized_pipeline/scripts"
config_directory="dbfs:/libraries/edh-en-edz-eam/src/generalized_pipeline/scripts"
script_current_directory=current_directory.replace("/Workspace","")

ws_url=spark.conf.get("spark.databricks.workspaceUrl")

# COMMAND ----------


def get_config_df(config_directory):
    config_df=spark.read.format("csv").option("header",True).load(f"{config_directory}/config_files/databricks_url_env_config.csv")
    return config_df

def get_config_values(config_df: DataFrame, ws_url: str) -> tuple:
    url_hash = hash_workspace_url(ws_url)
    env = config_df.filter(config_df.workspace_url == url_hash).select("env").first()["env"]
    net_type = config_df.filter(config_df.workspace_url == url_hash).select("type").first()["type"]
    token = get_adb_token(net_type, env)
    return env, net_type, token

# getting platform configuration values

def get_platform_config(config_directory, net_type, env ):
    platform_config_path=f"{config_directory}/config_files/platform_config.json"
    platform_config=spark.read.json(platform_config_path,multiLine=True)
    platform_config_values= platform_config.collect()
    client_secret = platform_config_values[0]['client_secret']
    client_id = platform_config_values[0]['client_id']
    tenant_id = platform_config_values[0]['tenant_id']
    scope=f"kv-edh{net_type}-euw-{env}-is01"
    return (scope, client_id, client_secret, tenant_id)

def get_storage_account(net_type,env):
    if net_type == "en":
        storage_account=f"{reg_storage_account}{env}"
    else:
        storage_account=f"{unreg_storage_account}{env}"
    return storage_account


def set_credentials(scope,storage_account,client_id,client_secret,tenant_id):
    service_credential = dbutils.secrets.get(scope=scope,key=client_id)
    service_credential1 = dbutils.secrets.get(scope=scope,key=client_secret)


    spark.conf.set(f"fs.azure.account.auth.type.{storage_account}.dfs.core.windows.net", "OAuth")
    spark.conf.set(f"fs.azure.account.oauth.provider.type.{storage_account}.dfs.core.windows.net","org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
    spark.conf.set(f"fs.azure.account.oauth2.client.id.{storage_account}.dfs.core.windows.net", service_credential)
    spark.conf.set(f"fs.azure.account.oauth2.client.secret.{storage_account}.dfs.core.windows.net", service_credential1)
    spark.conf.set(f"fs.azure.account.oauth2.client.endpoint.{storage_account}.dfs.core.windows.net", f"https://login.microsoftonline.com/{tenant_id}/oauth2/token")



def hash_workspace_url(url: str) -> str:
    return hashlib.sha256(url.encode()).hexdigest()
def get_adb_token(net_type: str, env: str) -> str:
    secret_scope = f'kv-edh{net_type}-euw-{env}-is01'
    token = dbutils.secrets.get(scope=secret_scope, key='databricks-token')
    return token

reg_storage_account = 'stedhenis01land'
unreg_storage_account = 'stedhunregis01land'
reg_metadata_storage_account = 'stedheneuwdis'
unreg_metadata_storage_account = 'stedhunregeuwdis'



# COMMAND ----------

env='qas'
storage_account=reg_storage_account+env
# storage_account='stedhen2444stdqas'

storage_path=f'abfss://ingridgis-oracle@{storage_account}.dfs.core.windows.net/hen/2025/02/19'
# storage_std_path='abfss://edh@stedhen2444stddev.dfs.core.windows.net/ingridgis/FOLDELESEK_SABL.parquet'

# COMMAND ----------

# Get Configuration Variables
config_df =get_config_df(config_directory)
(env, net_type, token) = get_config_values(config_df,ws_url)
storage_account = get_storage_account(net_type,env)

# COMMAND ----------

# Setting Credentials using Platform Values
(scope, client_id, client_secret, tenant_id) =  get_platform_config(config_directory, net_type, env)
set_credentials(scope,storage_account,client_id,client_secret,tenant_id)

# COMMAND ----------


# net_type = "en"
# env = "dev"
# scope=f"databricks_{env}_{net_type}_scope"
# # storage_account=f"stedheneamlanding{env}"

# scope=f"databricks_{env}_{net_type}_scope"


# storage_account=f"stedhenis01land{env}"
# # storage_account=f"stedhenis01ext{env}"

# # storage_account=f"stedhen2444consdev"

# config_directory="dbfs:/libraries/edh-en-edz-eam/src/generalized_pipeline/scripts"
# platform_config_path=f"{config_directory}/config_files/platform_config.json"
# platform_config=spark.read.json(platform_config_path,multiLine=True)
# platform_config_values= platform_config.collect()
# client_secret = platform_config_values[0]['client_secret']
# client_id = platform_config_values[0]['client_id']
# tenant_id = platform_config_values[0]['tenant_id']



  
# set_credentials(scope,storage_account,client_id,client_secret,tenant_id)

# COMMAND ----------

client_secret


# COMMAND ----------

listLanding=dbutils.fs.ls(storage_path)

# COMMAND ----------

display(listLanding)

# COMMAND ----------

len(listLanding)

# COMMAND ----------

# listNames=listLanding.explode(name).map(lambda x: x[0]).collect()

# COMMAND ----------

# listLanding[0][0].strip(',').replace('abfss://inis-oracle@stedhenis01landrun.dfs.core.windows.net/hen/2025/01/16/','').replace('.parquet','')

# COMMAND ----------

# filenames=[listLanding[0][0].strip(',').replace('abfss://inis-oracle@stedhenis01landrun.dfs.core.windows.net/hen/2025/01/16/','').replace('.parquet','')]

# COMMAND ----------

# len(listnames)

# COMMAND ----------


listnames=[]
for i in listLanding:
    part=i[0].strip(',').replace(storage_path+'/','').replace('.parquet','')
    listnames.append(part)

# COMMAND ----------

listnames

# COMMAND ----------

list2=["ABLAK_ADATOK", "ABLAK_SZUROK", "ABLAKOK", "ACCS_EXPORT_OBJEKTUMOK", "ADIJAS_FOGYASZTOK", "ADIJAS_FOGYASZTOK_JOVO", "ADIJAS_FOGYASZTOK_MULT", "ADIJAS_FOGYASZTOK_SABL", "AKKU_TELEPEK", "AKKU_TELEPEK_JOVO", "AKKU_TELEPEK_MULT", "AKKU_TELEPEK_SABL", "AKKU_TOLTOK", "AKKU_TOLTOK_JOVO", "AKKU_TOLTOK_MULT", "AKKU_TOLTOK_SABL", "ALALLOMASOK", "ALALLOMASOK_JOVO", "ALALLOMASOK_MULT", "ALALLOMASOK_SABL", "ARAMKOR_KAPCSOLOK", "ARAMKOR_KAPCSOLOK_JOVO", "ARAMKOR_KAPCSOLOK_MULT", "ARAMKOR_KAPCSOLOK_SABL", "ARAMKOR_SZABALYZOK", "ARAMKOR_SZABALYZOK_JOVO", "ARAMKOR_SZABALYZOK_MULT", "ARAMKOR_SZABALYZOK_SABL", "ARAMKOROK", "ARAMKOROK_JOVO", "ARAMKOROK_MULT", "ARAMKOROK_SABL", "ARAMVALTO_MAGOK", "ARAMVALTO_MAGOK_JOVO", "ARAMVALTO_MAGOK_MULT", "ARAMVALTO_MAGOK_SABL", "ARAMVALTOK", "ARAMVALTOK_JOVO", "ARAMVALTOK_MULT", "ARAMVALTOK_SABL", "BIZTOSITO_ESZK", "BIZTOSITO_ESZK_JOVO", "BIZTOSITO_ESZK_MULT", "BIZTOSITO_ESZK_SABL", "BIZTOSITOK", "BIZTOSITOK_JOVO", "BIZTOSITOK_MULT", "BIZTOSITOK_SABL", "CSATLAKOZOVEZETEKEK", "CSATLAKOZOVEZETEKEK_JOVO", "CSATLAKOZOVEZETEKEK_MULT", "CSATLAKOZOVEZETEKEK_SABL", "CSILLPK_TRANSZFORMATOROK", "CSILLPK_TRANSZFORMATOROK_JOVO", "CSILLPK_TRANSZFORMATOROK_MULT", "CSILLPK_TRANSZFORMATOROK_SABL", "DOKUMENTUMOK", "DWG_ADATOK", "DWG_IMPORT_OBJEKTUM_ADATOK", "DWG_IMPORT_OBJEKTUM_ADATOK_HIBAS", "DWG_IMPORT_OBJEKTUMOK", "DWG_IMPORT_OBJEKTUMOK_HIBAS", "DWG_IMPORTOK", "EAUTO_TOLTOK", "EAUTO_TOLTOK_JOVO", "EAUTO_TOLTOK_MULT", "EAUTO_TOLTOK_SABL", "ELLATOTT_FOGY_ELLATAS_KOR", "ELLATOTT_FOGY_ELLATAS_KOR_TEMP", "ELLATOTT_KOZTERULETEK", "ELLATOTT_KOZTERULETEK_TEMP", "ELLATOTT_TRALLOMASOK", "ELLENALLAS_ESZK", "ELLENALLAS_ESZK_JOVO", "ELLENALLAS_ESZK_MULT", "ELLENALLAS_ESZK_SABL", "ELLENALLASOK", "ELLENALLASOK_JOVO", "ELLENALLASOK_MULT", "ELLENALLASOK_SABL", "ELOSZTOSZEKRENYEK", "ELOSZTOSZEKRENYEK_JOVO", "ELOSZTOSZEKRENYEK_MULT", "ELOSZTOSZEKRENYEK_SABL", "EROMUVEK", "EROMUVEK_JOVO", "EROMUVEK_MULT", "EROMUVEK_SABL", "ETM_VEZERLOK", "ETM_VEZERLOK_JOVO", "ETM_VEZERLOK_MULT", "ETM_VEZERLOK_SABL", "EVV_AZONOSITO_GENERALAS_LOG", "EVV_AZONOSITO_GENERALAS_WORK", "EVV_DOKUMENTUMOK", "EVV_HIBAUZENETEK", "EVV_MUNKAFOLYAMATOK", "FAM_KOTESEK", "FAM_KOTESEK_JOVO", "FAM_KOTESEK_MULT", "FAM_KOTESEK_SABL", "FELIRATOK", "FELIRATOK_JOVO", "FELIRATOK_MULT", "FELIRATOK_SABL", "FENYFORRASOK", "FENYFORRASOK_JOVO", "FENYFORRASOK_MULT", "FENYFORRASOK_SABL", "FESZULTSEGVALTO_TEKERCSEK", "FESZULTSEGVALTO_TEKERCSEK_JOVO", "FESZULTSEGVALTO_TEKERCSEK_MULT", "FESZULTSEGVALTO_TEKERCSEK_SABL", "FESZULTSEGVALTOK", "FESZULTSEGVALTOK_JOVO", "FESZULTSEGVALTOK_MULT", "FESZULTSEGVALTOK_SABL", "FOGYASZTASI_PONTOK", "FOGYASZTASI_PONTOK_JOVO", "FOGYASZTASI_PONTOK_MULT", "FOGYASZTASI_PONTOK_SABL", "FOJTOTEKERCS_ESZK", "FOJTOTEKERCS_ESZK_JOVO", "FOJTOTEKERCS_ESZK_MULT", "FOJTOTEKERCS_ESZK_SABL", "FOJTOTEKERCSEK", "FOJTOTEKERCSEK_JOVO", "FOJTOTEKERCSEK_MULT", "FOJTOTEKERCSEK_SABL", "FOLDELESEK", "FOLDELESEK_JOVO", "FOLDELESEK_MULT", "FOLDELESEK_SABL", "FOLDELO_SZAKASZOLO_ESZK", "FOLDELO_SZAKASZOLO_ESZK_JOVO", "FOLDELO_SZAKASZOLO_ESZK_MULT", "FOLDELO_SZAKASZOLO_ESZK_SABL", "FOLDELO_SZAKASZOLOK", "FOLDELO_SZAKASZOLOK_JOVO", "FOLDELO_SZAKASZOLOK_MULT", "FOLDELO_SZAKASZOLOK_SABL", "GAZ_ALLOMASOK", "GAZ_ALLOMASOK_JOVO", "GAZ_ALLOMASOK_MULT", "GAZ_ALLOMASOK_SABL", "GAZ_ANODOK", "GAZ_ANODOK_JOVO", "GAZ_ANODOK_MULT", "GAZ_ANODOK_SABL", "GAZ_BIZTONSAGI_OVEZETEK", "GAZ_BIZTONSAGI_OVEZETEK_JOVO", "GAZ_BIZTONSAGI_OVEZETEK_MULT", "GAZ_BIZTONSAGI_OVEZETEK_SABL", "GAZ_DRENAZSOK", "GAZ_DRENAZSOK_JOVO", "GAZ_DRENAZSOK_MULT", "GAZ_DRENAZSOK_SABL", "GAZ_ELZAROK", "GAZ_ELZAROK_JOVO", "GAZ_ELZAROK_MULT", "GAZ_ELZAROK_SABL", "GAZ_FELIRATOK", "GAZ_FELIRATOK_JOVO", "GAZ_FELIRATOK_MULT", "GAZ_FELIRATOK_SABL", "GAZ_FOGYASZTASI_PONTOK", "GAZ_FOGYASZTASI_PONTOK_JOVO", "GAZ_FOGYASZTASI_PONTOK_MULT", "GAZ_FOGYASZTASI_PONTOK_SABL", "GAZ_KATOD_ALLOMASOK", "GAZ_KATOD_ALLOMASOK_JOVO", "GAZ_KATOD_ALLOMASOK_MULT", "GAZ_KATOD_ALLOMASOK_SABL", "GAZ_KERESZTEZESEK", "GAZ_KERESZTEZESEK_JOVO", "GAZ_KERESZTEZESEK_MULT", "GAZ_KERESZTEZESEK_SABL", "GAZ_KOTESEK", "GAZ_KOTESEK_JOVO", "GAZ_KOTESEK_MULT", "GAZ_KOTESEK_SABL", "GAZ_LEAGAZASOK", "GAZ_LEAGAZASOK_JOVO", "GAZ_LEAGAZASOK_MULT", "GAZ_LEAGAZASOK_SABL", "GAZ_MERETEZESI_FELIRATOK", "GAZ_MERETEZESI_FELIRATOK_JOVO", "GAZ_MERETEZESI_FELIRATOK_MULT", "GAZ_MERETEZESI_FELIRATOK_SABL", "GAZ_MERETEZESI_JELEK", "GAZ_MERETEZESI_JELEK_JOVO", "GAZ_MERETEZESI_JELEK_MULT", "GAZ_MERETEZESI_JELEK_SABL", "GAZ_MERETEZESI_VONALAK", "GAZ_MERETEZESI_VONALAK_JOVO", "GAZ_MERETEZESI_VONALAK_MULT", "GAZ_MERETEZESI_VONALAK_SABL", "GAZ_NYOMASSZABALYZOK", "GAZ_NYOMASSZABALYZOK_JOVO", "GAZ_NYOMASSZABALYZOK_MULT", "GAZ_NYOMASSZABALYZOK_SABL", "GAZ_POT_MEROHELYEK", "GAZ_POT_MEROHELYEK_JOVO", "GAZ_POT_MEROHELYEK_MULT", "GAZ_POT_MEROHELYEK_SABL", "GAZ_POT_MEROVEZETEKEK", "GAZ_POT_MEROVEZETEKEK_JOVO", "GAZ_POT_MEROVEZETEKEK_MULT", "GAZ_POT_MEROVEZETEKEK_SABL", "GAZ_RAJZJELEK", "GAZ_RAJZJELEK_JOVO", "GAZ_RAJZJELEK_MULT", "GAZ_RAJZJELEK_SABL", "GAZ_RAJZVONALAK", "GAZ_RAJZVONALAK_JOVO", "GAZ_RAJZVONALAK_MULT", "GAZ_RAJZVONALAK_SABL", "GAZ_SEGEDVEZETEKEK", "GAZ_SEGEDVEZETEKEK_JOVO", "GAZ_SEGEDVEZETEKEK_MULT", "GAZ_SEGEDVEZETEKEK_SABL", "GAZ_SZUKITOK", "GAZ_SZUKITOK_JOVO", "GAZ_SZUKITOK_MULT", "GAZ_SZUKITOK_SABL", "GAZ_TARTOZEKOK", "GAZ_TARTOZEKOK_JOVO", "GAZ_TARTOZEKOK_MULT", "GAZ_TARTOZEKOK_SABL", "GAZ_VEDOCSOVEK", "GAZ_VEDOCSOVEK_JOVO", "GAZ_VEDOCSOVEK_MULT", "GAZ_VEDOCSOVEK_SABL", "GAZ_VEZETEKEK", "GAZ_VEZETEKEK_JOVO", "GAZ_VEZETEKEK_MULT", "GAZ_VEZETEKEK_SABL", "GAZ_VILL_ELOSZEKRENYEK", "GAZ_VILL_ELOSZEKRENYEK_JOVO", "GAZ_VILL_ELOSZEKRENYEK_MULT", "GAZ_VILL_ELOSZEKRENYEK_SABL", "GAZ_VILL_TARTOSZERKEZETEK", "GAZ_VILL_TARTOSZERKEZETEK_JOVO", "GAZ_VILL_TARTOSZERKEZETEK_MULT", "GAZ_VILL_TARTOSZERKEZETEK_SABL", "GAZ_VILL_VEZETEKEK", "GAZ_VILL_VEZETEKEK_JOVO", "GAZ_VILL_VEZETEKEK_MULT", "GAZ_VILL_VEZETEKEK_SABL", "GEOMETA_JSON", "GEOMETA_JSON_MASTER", "GEOMETRIA_ADATOK", "GYUJTOSINEK", "GYUJTOSINEK_JOVO", "GYUJTOSINEK_MULT", "GYUJTOSINEK_SABL", "HFKV_BERENDEZES_ESZK", "HFKV_BERENDEZES_ESZK_JOVO", "HFKV_BERENDEZES_ESZK_MULT", "HFKV_BERENDEZES_ESZK_SABL", "HFKV_BERENDEZESEK", "HFKV_BERENDEZESEK_JOVO", "HFKV_BERENDEZESEK_MULT", "HFKV_BERENDEZESEK_SABL", "HIBAHELY_BEJARAS_WORK", "HIBAHELY_EREDMENYEK", "HIBAHELY_EREDMENYEK_HIBAK", "HIBAHELY_EREDMENYEK_KOORDINATAK", "HIBAHELY_EREDMENYEK_KOORDINATAK_WKT", "HIBAHELY_HIBATIPUSOK", "HIBAHELY_KIVEZETES_WORK", "HULLAMZARAK", "HULLAMZARAK_JOVO", "HULLAMZARAK_MULT", "HULLAMZARAK_SABL", "IDEGEN_ESZKOZOK", "IDEGEN_ESZKOZOK_JOVO", "IDEGEN_ESZKOZOK_MULT", "IDEGEN_ESZKOZOK_SABL", "INIS_KORZETEK", "IVOLTO_TEKERCS_ESZK", "IVOLTO_TEKERCS_ESZK_JOVO", "IVOLTO_TEKERCS_ESZK_MULT", "IVOLTO_TEKERCS_ESZK_SABL", "IVOLTO_TEKERCSEK", "IVOLTO_TEKERCSEK_JOVO", "IVOLTO_TEKERCSEK_MULT", "IVOLTO_TEKERCSEK_SABL", "KA_AKKUTELEP", "KA_AKKUTOLTO", "KA_ARAMVALTO", "KA_BIZALJ", "KA_BIZBET", "KA_CSATVEZ", "KA_DWG_ATTRIBUTUM", "KA_DWG_BLOKK", "KA_DWG_FELIRAT", "KA_DWG_FOLIA", "KA_DWG_JELKULCS", "KA_DWG_KODERTEK", "KA_EAUTO_TOLTO", "KA_ELLENALLAS", "KA_FESZVALTO", "KA_FOJTOTEKERCS", "KA_HFKV_TRAFO", "KA_IVOLTO", "KA_IVOLTOTEK", "KA_KABEL", "KA_KARMANTYU", "KA_KOCSI", "KA_KOMBIVALTO", "KA_KONDENZ", "KA_MEGSZAKITO", "KA_MEROVALTO", "KA_NYOMVONAL_SZAKASZ", "KA_OSZKAP", "KA_OSZLOP", "KA_SODRONY", "KA_SZAKASZOLO", "KA_SZAKKAPCSOLO", "KA_SZIGETELO", "KA_TOK_KAPCSOLO", "KA_TOKOZOTT_BERENDEZES", "KA_TRAFO", "KA_TULFESZ", "KA_VANJ", "KA_VEDELEM", "KA_VEDOVEZET", "KABEL_KARMANTYUK", "KABEL_KARMANTYUK_JOVO", "KABEL_KARMANTYUK_MULT", "KABEL_KARMANTYUK_SABL", "KABEL_VEGELZAROK", "KABEL_VEGELZAROK_JOVO", "KABEL_VEGELZAROK_MULT", "KABEL_VEGELZAROK_SABL", "KABELVEZETEKEK", "KABELVEZETEKEK_JOVO", "KABELVEZETEKEK_KA", "KABELVEZETEKEK_MULT", "KABELVEZETEKEK_SABL", "KAPCSOLO_BERENDEZESEK", "KAPCSOLO_BERENDEZESEK_JOVO", "KAPCSOLO_BERENDEZESEK_MULT", "KAPCSOLO_BERENDEZESEK_SABL", "KERESZTEZESEK", "KERESZTEZESEK_JOVO", "KERESZTEZESEK_MULT", "KERESZTEZESEK_SABL", "KIEMELT_OBJEKTUMOK", "KIF_ELOSZTOK", "KIF_ELOSZTOK_JOVO", "KIF_ELOSZTOK_MULT", "KIF_ELOSZTOK_SABL", "KK_CSATVEZ_HAZSZAM", "KK_GAZVEZETEK_SZERELVENY", "KK_GAZVEZETEK_SZERELVENY_WORK", "KK_HALOZAT_NYOMVONAL", "KK_KABEL_VEGELZARO_VSZ", "KK_KOFELO_KESZ", "KK_OKSZAKASZ_TRANSZFORMATOR", "KK_OKSZAKASZ_VONALSZAKASZ", "KK_OSZLOP_VEZETEK", "KK_OSZLOP_VEZETEK_NEW", "KK_OSZLOP_VEZETEK_OLD", "KK_OSZLOP_VEZETEK_WORK", "KK_SZIMB_KOMPONENS", "KK_SZIMB_KOMPONENS_DEF", "KK_SZIMB_KOMPONENS_SAVE", "KK_TMOKSZAKASZ_TRANSZFORMATOR", "KK_TMOKSZAKASZ_VONALSZAKASZ", "KK_VEZETEK_SZERELVENY", "KK_VEZETEK_SZERELVENY_WORK", "KO_ABLOYZAR_CILINDER_TIP", "KO_ABRAZOLASI_MOD", "KO_ABRMOD_ABLAK", "KO_ABRMOD_KATEGORIA", "KO_AFOGY_TIP", "KO_AKKU_KONTROL", "KO_AKKUTOLT_TIP", "KO_AKSZAB_KTG", "KO_ALAL_CSOP", "KO_ALAL_EMESZTO", "KO_ALAL_OLAJLV", "KO_ALAL_TIP", "KO_ALAL_VAGYVED", "KO_ALL_FUNK", "KO_ALL_SABLON", "KO_ALLKATEGORIA", "KO_ALLOMAS_KTG", "KO_ARAMMAG_OSZTPONT", "KO_ARAMV_TELJ", "KO_ARAMVALT_ATTET", "KO_ARAMVALT_TIP", "KO_ARMATURA_TIP", "KO_ATELEP_TIP", "KO_ATKAR_TIP", "KO_ATOLTO_KIALAKITAS", "KO_ATOLTO_TESZTCIDO", "KO_ATOLTO_TESZTIDO", "KO_ATOLTO_TESZTKIIDO", "KO_AV_ATTET", "KO_BIZALJ_TIP", "KO_BIZALJMERET_TIP", "KO_BIZBET_M_TIP", "KO_BIZBET_TIP", "KO_BIZT_ARAM", "KO_BIZT_ZAR", "KO_BIZTIP", "KO_BIZTOS_HELY", "KO_CSATVEZ_ELREND", "KO_CSE_SZEKRENY", "KO_CSO_ATMERO", "KO_CSO_BELSOATMERO", "KO_EAUTOLT_JELLEG", "KO_ELHELYEZES", "KO_ELLENALL_KTG", "KO_ELLENALLAS_TIP", "KO_ELOSZEK_HELY", "KO_ELZARO_KTG", "KO_ELZARO_TIP", "KO_EROMU_TIP", "KO_ESZEK_KTG", "KO_ESZEK_TARTO", "KO_ESZEK_TIP", "KO_ETM_TIP", "KO_FAMKOT_KTG", "KO_FAMKOT_TIP", "KO_FANOE_TIP", "KO_FAZIS", "KO_FAZIS_REND", "KO_FEJSZERKEZET", "KO_FEKTETESMOD", "KO_FELELOS", "KO_FELIRAT_TIP", "KO_FENYF_TELJ", "KO_FENYFOR_TIP", "KO_FESZ_ATTET", "KO_FESZ_SZINT", "KO_FESZT_OSZTPONT", "KO_FESZV_TELJ", "KO_FESZVALT_ATTET", "KO_FESZVALT_TIP", "KO_FOGYHAL_STATUSZ", "KO_FOJTO_TIP", "KO_FOKOZATKAP_TIP", "KO_FOLDEL_KTG", "KO_FOLDELL_TIP", "KO_FTEKERCS_TIP", "KO_FV_ATTET", "KO_GAZALL_KTG", "KO_GAZALLOMAS_TIP", "KO_GAZVCS_TIP", "KO_GAZVEZ_ANYAG", "KO_GAZVEZ_NYOMAS", "KO_GAZVEZETEK_ATMERO", "KO_GAZVEZETEK_NYOMAS", "KO_GEN_SZAB", "KO_GYARTO", "KO_GYSIN_ANYAG", "KO_GYSIN_ELREND", "KO_GYSIN_HELY", "KO_GYSIN_KIALAKITAS", "KO_GYSIN_KTG", "KO_GYSIN_TIP", "KO_HAJT_MOD", "KO_HAJT_TIP", "KO_HANGELL_TIP", "KO_HFKADO_TIP", "KO_HFKCSBER_TIP", "KO_HFKIKON_TIP", "KO_HFKRSON_TIP", "KO_HFKVBER_KTG", "KO_HFKVED_TIP", "KO_HOFOKVED_TIP", "KO_HUTESMOD", "KO_IDEGENESZK_TIP", "KO_IDEGENVEZ_TIP", "KO_IDESZK_TULAJDONOS", "KO_IDESZK_UZEMELTETO", "KO_INIS_MAP", "KO_INIS_OBJEKTUM", "KO_INVERTER_TIP", "KO_IVOLTO_KTG", "KO_IVOLTO_OLAJ", "KO_IVOLTO_SZAB", "KO_IVOLTO_TIP", "KO_JAV_BEAVATKOZASMOD", "KO_KABKAR_KTG", "KO_KABSZER_GYART", "KO_KABVEG_KTG", "KO_KABVEGELZ_TIP", "KO_KAPCS_CSOP", "KO_KAPCS_KTG", "KO_KAPCSOLO_FUNKCIO", "KO_KARMANTYU_TIP", "KO_KATEGORIA", "KO_KELO_SZEKRENY_TIP", "KO_KELO_TAP_LESZVEZ_TIP", "KO_KERESZT_TIP", "KO_KESZ_TIPUS_TIP", "KO_KOCKAZAT", "KO_KOCSITIP", "KO_KOFELO_TIP", "KO_KOMBIVALT_TIP", "KO_KONDEN_HELY", "KO_KONDEN_KTG", "KO_KONDENZ_TELJ", "KO_KONDENZ_TIP", "KO_KOTES_KTG", "KO_KOTES_TIP", "KO_LAMPAHELY_JELLEG", "KO_LAMPAHELY_TIP", "KO_LATEST_FENYELOSZLASTIP", "KO_LATEST_JAVITASMODOK", "KO_LATEST_TAVFELUGYELET", "KO_LEGJELZO_TIP", "KO_MADESZK_TIP", "KO_MAGNESKAP_TIP", "KO_MEGBIZHATOSAG", "KO_MEGSZAKITO_TIP", "KO_MEGSZHAJT_TIP", "KO_MERETEZES_HAL", "KO_MERETJEL_TIP", "KO_MERETVONAL_TIP", "KO_MEROVALT_HELY", "KO_MEROVALT_KTG", "KO_MEROVALT_TIP", "KO_MEZO_KITAPLALAS", "KO_MEZO_KTG", "KO_MEZO_MINOSITES", "KO_MEZO_REND", "KO_MEZO_TIP", "KO_MUSZERES_VIZSG_IDO", "KO_MUSZERES_VIZSG_MODOK", "KO_MV_ELHELY", "KO_NAPELEM_TIP", "KO_NEVL_ARAM", "KO_NEVL_ELLEN", "KO_NEVL_TELJ", "KO_NYILADEK_JEL", "KO_NYOMAS", "KO_NYOMSZAB_HELY", "KO_NYOMSZAB_KTG", "KO_NYOMSZAB_TIP", "KO_NYSZAB_ELHELY", "KO_NYV_VEZETEKJELLEG", "KO_OLAJ_KAT", "KO_OLAJ_KTG", "KO_OSZKAPCS_ELHELY_TIP", "KO_OSZKAPCS_HELY", "KO_OSZKAPCS_HOZZAVEZ_TIP", "KO_OSZKAPCS_TIP", "KO_RAJZJEL_TIP", "KO_RAJZVONAL_TIP", "KO_REZGCSILL_TIP", "KO_SCADA_KMOD", "KO_SEGEDUZEM_KIALAKITAS", "KO_STATUSZ", "KO_SUZELO_AUTOMATIKA", "KO_SUZELO_HELY", "KO_SUZELO_KIALAKITAS", "KO_SZABADTERI_ZJELZ_ENERG", "KO_SZABADTERI_ZJELZ_KOM", "KO_SZABADTERI_ZJELZ_TIP", "KO_SZABHAJT_TIP", "KO_SZAKASZHAJT_TIP", "KO_SZAKASZOLO_HELY", "KO_SZAKASZOLO_TIP", "KO_SZAKKAP_TIP", "KO_SZAKKAPCS_TIP", "KO_SZAMLALO_TIP", "KO_SZERELES_MOD", "KO_SZERELV_KTG", "KO_SZERELVENY_KTG", "KO_SZERELVENY_TIP", "KO_SZIGANYAG", "KO_SZIGETELO_FUNKCIO", "KO_SZIGKOZ", "KO_SZIGKOZEG", "KO_SZIGLANC_IRANY_TIP", "KO_SZINKOD", "KO_SZUKITO_TIP", "KO_TARTO_ALAP", "KO_TARTO_ANYAG", "KO_TARTO_CSUCSH", "KO_TARTO_FEJSZERK_TIP", "KO_TARTO_FELULET", "KO_TARTO_FELULETKEZELESEK", "KO_TARTO_FUNKCIO", "KO_TARTO_JELLEG", "KO_TARTO_KERESZTTARTO_TIP", "KO_TARTO_KOZOS", "KO_TARTO_KTG", "KO_TARTO_MADARVED_F_TIP", "KO_TARTO_MADARVED_T_TIP", "KO_TARTO_OLTOCSO", "KO_TARTO_OVEZ_KTART_ALATT_TIP", "KO_TARTO_OVEZ_KTART_FELETT_TIP", "KO_TARTO_TIP", "KO_TARTO_TULFESZ", "KO_TARTO_VILLBER_TIP", "KO_TARTOSZERKJELL", "KO_TARTOZEK_KTG", "KO_TARTOZEK_TIP", "KO_TARTSZIG_TIP", "KO_TARTSZKATEGORIA", "KO_TAVMUK_TIP", "KO_TEKERCS_KTG", "KO_TELEPITES", "KO_TELKOM_KTG", "KO_TELKOMSZER_TIP", "KO_TELKOMVEZ_TIP", "KO_TERSZAK_TIP", "KO_TESZT_FUNKCIO", "KO_TOKOZAS_TIP", "KO_TRAFO_ALAP", "KO_TRAFO_CSATLAKOZAS", "KO_TRAFO_CSPMOD", "KO_TRAFO_EROFORRJELL", "KO_TRAFO_HELY", "KO_TRAFO_HUTESMOD", "KO_TRAFO_KJELLEG", "KO_TRAFO_KTG", "KO_TRAFO_TAP_TIP", "KO_TRAFO_TELJ", "KO_TRAFO_TIP", "KO_TRAFO_TIPCSOP", "KO_TRALL_ALLAPOT", "KO_TRALL_GYART", "KO_TRALL_TIP", "KO_TRANSZ_KTG", "KO_TRFOKOZAT_KAP_TIP", "KO_TULAJDONOS", "KO_TULFESZ_HELY", "KO_TULFESZ_KTG", "KO_TULFESZ_TIP", "KO_TUZJELZO", "KO_TUZOLTO_TIP", "KO_UPS_ELHELY", "KO_UPS_KIALAKITAS", "KO_UPS_TELJ", "KO_UZEMELTETO", "KO_UZEMIRANYITO", "KO_UZEMMOD", "KO_VEDCSO_ANYAG", "KO_VEDCSO_ATMERO", "KO_VEDCSO_KTG", "KO_VEDELEM_HELY", "KO_VEDELEM_JELLEG", "KO_VEDELEM_KTG", "KO_VEDELEM_TIP", "KO_VEDOCSO_ANYAG", "KO_VEDOCSO_KTG", "KO_VEDOCSO_RETEG", "KO_VEDOCSO_TIP", "KO_VEDOVEZ_KTG", "KO_VEDOVEZET_TIP", "KO_VEZETEK_ANYAG", "KO_VEZETEK_ELREND", "KO_VEZETEK_FESZIT", "KO_VEZETEK_KER", "KO_VEZETEK_REND", "KO_VEZETEK_TECH", "KO_VEZETEK_TIP", "KO_VEZFESZ", "KO_VEZJOG_STATUSZ", "KO_ZARL_SZILARDSAG", "KO_ZARLATJELZ_TIP", "KO_ZAROLAS_OK", "KOF_CSATLAKOZOK", "KOF_CSATLAKOZOK_JOVO", "KOF_CSATLAKOZOK_MULT", "KOF_CSATLAKOZOK_SABL", "KOMB_MEROVALTOK", "KOMB_MEROVALTOK_JOVO", "KOMB_MEROVALTOK_MULT", "KOMB_MEROVALTOK_SABL", "KOMPLEX_BERENDEZESEK", "KOMPLEX_BERENDEZESEK_JOVO", "KOMPLEX_BERENDEZESEK_MULT", "KOMPLEX_BERENDEZESEK_SABL", "KONDENZATOR_EGYSEGEK", "KONDENZATOR_EGYSEGEK_JOVO", "KONDENZATOR_EGYSEGEK_MULT", "KONDENZATOR_EGYSEGEK_SABL", "KONDENZATOR_ESZK", "KONDENZATOR_ESZK_JOVO", "KONDENZATOR_ESZK_MULT", "KONDENZATOR_ESZK_SABL", "KONDENZATOROK", "KONDENZATOROK_JOVO", "KONDENZATOROK_MULT", "KONDENZATOROK_SABL", "KOZTERULET_ADATOK", "KOZTERULET_ADATOK_JOVO", "KOZTERULET_ADATOK_MULT", "KOZTERULET_ADATOK_SABL", "LAMPAHELYEK", "LAMPAHELYEK_JOVO", "LAMPAHELYEK_MULT", "LAMPAHELYEK_SABL", "LAMPATESTEK", "LAMPATESTEK_JOVO", "LAMPATESTEK_MULT", "LAMPATESTEK_SABL", "LEAGAZASI_PONTOK", "LEAGAZASI_PONTOK_JOVO", "LEAGAZASI_PONTOK_MULT", "LEAGAZASI_PONTOK_SABL", "MEGSZ_KOCSIK", "MEGSZ_KOCSIK_JOVO", "MEGSZ_KOCSIK_MULT", "MEGSZ_KOCSIK_SABL", "MEGSZAKITO_ESZK", "MEGSZAKITO_ESZK_JOVO", "MEGSZAKITO_ESZK_MULT", "MEGSZAKITO_ESZK_SABL", "MEGSZAKITOK", "MEGSZAKITOK_JOVO", "MEGSZAKITOK_MULT", "MEGSZAKITOK_SABL", "MEKH_ESZKOZKATALOGUS", "MEKH_LV_TOPOLOGY", "MEKH_LV_TOPOLOGY_TEMP", "MEKH_MV_TOPOLOGY", "MEKH_MV_TOPOLOGY_TEMP", "MEKH_MVLV_TR_LIST", "MEROVALTO_ESZK", "MEROVALTO_ESZK_JOVO", "MEROVALTO_ESZK_MULT", "MEROVALTO_ESZK_SABL", "META_ADATOK", "MEZOK", "MEZOK_JOVO", "MEZOK_MULT", "MEZOK_SABL", "MISZ_CSATLAKOZOSZERELESEK", "MISZ_KESZULEKHELYEK", "MISZ_SZERELESEK", "MOBIL_ADATCSEMPEK", "MOBIL_GPS_UT_PONTOK", "MOBIL_GPS_UTAK", "MOBIL_TERKEPEK", "MOBIL_TOROLT_OBJEKTUMOK", "MSCATALOG", "NAPELEMEK", "NAPELEMEK_JOVO", "NAPELEMEK_MULT", "NAPELEMEK_SABL", "NEPLAN_ADATOK", "NIS_ADATOK", "NYV_BERENDEZESEK", "NYV_BERENDEZESEK_JOVO", "NYV_BERENDEZESEK_KA", "NYV_BERENDEZESEK_MULT", "NYV_BERENDEZESEK_SABL", "NYV_BIZTOVEZETEK", "NYV_BIZTOVEZETEK_JOVO", "NYV_BIZTOVEZETEK_KA", "NYV_BIZTOVEZETEK_MULT", "NYV_BIZTOVEZETEK_SABL", "NYV_EAUTO_TOLTOK", "NYV_EAUTO_TOLTOK_JOVO", "NYV_EAUTO_TOLTOK_KA", "NYV_EAUTO_TOLTOK_MULT", "NYV_EAUTO_TOLTOK_SABL", "NYV_KANDELABEREK", "NYV_KANDELABEREK_JOVO", "NYV_KANDELABEREK_KA", "NYV_KANDELABEREK_MULT", "NYV_KANDELABEREK_SABL", "NYV_KIF_CSATLAKOZOK", "NYV_KIF_CSATLAKOZOK_JOVO", "NYV_KIF_CSATLAKOZOK_KA", "NYV_KIF_CSATLAKOZOK_MULT", "NYV_KIF_CSATLAKOZOK_SABL", "NYV_LAMPAHELYEK", "NYV_LAMPAHELYEK_JOVO", "NYV_LAMPAHELYEK_KA", "NYV_LAMPAHELYEK_MULT", "NYV_LAMPAHELYEK_SABL", "NYV_TARTOSZERKEZETEK", "NYV_TARTOSZERKEZETEK_JOVO", "NYV_TARTOSZERKEZETEK_KA", "NYV_TARTOSZERKEZETEK_MULT", "NYV_TARTOSZERKEZETEK_SABL", "NYV_VEDOCSOVEK", "NYV_VEDOCSOVEK_JOVO", "NYV_VEDOCSOVEK_KA", "NYV_VEDOCSOVEK_MULT", "NYV_VEDOCSOVEK_SABL", "NYV_VEZETEKEK", "NYV_VEZETEKEK_JOVO", "NYV_VEZETEKEK_KA", "NYV_VEZETEKEK_MULT", "NYV_VEZETEKEK_SABL", "OBJEKTUM_ADATREKORDOK", "OBJEKTUM_GEOMETRIAK", "OBJEKTUM_GEOMETRIAK_JOVO", "OBJEKTUM_GEOMETRIAK_MULT", "OBJEKTUM_GEOMETRIAK_SABL", "OBJEKTUM_GEOMETRIAK_SAVE", "OBJEKTUM_GEOMETRIAK_SZIMBOLIKA", "OBJEKTUM_GYUJTEMENY_SOROK", "OBJEKTUM_GYUJTEMENYEK", "OBJEKTUM_HIERARCHIA", "OBJEKTUM_HIERARCHIA_SAVE", "OBJEKTUM_KAPCSOLATOK", "OBJEKTUM_KIEMELESEK", "OBJEKTUM_REFERENCIAK", "OBJEKTUM_TOPOLOGIAK", "OBJEKTUM_TOPOLOGIAK_JOVO", "OBJEKTUM_TOPOLOGIAK_MULT", "OBJEKTUM_TOPOLOGIAK_SABL", "OBJEKTUM_TOPOLOGIAK_SAVE", "OC_ARAMVALT_TIP", "OC_BIZALJ_TIP", "OC_EROMU_TIP", "OC_FANOE_TIP", "OC_FESZVALT_TIP", "OC_FOJTO_TIP", "OC_FOLDELL_TIP", "OC_GYSIN_ANYAG", "OC_HANGELL_TIP", "OC_HFKV_TRAFO", "OC_IVOLTO_TIP", "OC_KABVEGELZ_TIP", "OC_KAPCS_CSOP", "OC_KONDENZ_TIP", "OC_MEGSZAKITO_TIP", "OC_MEROVALT_TIP", "OC_SZAKASZOLO_TIP", "OC_TERSZAK_TIP", "OC_TRAFO_TIP", "OC_TULFESZ_TIP", "OC_ZARLATJELZ_TIP", "OSZLOPKAPCSOLO_ESZK", "OSZLOPKAPCSOLO_ESZK_JOVO", "OSZLOPKAPCSOLO_ESZK_MULT", "OSZLOPKAPCSOLO_ESZK_SABL", "OSZLOPKAPCSOLOK", "OSZLOPKAPCSOLOK_JOVO", "OSZLOPKAPCSOLOK_MULT", "OSZLOPKAPCSOLOK_SABL", "RAJZJELEK", "RAJZJELEK_JOVO", "RAJZJELEK_MULT", "RAJZJELEK_SABL", "RAJZVONALAK", "RAJZVONALAK_JOVO", "RAJZVONALAK_MULT", "RAJZVONALAK_SABL", "RBM_KABEL_METSZESEK", "RBM_KABEL_NYOMVONALAK", "RBM_KABEL_SZAKASZOK", "RBM_KK_SZAKASZ_NYOMVONAL", "RBM_OK_SZAKASZOK", "RBM_SEPLAND_KIEMELESEK", "RBM_TMOK_SZAKASZOK", "REDLINE_ATTRIBUTUMOK", "REDLINE_SZIMBOLUMOK", "REDLINE_TRANZAKCIOK", "REDLINE_VONALAK", "RENDSZER_SZAKASZOK", "RENDSZER_SZAKASZOK_JOVO", "RENDSZER_SZAKASZOK_MULT", "RENDSZER_SZAKASZOK_SABL", "RENDSZEREK", "RENDSZEREK_JOVO", "RENDSZEREK_MULT", "RENDSZEREK_SABL", "RENDSZERPARAMETEREK1", "RENDSZERPARAMETEREK2", "SABLON_OBJEKTUMOK", "SABLONOK", "SEGEDUZ_ELOSZTOK", "SEGEDUZ_ELOSZTOK_JOVO", "SEGEDUZ_ELOSZTOK_MULT", "SEGEDUZ_ELOSZTOK_SABL", "SEGEDUZ_TRANSZFORMATOROK", "SEGEDUZ_TRANSZFORMATOROK_JOVO", "SEGEDUZ_TRANSZFORMATOROK_MULT", "SEGEDUZ_TRANSZFORMATOROK_SABL", "SEGEDVEZETEKEK", "SEGEDVEZETEKEK_JOVO", "SEGEDVEZETEKEK_MULT", "SEGEDVEZETEKEK_SABL", "SINFOGY_VEZETEKEK", "SINFOGY_VEZETEKEK_JOVO", "SINFOGY_VEZETEKEK_MULT", "SINFOGY_VEZETEKEK_SABL", "SZABADVEZETEKEK", "SZABADVEZETEKEK_JOVO", "SZABADVEZETEKEK_KA", "SZABADVEZETEKEK_MULT", "SZABADVEZETEKEK_SABL", "SZAKASZOLO_ESZK", "SZAKASZOLO_ESZK_JOVO", "SZAKASZOLO_ESZK_MULT", "SZAKASZOLO_ESZK_SABL", "SZAKASZOLO_KAPCSOLO_ESZK", "SZAKASZOLO_KAPCSOLO_ESZK_JOVO", "SZAKASZOLO_KAPCSOLO_ESZK_MULT", "SZAKASZOLO_KAPCSOLO_ESZK_SABL", "SZAKASZOLO_KAPCSOLOK", "SZAKASZOLO_KAPCSOLOK_JOVO", "SZAKASZOLO_KAPCSOLOK_MULT", "SZAKASZOLO_KAPCSOLOK_SABL", "SZAKASZOLOK", "SZAKASZOLOK_JOVO", "SZAKASZOLOK_MULT", "SZAKASZOLOK_SABL", "SZERELVENYEK", "SZERELVENYEK_JOVO", "SZERELVENYEK_MULT", "SZERELVENYEK_SABL", "SZIGETELOK", "SZIGETELOK_JOVO", "SZIGETELOK_MULT", "SZIGETELOK_SABL", "SZUNETMENTESEK", "SZUNETMENTESEK_JOVO", "SZUNETMENTESEK_MULT", "SZUNETMENTESEK_SABL", "TABLA_VERZIOK", "TARTOSZERKEZETEK", "TARTOSZERKEZETEK_JOVO", "TARTOSZERKEZETEK_KA", "TARTOSZERKEZETEK_MULT", "TARTOSZERKEZETEK_SABL", "TELKOM_SZERELVENYEK", "TELKOM_SZERELVENYEK_JOVO", "TELKOM_SZERELVENYEK_MULT", "TELKOM_SZERELVENYEK_SABL", "TELKOM_VEZETEKEK", "TELKOM_VEZETEKEK_JOVO", "TELKOM_VEZETEKEK_MULT", "TELKOM_VEZETEKEK_SABL", "TEMAKAPCSOLOK", "TEMP_ADAT_IMPORT_KORZETEK", "TEMP_CSV_TERKEP_MODOSITASOK", "TEMP_ELLENORZESEK", "TEMP_GISU_CSATOBJ", "TEMP_IDEGEN_E_J_MOD", "TEMP_KABCSONYOM_J_MOD", "TEMP_KERETEK", "TEMP_KORLATOZASI_TERULETEK_SZIM", "TEMP_MEZO_HIBA", "TEMP_MEZO_JAV", "TEMP_NYOMSZAK_J_MOD", "TEMP_NYV_KAPCS_OBJEKTUMOK", "TEMP_NYV_OSZLOPOK", "TEMP_NYV_TERKEP_MODOSITASOK", "TEMP_OBJEKTUMOK", "TEMP_OBJGEO_J_MOD", "TEMP_OBJGEO_VALTOZAS_LOG", "TEMP_SABLON_OBJ_AZON", "TEMP_SCADA_MEZONEV", "TEMP_TRALL_MOZGATAS", "TERKEPEK", "TOKOZOTT_BERENDEZESEK", "TOKOZOTT_BERENDEZESEK_JOVO", "TOKOZOTT_BERENDEZESEK_MULT", "TOKOZOTT_BERENDEZESEK_SABL", "TOPOLOGIA_BEJARASOK", "TRALLOMASOK", "TRALLOMASOK_JOVO", "TRALLOMASOK_MULT", "TRALLOMASOK_SABL", "TRANSZFORMATOR_ESZK", "TRANSZFORMATOR_ESZK_JOVO", "TRANSZFORMATOR_ESZK_MULT", "TRANSZFORMATOR_ESZK_SABL", "TRANSZFORMATOROK", "TRANSZFORMATOROK_JOVO", "TRANSZFORMATOROK_MULT", "TRANSZFORMATOROK_SABL", "TRANZAKCIOK", "TRANZAKCIOK_GISU", "TRANZAKCIOK_LOG", "TULFESZ_LEVEZETO_ESZK", "TULFESZ_LEVEZETO_ESZK_JOVO", "TULFESZ_LEVEZETO_ESZK_MULT", "TULFESZ_LEVEZETO_ESZK_SABL", "TULFESZ_LEVEZETOK", "TULFESZ_LEVEZETOK_JOVO", "TULFESZ_LEVEZETOK_MULT", "TULFESZ_LEVEZETOK_SABL", "UZEMVITELI_ADATOK", "VEDELMEK", "VEDELMEK_JOVO", "VEDELMEK_MULT", "VEDELMEK_SABL", "VEDOCSOVEK", "VEDOCSOVEK_JOVO", "VEDOCSOVEK_MULT", "VEDOCSOVEK_SABL", "VEDOVEZETOK", "VEDOVEZETOK_JOVO", "VEDOVEZETOK_MULT", "VEDOVEZETOK_SABL", "VONAL_BEJARAS", "VONAL_BEJARAS_OSZLOPOK", "VONAL_SZAKASZOK", "VONAL_SZAKASZOK_ALALLOM_INDUL", "VONAL_SZAKASZOK_JOVO", "VONAL_SZAKASZOK_KK_TRALL_OBJ", "VONAL_SZAKASZOK_KK_TRALL_VONAL", "VONAL_SZAKASZOK_MULT", "VONAL_SZAKASZOK_SABL", "VONAL_SZAKASZOK_TRALL", "VONAL_SZAKASZOK_TRALL_KAPCSFUN", "VONAL_SZAKASZOK_UPDATED_SAVED", "VONALAK", "VONALAK_JOVO", "VONALAK_MULT", "VONALAK_SABL", "ZARLATJELZOK", "ZARLATJELZOK_JOVO", "ZARLATJELZOK_MULT", "ZARLATJELZOK_SABL"
]

# COMMAND ----------

len(list2)

# COMMAND ----------

len(listnames)

# COMMAND ----------

differencees=set(list2).difference(set(listnames))

# COMMAND ----------

differencees

# COMMAND ----------

len(differencees)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC  landing

# COMMAND ----------

# MAGIC %md
# MAGIC these has duplicates:
# MAGIC 'v_edh_isu_gp_beziehung', 'v_edh_isu_steuer', 'v_edh_isu_zo_anlage', 'v_edh_isu_zo_betreiber', 'v_edh_isu_zo_markt', 'v_edh_isu_zo_weitere

# COMMAND ----------

# MAGIC %md
# MAGIC ErrorCode=DelimitedTextMoreColumnsThanDefined,'Type=Microsoft.DataTransfer.Common.Shared.HybridDeliveryException,Message=Error found when processing 'Csv/Tsv Format Text' source 'ZISU_MDAT_20240516_084644.csv' with row number 2384181: found more columns than expected column count 75.,Source=Microsoft.DataTransfer.Common,'

# COMMAND ----------


df_FOLD_SABLstd=spark.read.format('parquet').load(f'abfss://2444@stedhenis01extdev.dfs.core.windows.net/isu/FOLDELESEK_SABL.parquet')
df_FOLD_SABLt=spark.read.format('parquet').load(f'{storage_path}/FOLDELESEK_SABL.parquet')

df_FOLD_SABLt.createOrReplaceTempView(f'FOLD_SABLstd')

df_FOLD_SABLt.createOrReplaceTempView(f'FOLD_SABLt')

print('df_FOLD_SABLt')
# spark.sql(f'select ".NODE1", count(*) as cnt from zisu_mdat group by ".NODE1" having cnt>1').display()

# spark.sql(f'select * from FOLD_SABLt').display(5)

spark.sql(f'select * from FOLD_SABLstdt').display(5)

# COMMAND ----------


#std check

df_FOLD_SABLstd=spark.read.format('delta').load(storage_std_path)
# df_FOLD_SABLt=spark.read.format('parquet').load(f'{storage_path}/FOLDELESEK_SABL.parquet')
# df_FOLD_SABLstd=spark.read.format('delta').load('abfss://edh@stedhen2444stddev.dfs.core.windows.net/ingridgis/KO_SZABADTERI_ZJELZ_TIP')
df_FOLD_SABLstd=spark.read.format('delta').load('abfss://edh@stedhen2444stddev.dfs.core.windows.net/ingridgis/FOLDELESEK_SABL_rejected_records')
df_FOLD_SABLstd.createOrReplaceTempView(f'FOLD_SABLstd')

# df_FOLD_SABLt.createOrReplaceTempView(f'FOLD_SABLt')

print('df_FOLD_SABLstd')
# spark.sql(f'select ".NODE1", count(*) as cnt from zisu_mdat group by ".NODE1" having cnt>1').display()

# spark.sql(f'select * from FOLD_SABLt').display(5)

spark.sql(f'select * from FOLD_SABLstd').display(5)

# COMMAND ----------

#std check



df_ABLAK_ADATOK_rejected_records=spark.read.format('delta').load('abfss://edh@stedhen2444stddev.dfs.core.windows.net/ingridgis/ABLAK_ADATOK_rejected_records')

df_ABLAK_ADATOK_rejected_records=spark.read.format('delta').load('abfss://edh@stedhen2444stddev.dfs.core.windows.net/ingridgis/ABLAK_ADATOK')
df_ABLAK_ADATOK_rejected_records.createOrReplaceTempView(f'ABLAK_ADATOK_rejected_records')
df_ABLAK_ADATOK_rejected_records.createOrReplaceTempView(f'ABLAK_ADATOK')
# df_FOLD_SABLt.createOrReplaceTempView(f'FOLD_SABLt')

print('df_ABLAK_ADATOK_rejected_records')
# spark.sql(f'select ".NODE1", count(*) as cnt from zisu_mdat group by ".NODE1" having cnt>1').display()

# spark.sql(f'select * from FOLD_SABLt').display(5)

spark.sql(f'select count(*) from ABLAK_ADATOK_rejected_records').display(5)
spark.sql(f'select count(*) from ABLAK_ADATOK').display(5)


# COMMAND ----------

listStd=dbutils.fs.ls('abfss://edh@stedhen2444stddev.dfs.core.windows.net/ingridgis/')

# COMMAND ----------

res=[x.path for x in listStd if 'FOLDELESEK' in x.path]
res

# COMMAND ----------

res_rejected=[x.path for x in listStd if 'rejected' in x.path]
res_rejected

# COMMAND ----------

len(res_rejected)

# COMMAND ----------

dbutils.fs.ls('abfss://edh@stedhen2444stddev.dfs.core.windows.net/ingridgis/FOLDELESEK_SABL/')

# COMMAND ----------

spark.sql(f'select  MRRES,count(MRRES) as cnt from zisu_mdat group by MRRES having cnt>1').display(5)

# COMMAND ----------

df_zisu_mdat.show()

# COMMAND ----------

# MAGIC %md
# MAGIC --------------------------------------------------------------------------------------------------------------------------------------
# MAGIC check with incremental index the particular rows

# COMMAND ----------

from pyspark.sql.functions import lit,row_number,col
from pyspark.sql.window import Window
from pyspark.sql import functions as F

df_zisu_mdat = df_zisu_mdat.withColumn("_index", F.monotonically_increasing_id())

w = Window().partitionBy(lit('_index')).orderBy(lit('_index'))
# df1 = df_zisu_mdat.withColumn("row_num", row_number().over(w))

# df1.show()


# COMMAND ----------



df1.filter(col('row_num').between(2,4)).display()

# COMMAND ----------

df1 = df_zisu_mdat.withColumn("row_num", row_number().over(w))
df1.filter(col('_index').between(41160620,41160635)).display()

# COMMAND ----------

spark.sql(f'select count(*) from zisu_mdat').display()

# COMMAND ----------

df_zisu_mdat_dropped=spark.read.options(header=True, delimiter="|",mode="DROPMALFORMED").format('csv').load(f'abfss://2444@stedhenis01extdev.dfs.core.windows.net/isu/ZISU_MDAT_20240516_084644.csv')

df_zisu_mdat.createOrReplaceTempView(f'zisu_mdat_dr')
print('zisu_mdat')
spark.sql(f'select count(*) from zisu_mdat_dr').display()

# COMMAND ----------

df_zisu_mdat_dropped=spark.read.options(header=True, delimiter="|",LineSep="\n", maxColumns=75).format('csv').load(f'abfss://2444@stedhenis01extdev.dfs.core.windows.net/isu/ZISU_MDAT_20240516_084644.csv')

df_zisu_mdat.createOrReplaceTempView(f'zisu_mdat_s')
print('zisu_mdat')
spark.sql(f'select count(*) from zisu_mdat_s').display()

# COMMAND ----------

df_zisu_mdat_dropped=spark.read.options(header=True, delimiter="|",LineSep="\n", maxColumns=75,mode="DROPMALFORMED").format('csv').load(f'abfss://2444@stedhenis01extdev.dfs.core.windows.net/isu/ZISU_MDAT_20240516_084644.csv')

df_zisu_mdat.createOrReplaceTempView(f'zisu_mdat_s')
print('zisu_mdat')
spark.sql(f'select count(*) from zisu_mdat_s').display()

# COMMAND ----------

spark.sql(f'select * from zisu_mdat_s').display(5)

# COMMAND ----------

df_zisu_mdat_dropped=spark.read.options(header=True, delimiter="|",LineSep="\n", maxColumns=75,mode="PERMISSIVE").format('csv').load(f'abfss://2444@stedhenis01extdev.dfs.core.windows.net/isu/ZISU_MDAT_20240516_084644.csv')

from pyspark.sql import functions as F

df_zisu_mdat_dropped=spark.read.options(header=True, delimiter="|").format('csv').load(f'abfss://2444@stedhenis01extdev.dfs.core.windows.net/isu/ZISU_MDAT_20240516_084644.csv')

# Function to get rows at `rownums`
def getrows(df, rownums=None):
    return df.filter(df["_index"].isin(rownums))

# Add an index column to the DataFrame
df_zisu_mdat_dropped = df_zisu_mdat_dropped.withColumn("_index", F.monotonically_increasing_id())


df_zisu_mdat_dropped.createOrReplaceTempView(f'zisu_mdat_spermDROPPED')
print('zisu_mdat')
spark.sql(f'select * from zisu_mdat_spermDROPPED').display()

# COMMAND ----------

spark.sql(f'select * from zisu_mdat_spermDROPPED WHERE _index=41160626').display()

# COMMAND ----------

df_zisu_mdat_dropped=spark.read.options(header=True, delimiter="|",LineSep="\n", maxColumns=75,mode="FAILFAST").format('csv').load(f'abfss://2444@stedhenis01extdev.dfs.core.windows.net/isu/ZISU_MDAT_20240516_084644.csv')

df_zisu_mdat.createOrReplaceTempView(f'zisu_mdat_sss')
print('zisu_mdat')
spark.sql(f'select count(*) from zisu_mdat_sss').display()

# COMMAND ----------

# MAGIC %md
# MAGIC ErrorCode=DelimitedTextMoreColumnsThanDefined,'Type=Microsoft.DataTransfer.Common.Shared.HybridDeliveryException,Message=Error found when processing 'Csv/Tsv Format Text' source 'ZISU_MDAT_20240516_084644.csv' with row number 41160627: found more columns than expected column count 75.,Source=Microsoft.DataTransfer.Common,'

# COMMAND ----------

from pyspark.sql import functions as F

df=spark.read.options(header=True, delimiter="|").format('csv').load(f'abfss://2444@stedhenis01extdev.dfs.core.windows.net/isu/ZISU_MDAT_20240516_084644.csv')

# Function to get rows at `rownums`
def getrows(df, rownums=None):
    return df.filter(df["_index"].isin(rownums))

# Add an index column to the DataFrame
df = df.withColumn("_index", F.monotonically_increasing_id())

# Get rows at positions 0 and 2.
getrows(df, rownums=[0, 2]).collect()

# COMMAND ----------

getrows(df, rownums=[2384180,2384181,2384182]).collect()

# COMMAND ----------

df.createOrReplaceTempView(f'zisu_mdat')
print('zisu_mdat')

spark.sql(f'select * from zisu_mdat where _index=2384180').display()
spark.sql(f'select * from zisu_mdat where _index=2384181').display()

# COMMAND ----------

spark.sql(f'select * from zisu_mdat where _index=2384180').display()
spark.sql(f'select * from zisu_mdat where _index=2384181').display()

# COMMAND ----------

spark.sql(f'select * from zisu_mdat where _index=1').display()

# COMMAND ----------

getrows(df, rownums=[2384181]).collect()

# COMMAND ----------

# MAGIC %md
# MAGIC LANDING
# MAGIC

# COMMAND ----------


df_zisu_mdat=spark.read.format('parquet').load(f'abfss://test@stedhenis01landdev.dfs.core.windows.net/test/ZISU_MDAT-00001')
df_zisu_mdat=spark.read.format('parquet').load(f'abfss://isu@stedhenis01landdev.dfs.core.windows.net/hen/2024/06/12/EPROFHEAD.parquet')
df_zisu_mdat.createOrReplaceTempView(f'zisu_mdat1')
# print('zisu_mdat')
# spark.sql(f'select ".NODE1", count(*) as cnt from zisu_mdat group by ".NODE1" having cnt>1').display()

df_zisu_mdat=spark.read.format('parquet').load(f'abfss://test@stedhenis01landdev.dfs.core.windows.net/test/ZISU_MDAT-00002')

df_zisu_mdat.createOrReplaceTempView(f'zisu_mdat2')

spark.sql(f'select count(*) from zisu_mdat1').display()

spark.sql(f'select count(*) from zisu_mdat1 as zm1 inner join zisu_mdat2 as zm2 on zm1.ABLBELNR=zm2.ABLBELNR ').display()

# COMMAND ----------

# MAGIC %md
# MAGIC ######check for NODE1
# MAGIC "IPMSQNOFHDR","IPMSQNOHDR","IPMSQWOPER","IV_MPLA",

# COMMAND ----------


IPMSQWOPER=spark.read.format('delta').load(f'abfss://eam@stedhenedisconsqas.dfs.core.windows.net/NonPII/IPMSQWOPER/')
IPMSQWOPER.createOrReplaceTempView(f'IPMSQWOPER')
print(table)
spark.sql(f'select ".NODE1", count(*) as cnt from IPMSQWOPER group by ".NODE1" having cnt>1').display()



# COMMAND ----------

IV_MPLA.columns

# COMMAND ----------

#s4u  edi

storageacc=f's4u@stedhenediscons{env}'

dbutils.fs.ls(f'abfss://{storageacc}.dfs.core.windows.net/NonPII/')

# COMMAND ----------

storageacc=f's4u@stedhenediscons{env}'

#"DLCO_V_ACDOCA","DLCO_V_COOI",
tables=["C_EDH_Business_Asset","C_EDH_Measure","C_EDH_Status","DLCO_V_CSKB","DLCO_V_CSKT","DLCO_V_CSLA","DLCO_V_CSLT","DLCO_V_CSSL","DLCO_V_PROJ","DLCO_V_PRPS","DLFI_V_BKPF","DLFI_V_BSEG","DLFI_V_BSET","DLFI_V_BSID","DLFI_V_BVOR","DLFI_V_SKB1","DLFI_V_T001","DLMM_V_EBAN","DLMM_V_EKKO","DLMM_V_EKPO","DLSD_V_VBAK","DLSD_V_VBAP","DLSD_V_VBRK","DLSD_V_VBRP"]



#maincotroltable
# tablesALL=[
# /EON/DLCO_V_ACDOCA /EON/DLCO_V_COOI /EON/DLCO_V_CSKB /EON/DLCO_V_CSKT /EON/DLCO_V_CSLA /EON/DLCO_V_CSLT /EON/DLCO_V_CSSL /EON/DLCO_V_PROJ /EON/DLCO_V_PRPS /EON/DLFI_V_BKPF /EON/DLFI_V_BSEG /EON/DLFI_V_BSET /EON/DLFI_V_BSID /EON/DLFI_V_BVOR /EON/DLFI_V_SKB1 /EON/DLFI_V_T001 /EON/DLMM_V_EBAN /EON/DLMM_V_EKKO /EON/DLMM_V_EKPO /EON/DLSD_V_VBAK /EON/DLSD_V_VBAP /EON/DLSD_V_VBRK /EON/DLSD_V_VBRP /KAW/C_EDH_Business_Asset /KAW/C_EDH_Measure /KAW/C_EDH_Status AUFK CCVDOCOBJATTCHDE  JCDS JEST JSTO TJ30T  EKKN]
nonTables=[]



checkMandt(tables,storageacc)

# COMMAND ----------

len(tables)

# COMMAND ----------

# "DLCO_V_ACDOCA","DLCO_V_COOI"
storageacc=f's4u@stedhenediscons{env}'

df_acdoca=spark.read.format('delta').load(f'abfss://{storageacc}.dfs.core.windows.net/NonPII/DLCO_V_ACDOCA/')
df_acdoca.createOrReplaceTempView(f'df_acdoca_table')
print(table)
spark.sql(f'select ".NODE1", count(*) as cnt from df_acdoca_table group by ".NODE1" having cnt>1').display()

DLCO_V_COOI=spark.read.format('delta').load(f'abfss://{storageacc}.dfs.core.windows.net/NonPII/DLCO_V_COOI/')
DLCO_V_COOI.createOrReplaceTempView(f'DLCO_V_COOI')
print(table)
spark.sql(f'select ".NODE1", count(*) as cnt from DLCO_V_COOI group by ".NODE1" having cnt>1').display()


# COMMAND ----------

df_acdoca.columns

# COMMAND ----------

DLCO_V_COOI.columns

# COMMAND ----------

# MAGIC %md
# MAGIC #####further analyzes

# COMMAND ----------

storageacc=f's4u@stedhenavaconcons{env}'
tables=["DLCO_V_ACDOCA",'DLCO_V_ACDOCP']
# tables=["DLCO_V_ACDOCA",'DLCOSQACDCA']   edis

checkColumn(tables,storageacc,'".NODE1"')
checkColumn(tables,storageacc,'RCLNT')

# COMMAND ----------

storageacc=f's4u@stedhenediscons{env}'

tables=["DLCO_V_ACDOCA"]   

checkColumn(tables,storageacc,'".NODE1"')
checkColumn(tables,storageacc,'RCLNT')

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog edh_en_consumption_dev;
# MAGIC
# MAGIC use schema 2444_ingridgis;

# COMMAND ----------

# MAGIC %sql
# MAGIC show tables

# COMMAND ----------

