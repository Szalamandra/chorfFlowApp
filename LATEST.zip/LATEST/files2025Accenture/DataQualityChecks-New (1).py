# Databricks notebook source
dbutils.widgets.removeAll()
#dbutils.secrets.listScopes()

# COMMAND ----------

from pyspark.context import SparkContext
from pyspark.sql.session import SparkSession

class ConfigHandler():
    def __init__(self):
        sc = SparkContext.getOrCreate()
        self.spark = SparkSession(sc)
        try:
            from pyspark.dbutils import DBUtils
            self.dbutils = DBUtils(self.spark)
        except ImportError:
            import IPython
            self.dbutils = IPython.get_ipython().user_ns["dbutils"]

    def set_credentials(self, scope, storage_account, client_id, client_secret, tenant_id):
        client_id = self.dbutils.secrets.get(scope=scope, key=client_id)
        client_secret = self.dbutils.secrets.get(scope=scope, key=client_secret)
        sp_app_id =  self.dbutils.secrets.get(scope=scope,key="SP-INTEGRATION-APP-ID")
        ap_secret =  self.dbutils.secrets.get(scope=scope,key="SP-INTEGRATION-SECRET")

        self.spark.conf.set(f"fs.azure.account.auth.type.{storage_account}.dfs.core.windows.net", "OAuth")
        self.spark.conf.set(f"fs.azure.account.oauth.provider.type.{storage_account}.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
        self.spark.conf.set(f"fs.azure.account.oauth2.client.id.{storage_account}.dfs.core.windows.net", sp_app_id)
        self.spark.conf.set(f"fs.azure.account.oauth2.client.secret.{storage_account}.dfs.core.windows.net", ap_secret)
        self.spark.conf.set(f"fs.azure.account.oauth2.client.endpoint.{storage_account}.dfs.core.windows.net", f"https://login.microsoftonline.com/{tenant_id}/oauth2/token")

# COMMAND ----------

dbutils.widgets.text('widget_storage_name', 'stedhenshngconsdev', '1. Name of Storage Account')
dbutils.widgets.text('widget_source', 'edh', '2. Source of Data')
dbutils.widgets.text('widget_source_folder', 'eam', '3. Source Folder')
dbutils.widgets.text('widget_zone', 'consumption', '4. Zone')
#dbutils.widgets.text('widget_relative_path', 'NonPII/vendor_order', '5. Relative Path')
dbutils.widgets.text('widget_secret_scope', 'kv-edhen-euw-dev-is01', '6. Secret Scope')

STORAGE_ACCOUNT_NAME = dbutils.widgets.get("widget_storage_name")
SOURCE_CONTAINER = dbutils.widgets.get("widget_source")
SOURCE_FOLDER=dbutils.widgets.get("widget_source_folder")
SOURCE_ZONE=dbutils.widgets.get("widget_zone")
#RELATIVE_PATH = dbutils.widgets.get("widget_relative_path")
SECRET_SCOPE = dbutils.widgets.get("widget_secret_scope")

ConfigHandler().set_credentials(SECRET_SCOPE, STORAGE_ACCOUNT_NAME, 'SP-INTEGRATION-APP-ID', 'SP-INTEGRATION-SECRET', 'b914a242-e718-443b-a47c-6b4c649d8c0a')

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC --SELECT count(*) FROM delta.`abfss://telefoniedb@stedhenwestnetzconsrun.dfs.core.windows.net/NonPII/tel_wn_callflow/` --ORDER BY datetime DESC 
# MAGIC --486707 on 16th Oct

# COMMAND ----------

# MAGIC %md
# MAGIC ## **Get empty table list**

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType,LongType, TimestampType
from pyspark.sql.functions import regexp_replace, lit, count

# list of empty tables
def df_files(path):
    try:
            #path = "abfss://iconnect@stedhenedisconsqas.dfs.core.windows.net/NonPII/"
            files = dbutils.fs.ls(path)

            ddlSchema = StructType([
                StructField('path',StringType()),
                StructField('name',StringType()),
                StructField('size',LongType()),
                StructField('modtime', LongType())
                    ])
    #yy:mm:dd:hh:min:sec

            df = spark.createDataFrame(files,ddlSchema)
            return df
        
    except:
        print("table path is not correct")

def empty_tables(zone,path):
    try:
        
        empty_table_schema = StructType([
            StructField('zone',StringType()),
            StructField('empty_table',StringType())
            ])
        
        empty_table_df = spark.createDataFrame([], empty_table_schema)
        df = df_files(path)
        path_li = df.select("path").collect()
        name_li = df.select("name").collect()
        for i in range(0,len(path_li)):
            if zone == "landing":
                df = spark.read.format("parquet").load(path_li[i][0])
                if df.count() ==0:
                    cols = ["zone","empty_table"]
                    empty_table = name_li[i][0]
                    table_df = spark.createDataFrame([[zone,empty_table]], cols)
                    empty_table_df = empty_table_df.union(table_df)
            else:
                df = spark.read.format("delta").load(path_li[i][0])
                if df.count() ==0:
                    cols = ["zone","empty_table"]
                    empty_table = name_li[i][0]
                    table_df = spark.createDataFrame([[zone,empty_table]], cols)
                    empty_table_df = empty_table_df.union(table_df)
                
        empty_table_df = empty_table_df.withColumn("empty_table", regexp_replace("empty_table","(/$)|(.parquet)$", ""))
        empty_table_df.display() 
    except:
        print("error in finding empty tables")

# COMMAND ----------

# MAGIC %md
# MAGIC ### **List of the empty tables**

# COMMAND ----------


print(STORAGE_ACCOUNT_NAME,' - ',SOURCE_FOLDER)
table_path=f"abfss://edh@{STORAGE_ACCOUNT_NAME}.dfs.core.windows.net/{SOURCE_FOLDER}/"
empty_tables(SOURCE_ZONE, table_path)
print("rows in tables in a zone")

# COMMAND ----------

# MAGIC %md
# MAGIC Tables and fields counts

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, LongType
from pyspark.sql.functions import regexp_replace

# List of files in the given path
def df_files(path):
    try:
        files = dbutils.fs.ls(path)
        ddlSchema = StructType([
            StructField('path', StringType()),
            StructField('name', StringType()),
            StructField('size', LongType()),
            StructField('modtime', LongType())
        ])
        df = spark.createDataFrame(files, ddlSchema)
        return df
    except:
        print("Table path is not correct")

def table_field_counts(zone, path):
    try:
        table_schema = StructType([
            StructField('zone', StringType()),
            StructField('table_name', StringType()),
            StructField('field_count', LongType())
        ])
        
        table_df = spark.createDataFrame([], table_schema)
        df = df_files(path)
        path_li = df.select("path").collect()
        name_li = df.select("name").collect()
        
        for i in range(len(path_li)):
            if zone == "landing":
                df = spark.read.format("parquet").load(path_li[i][0])
            else:
                df = spark.read.format("delta").load(path_li[i][0])
            
            field_count = len(df.columns)
            table_name = name_li[i][0]
          
            cols = ["zone", "table_name", "field_count"]
            if table_name != 'volumeMetrics/':
                temp_df = spark.createDataFrame([[zone, table_name, field_count]], cols)
                table_df = table_df.union(temp_df)
        
        table_df = table_df.withColumn("table_name", regexp_replace("table_name", "(/$)|(.parquet)$", ""))
        display(table_df)
    except Exception as e:
        print(f"Error in finding table fields: {e}")

# Example usage
# STORAGE_ACCOUNT_NAME = "your_storage_account_name"  # Replace with your actual storage account name
table_path = f"abfss://{SOURCE_CONTAINER}@{STORAGE_ACCOUNT_NAME}.dfs.core.windows.net/{SOURCE_FOLDER}/"
print(table_path)
table_field_counts(SOURCE_ZONE, table_path)
print("Number of fields in tables in a zone")

# COMMAND ----------

# MAGIC %md
# MAGIC Record counts of tables

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, LongType
from pyspark.sql.functions import regexp_replace

# List of files in the given path
def df_files(path):
    try:
        files = dbutils.fs.ls(path)
        ddlSchema = StructType([
            StructField('path', StringType()),
            StructField('name', StringType()),
            StructField('size', LongType()),
            StructField('modtime', LongType())
        ])
        df = spark.createDataFrame(files, ddlSchema)
        return df
    except:
        print("Table path is not correct")

def table_record_counts(zone, path):
    try:
        table_schema = StructType([
            StructField('zone', StringType()),
            StructField('table_name', StringType()),
            StructField('record_count', LongType())
        ])
        
        table_df = spark.createDataFrame([], table_schema)
        df = df_files(path)
        path_li = df.select("path").collect()
        name_li = df.select("name").collect()
        
        for i in range(len(path_li)):
            if zone == "landing":
                df = spark.read.format("parquet").load(path_li[i][0])
            else:
                df = spark.read.format("delta").load(path_li[i][0])
            
            record_count = df.count()
            table_name = name_li[i][0]
          
            cols = ["zone", "table_name", "record_count"]
            if table_name != 'volumeMetrics/':
                temp_df = spark.createDataFrame([[zone, table_name, record_count]], cols)
                table_df = table_df.union(temp_df)
        
        table_df = table_df.withColumn("table_name", regexp_replace("table_name", "(/$)|(.parquet)$", ""))
        display(table_df)
    except:
        print("Error in finding table records")

# COMMAND ----------

# MAGIC %md
# MAGIC Record count in Consumption

# COMMAND ----------


#STORAGE_ACCOUNT_NAME = "your_storage_account_name"  # Replace with your actual storage account name
table_path = f"abfss://{SOURCE_CONTAINER}@{STORAGE_ACCOUNT_NAME}.dfs.core.windows.net/{SOURCE_FOLDER}/"
print(table_path)
table_record_counts(SOURCE_ZONE, table_path)
print("Rows in tables in a zone")

# COMMAND ----------

# MAGIC %md
# MAGIC Table records counts and duplicates

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, LongType
from pyspark.sql.functions import regexp_replace, col

# List of files in the given path
def df_files(path):
    try:
        files = dbutils.fs.ls(path)
        ddlSchema = StructType([
            StructField('path', StringType()),
            StructField('name', StringType()),
            StructField('size', LongType()),
            StructField('modtime', LongType())
        ])
        df = spark.createDataFrame(files, ddlSchema)
        return df
    except:
        print("Table path is not correct")

def tables_with_duplicates(zone, path):
    try:
        table_schema = StructType([
            StructField('zone', StringType()),
            StructField('table_name', StringType())
            # StructField('record_count', LongType()),
            # StructField('duplicate_count', LongType())
        ])
        
        table_df = spark.createDataFrame([], table_schema)
        #combined_df=spark.createDataFrame([], table_schema)
        df = df_files(path)
        path_li = df.select("path").collect()
        name_li = df.select("name").collect()
        
        for i in range(len(path_li)):
            if zone == "landing":
                df = spark.read.format("parquet").load(path_li[i][0])
            else:
                df = spark.read.format("delta").load(path_li[i][0])
                     
            #record_count = df.count()
            #duplicates_df = df.groupBy(df.columns).count().filter(col("count") > 1).count()
            duplicates_df = df.groupBy(df.columns).count().filter(col("count") > 1)
            # Identify duplicate records
           # duplicates_df = df.groupBy(df.columns).agg(count(df.columns).alias("count")).filter(col("count") > 1)
            print(name_li[i][0],duplicates_df.count())
            if duplicates_df.count() > 0:
                table_name = name_li[i][0]                
                cols = ["zone", "table_name"]
                incremental_df  = spark.createDataFrame([[zone, table_name]], cols)                
                combined_df  = table_df.union(incremental_df)
                table_df = combined_df           
                
        
        combined_df = combined_df.withColumn("table_name", regexp_replace("table_name", "(/$)|(.parquet)$", ""))
        display(combined_df)
    except:
        print("Error in finding table records")


# COMMAND ----------

# STORAGE_ACCOUNT_NAME = "your_storage_account_name"  # Replace with your actual storage account name
print(SOURCE_CONTAINER,' ',STORAGE_ACCOUNT_NAME,' ',SOURCE_FOLDER)
table_path = f"abfss://{SOURCE_CONTAINER}@{STORAGE_ACCOUNT_NAME}.dfs.core.windows.net/{SOURCE_FOLDER}/"
print(table_path)
tables_with_duplicates(SOURCE_ZONE, table_path)
print("Rows and duplicates in tables in a zone")

# COMMAND ----------

display(df_files(table_path))

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Find Distinct value of a field like MANDT**

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, LongType
from pyspark.sql.functions import col, regexp_replace

# List of files in the given path
def df_files(path):
    try:
        files = dbutils.fs.ls(path)
        ddlSchema = StructType([
            StructField('path', StringType()),
            StructField('name', StringType()),
            StructField('size', LongType()),
            StructField('modtime', LongType())
        ])
        df = spark.createDataFrame(files, ddlSchema)        
        return df
    except Exception as e:
        print(f"Table path is not correct: {e}")

def distinct_field_values(zone, path, field_name):
    try:
        table_schema = StructType([
            StructField('table_name', StringType()),
            StructField('distinct_value', StringType())
        ])
        
        table_df = spark.createDataFrame([], table_schema)
        df = df_files(path)
        path_li = df.select("path").collect()
        name_li = df.select("name").collect()
        
        for i in range(len(path_li)):
            if zone == "landing":
                df = spark.read.format("parquet").load(path_li[i][0])
            else:
                df = spark.read.format("delta").load(path_li[i][0])
            if field_name in df.columns:
                distinct_values_df = df.select(field_name).distinct()
                table_name = name_li[i][0]
            
                for row in distinct_values_df.collect():                  
                    distinct_value = row[field_name]                   
                    temp_df = spark.createDataFrame([[table_name, distinct_value]], table_schema)                   
                    table_df = table_df.union(temp_df)
                   
            else:
                print(f"Field '{field_name}' not found in table '{name_li[i][0]}'")
        table_df = table_df.withColumn("table_name", regexp_replace("table_name", "(/$)|(.parquet)$", ""))
        display(table_df)
    except Exception as e:
        print(f"Error in finding distinct values: {e}")

# COMMAND ----------

# STORAGE_ACCOUNT_NAME = "your_storage_account_name"  # Replace with your actual storage account name
print(SOURCE_CONTAINER,' ',STORAGE_ACCOUNT_NAME,' ',SOURCE_FOLDER)
table_path = f"abfss://{SOURCE_CONTAINER}@{STORAGE_ACCOUNT_NAME}.dfs.core.windows.net/{SOURCE_FOLDER}/"
print(table_path)
field_name='MANDT'
distinct_field_values(SOURCE_ZONE, table_path,field_name)
print("Rows and duplicates in tables in a zone")

# COMMAND ----------

net_type=SECRET_SCOPE.split('-')[1]
bu_name=STORAGE_ACCOUNT_NAME.replace(f'st{net_type}','').replace

# COMMAND ----------

bu_li=['bag','ava','edi','wez','westnetz','vse','haw','shng']

bu_name=[bu_name for bu_name in bu_li if bu_name in table_path][0]
print(bu_name)

# COMMAND ----------

# MAGIC %md
# MAGIC Finding filter criterias

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, LongType
from pyspark.sql.functions import col, regexp_replace,isnull,lit

view_without_filter_li=["DLCA_V_JCDS","DLCA_V_JEST","DLCA_V_JSTO","DLCA_V_TJ02T","DLCA_V_TJ30","DLCA_V_TJ30T","DLCO_V_PRHI","DLCO_V_PROJ","DLFI_V_SETHEADER","DLFI_V_SETLEAF","DLLO_V_KNVP","DLLO_V_LFA1_1","DLSD_V_VBAK","DLSD_V_VBAP","DLSD_V_VBFA","DLSD_V_VBRP"]


view_with_BUKRS_li=["DLCO_V_ACDOCA","DLCO_V_ACDOCP","DLCO_V_AUFK","DLCO_V_COEP","DLCO_V_COOI","DLCO_V_COSP","DLCO_V_COSS","DLCO_V_COVP","DLCO_V_CSKS","DLFI_V_ANLA","DLFI_V_BKPF","DLFI_V_BSAD","DLFI_V_BSAK","DLFI_V_BSAS","DLFI_V_BSEG","DLFI_V_BSET","DLFI_V_BSID","DLFI_V_BSIK","DLFI_V_BSIS","DLFI_V_BVOR","DLFI_V_SKB1","DLFI_V_T001","DLLO_V_KNB1","DLLO_V_LFB1","DLMM_V_EBAN","DLMM_V_EKKO","DLMM_V_EKPO","DLSD_V_VBRK"]

view_with_kokrs_li=["DLCO_V_COBK","DLCO_V_COEJ","DLCO_V_CSKB","DLCO_V_CSKT","DLCO_V_CSLA","DLCO_V_CSLT","DLCO_V_CSSL","DLMM_V_EKKN","DLSD_V_VBAK","DLSD_V_VBRP"]
#make it complerte
bu_li=['bag','ava','edi','wez','westnetz','vse','haw','shng']






# List of files in the given path
def df_files(path):
    try:
        files = dbutils.fs.ls(path)
        ddlSchema = StructType([
            StructField('path', StringType()),
            StructField('name', StringType()),
            StructField('size', LongType()),
            StructField('modtime', LongType())
        ])
        df = spark.createDataFrame(files, ddlSchema)        
        return df
    except Exception as e:
        print(f"Table path is not correct: {e}")

def distinct_filter_values(zone, path):
    view_without_filter_li=["DLCA_V_JCDS","DLCA_V_JEST","DLCA_V_JSTO","DLCA_V_TJ02T","DLCA_V_TJ30","DLCA_V_TJ30T","DLCO_V_PRHI","DLCO_V_PROJ","DLFI_V_SETHEADER","DLFI_V_SETLEAF","DLLO_V_KNVP","DLLO_V_LFA1_1","DLSD_V_VBAK","DLSD_V_VBAP","DLSD_V_VBFA","DLSD_V_VBRP","volumeMetrics"]


    view_with_BUKRS_li=["DLCO_V_AUFK","DLCO_V_COEP","DLCO_V_COOI","DLCO_V_COSP","DLCO_V_COSS","DLCO_V_COVP","DLCO_V_CSKS","DLFI_V_ANLA","DLFI_V_BKPF","DLFI_V_BSAD","DLFI_V_BSAK","DLFI_V_BSAS","DLFI_V_BSEG","DLFI_V_BSET","DLFI_V_BSID","DLFI_V_BSIK","DLFI_V_BSIS","DLFI_V_BVOR","DLFI_V_SKB1","DLFI_V_T001","DLLO_V_KNB1","DLLO_V_LFB1","DLMM_V_EBAN","DLMM_V_EKKO","DLMM_V_EKPO","DLSD_V_VBRK"]

    view_with_kokrs_li=["DLCO_V_COBK","DLCO_V_COEJ","DLCO_V_CSKB","DLCO_V_CSKT","DLCO_V_CSLA","DLCO_V_CSLT","DLCO_V_CSSL","DLMM_V_EKKN","DLSD_V_VBAK","DLSD_V_VBRP"]

    view_with_rbukr_li=["DLCO_V_ACDOCA","DLCO_V_ACDOCP"]

    view_with_pbukr_li=["DLCO_V_PRPS"]

    view_with_vbukr_li=["DLCO_V_PROJ"]

    view_with_ktopl_li=["DLCO_V_CSKA_1","DLCO_V_CSKU","DLFI_V_SKA1","DLFI_V_SKAT"]

    
    
    try:
        table_schema = StructType([
            StructField('table_name', StringType()),
            StructField('distinct_value', StringType())
        ])
        
        table_df = spark.createDataFrame([], table_schema)
        df = df_files(path)
        path_li = df.select("path").collect()
        name_li = df.select("name").collect()
        field_name=''
        for i in range(len(path_li)):
            if zone == "landing":
                df = spark.read.format("parquet").load(path_li[i][0])
                bu_name=[bu_name for bu_name in bu_li if bu_name in SOURCE_FOLDER][0]
                print(bu_name)    #remove
            else:
                df = spark.read.format("delta").load(path_li[i][0])
                bu_name=[bu_name for bu_name in bu_li if bu_name in STORAGE_ACCOUNT_NAME][0]
                

            table_name = name_li[i][0].replace("/", "")
            print(table_name)
            
            if table_name not in view_without_filter_li:
                if table_name in view_with_BUKRS_li:
                    field_name="BUKRS"
                elif table_name in view_with_kokrs_li:
                    field_name="KOKRS"
                elif table_name in view_with_rbukr_li:
                    field_name="RBUKRS"
                elif table_name in view_with_pbukr_li:
                    field_name="PBUKR"
                elif table_name in view_with_vbukr_li:
                    field_name="VBUKR"
                elif table_name in view_with_ktopl_li:
                    field_name="KTOPL"
                else:    
                    print(f"Filter criteria not found in table '{name_li[i][0]}'")
                
            
                distinct_values_df = df.select(field_name).fillna({field_name: "unknown"}).distinct() 
                # empty_or_null_df = df.filter(field_name.isNull().lit('string') | field_name=='').select(field_name)
                # distinct_values_df = distinct_df.union(empty_or_null_df).distinct() 
                display(distinct_values_df)
                        
                    
                    
                for row in distinct_values_df.collect():
                    if SOURCE_FOLDER == 'eam':
                        if bu_name == 'bag':
                            filter_value = [1800,3190]
                        elif bu_name == 'ava':
                            filter_value = '0901'
                        elif bu_name == 'edi':
                            filter_value =1101
                        elif bu_name == 'wez':
                            filter_value = 2200
                        elif bu_name == 'vse':
                            filter_value = [2400,2401,2402,2403]
                        elif bu_name == 'haw' or bu_name == 'shng':
                            filter_value = [1501,1504,1505,1552,1556,1570,1571,1572,'ECOA','106N']
                        else:
                            filter_value = []
                    else:
                        if bu_name == 'bag':
                            filter_value = [1800,3605,3606,3620,7039,7036,3140,3196,3636,3621,3631,3602,3190,3603,7033,7032,7034,7045]
                        elif bu_name == 'ava':
                            filter_value = '0901'
                        elif bu_name == 'edi':
                            filter_value = 1101
                        elif bu_name == 'edg':
                            filter_value = 7600
                        elif bu_name == 'wez':
                            filter_value = 2200
                        elif bu_name == 'vse':
                            filter_value = [2400,2401,2402,2403]
                        elif bu_name == 'haw' or bu_name == 'shng':
                            filter_value = ['1501','1504','1505','1552','1556','1570','1571','1572','ECOA','106N']  
                        else:
                            filter_value = '' 

                    distinct_value = row[field_name] 
                    if distinct_value not in filter_value:                    #should i take off hte strip?       
                        print(f"Filter criteria wrong in table '{name_li[i][0]}'")                  
                    temp_df = spark.createDataFrame([[table_name, distinct_value]], table_schema)                   
                    table_df = table_df.union(temp_df)
            else:    
                print(f"Filter criteria not applied in table '{name_li[i][0]}'")    
            
        table_df = table_df.withColumn("table_name", table_name)
        display(table_df)
    except Exception as e:
        print(f"Error in finding distinct values: {e}")

# COMMAND ----------

# STORAGE_ACCOUNT_NAME = "your_storage_account_name"  # Replace with your actual storage account name
print(SOURCE_CONTAINER,' ',STORAGE_ACCOUNT_NAME,' ',SOURCE_FOLDER)
table_path = f"abfss://{SOURCE_CONTAINER}@{STORAGE_ACCOUNT_NAME}.dfs.core.windows.net/{SOURCE_FOLDER}/"
print(table_path)

distinct_filter_values(SOURCE_ZONE, table_path)
print("Rows and duplicates in tables in a zone")

# COMMAND ----------

SOURCE_FOLDER

# COMMAND ----------

# MAGIC %sql
# MAGIC use catalog edh_en_consumption_dev
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC use shng_s4u

# COMMAND ----------

# MAGIC %sql
# MAGIC --[1501,1504,1505,1552,1556,1570,1571,1572,'ECOA','106N']
# MAGIC
# MAGIC select PBUKRS, count(*) from DLCO_V_ACDOCA group by PBUKRS
# MAGIC -- select BUKRS, count(*) from DLCO_V_AUFK group by BUKRS order by BUKRS
# MAGIC
# MAGIC -- select count(*) from DLCO_V_ACDOCA

# COMMAND ----------

