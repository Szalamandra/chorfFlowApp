# Databricks notebook source
import os
import requests
import json
import sys
from glob import glob
from datetime import datetime
sys.path.append(f"{os.path.dirname(os.path.dirname(os.getcwd()))}/utils")
from utils import fileExists,remover
from config_handler import *
from cluster_config import *
from job_dispatcher import *
from pyspark.sql.types import StructType, StructField, IntegerType, StringType,LongType
from pyspark.sql.functions import regexp_replace

# COMMAND ----------

current_directory=os.getcwd()
if current_directory=="/databricks/driver":
    current_directory="/Workspace/Repos/release/edh-en-edz-eam/src/generalized_pipeline/scripts"
config_directory="dbfs:/libraries/edh-en-edz-eam/src/generalized_pipeline/scripts"
script_current_directory=current_directory.replace("/Workspace","")
data_type_path=f"file:{current_directory}/config_files/s4u_data_type.json"
ws_url=spark.conf.get("spark.databricks.workspaceUrl")

# COMMAND ----------

# Get Configuration Variables
config_df =get_config_df(config_directory)
(env, net_type, token) = get_config_values(config_df,ws_url)
storage_account = get_storage_account(net_type,env)

# COMMAND ----------

# Setting Credentials using Platform Values
(scope, client_id, client_secret, tenant_id) =  get_platform_config(config_directory, net_type, env)
set_credentials(scope,storage_account,client_id,client_secret,tenant_id)

# COMMAND ----------


# Getting Payload json from ADF
dbutils.widgets.text("payload_json", "","") 
dbutils.widgets.text("qery_json", "","") 

payload_json = dbutils.widgets.get("payload_json")
qery_json=dbutils.widgets.get("qery_json") 

payload_json=json.loads(payload_json) 
query_json=json.loads(query_json) 

# COMMAND ----------

# setting required parameters for Creating Job
landing_zone_path  = get_landing_path(payload_json, storage_account)
source_system = get_source_system(payload_json)
bu_code = get_bu_code(payload_json)
business_unit,default_flag,uc_flag,scd_flag = get_storage_config(config_directory, bu_code, net_type)
erwin_json_path = get_erwin_json_path(payload_json)
bu=business_unit[0]
landing_zone_table_df=get_lz_tables_df(landing_zone_path)

# COMMAND ----------

print("config dataframe below")
display(config_df)

# COMMAND ----------

print(query_json)

print(payload_json)