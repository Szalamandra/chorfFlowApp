# Databricks notebook source

def set_credentials(scope,storage_account,client_id,client_secret,tenant_id):
    service_credential = dbutils.secrets.get(scope=scope,key=client_id)
    service_credential1 = dbutils.secrets.get(scope=scope,key=client_secret)


    spark.conf.set(f"fs.azure.account.auth.type.{storage_account}.dfs.core.windows.net", "OAuth")
    spark.conf.set(f"fs.azure.account.oauth.provider.type.{storage_account}.dfs.core.windows.net","org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
    spark.conf.set(f"fs.azure.account.oauth2.client.id.{storage_account}.dfs.core.windows.net", service_credential)
    spark.conf.set(f"fs.azure.account.oauth2.client.secret.{storage_account}.dfs.core.windows.net", service_credential1)
    spark.conf.set(f"fs.azure.account.oauth2.client.endpoint.{storage_account}.dfs.core.windows.net", f"https://login.microsoftonline.com/{tenant_id}/oauth2/token")

# COMMAND ----------


net_type = "en"
env = "qas"
scope=f"databricks_{env}_{net_type}_scope"
# storage_account=f"stedheneamlanding{env}"

scope=f"databricks_{env}_{net_type}_scope"


storage_account=f"stedhenis01land{env}"
# storage_account=f"stedhenis01ext{env}"

# storage_account=f"stedhen2444consdev"

config_directory="dbfs:/libraries/edh-en-edz-eam/src/generalized_pipeline/scripts"
platform_config_path=f"{config_directory}/config_files/platform_config.json"
platform_config=spark.read.json(platform_config_path,multiLine=True)
platform_config_values= platform_config.collect()
client_secret = platform_config_values[0]['client_secret']
client_id = platform_config_values[0]['client_id']
tenant_id = platform_config_values[0]['tenant_id']



  
set_credentials(scope,storage_account,client_id,client_secret,tenant_id)

# COMMAND ----------

dbutils.fs.ls(f'abfss://isu@{storage_account}.dfs.core.windows.net/NonPII/')

# COMMAND ----------



def checkMandt(tablelist,storageacc):
    for table in tablelist:
        tableDFName=f'{table}_df'
        tableDFName=spark.read.format('delta').load(f'abfss://{storageacc}.dfs.core.windows.net/NonPII/{table}/')
        tableDFName.createOrReplaceTempView(f'{table}_table')
        print(table)
        spark.sql(f'select MANDT, count(*) as cnt from {table}_table group by MANDT having cnt>1').display()


def checkColumn(tablelist,storageacc,colName):
    for table in tablelist:
        tableDFName=f'{table}_df'
        tableDFName=spark.read.format('delta').load(f'abfss://{storageacc}.dfs.core.windows.net/NonPII/{table}/')
        tableDFName.createOrReplaceTempView(f'{table}_table')
        print(table)
        spark.sql(f'select {colName}, count(*) as cnt from {table}_table group by {colName} having cnt>1').display()

# COMMAND ----------

for table in tables:
    tableDFName=f'{table}_df'
    tableDFName=spark.read.format('delta').load(f'abfss://s4utilities@{storage_account}.dfs.core.windows.net/NonPII/{table}/')
    tableDFName.createOrReplaceTempView(f'{table}_table')
    print(table)
    spark.sql(f'select MANDT, count(*) as cnt from {table}_table group by MANDT having cnt>1').display()

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC  landing

# COMMAND ----------




storageacc=f'test@{storage_account}'

dbutils.fs.ls(f'abfss://{storageacc}.dfs.core.windows.net/hen')

# COMMAND ----------



storageacc=f'eegis-oracle@{storage_account}'

dbutils.fs.ls(f'abfss://{storageacc}.dfs.core.windows.net/hen/2024/09/12')

# COMMAND ----------

df_ever=spark.read.options(header=True, delimiter="|").format('csv').load(f'abfss://test@stedhenis01landdev.dfs.core.windows.net/hen/2024/07/17/EVER.parquet')

df_ever.createOrReplaceTempView(f'ever_t')
print('ever_t')
# spark.sql(f'select ".NODE1", count(*) as cnt from ever group by ".NODE1" having cnt>1').display()

spark.sql(f'select count(*) from ever_t').display()
spark.sql(f'select distinct * from ever_t').display()

# COMMAND ----------

# df_ever=spark.read.options(header=True, delimiter="|").format('csv').load(f'abfss://test@stedhenis01landdev.dfs.core.windows.net/hen/2024/07/17/EVER.parquet')
df_ever=spark.read.format('parquet').load(f'abfss://eegis-oracle@stedhenis01landqas.dfs.core.windows.net/hen/2024/09/12/ARAMVALTOK.parquet', name='ARAMVALTOK.parquet')

df_ever.createOrReplaceTempView(f'ARAMVALTOK')
print('ARAMVALTOK')
# spark.sql(f'select ".NODE1", count(*) as cnt from ever group by ".NODE1" having cnt>1').display()

spark.sql(f'select * from ARAMVALTOK').display()
# spark.sql(f'select distinct * from ARAMVALTOK').display()

# COMMAND ----------

df_ever=spark.read.format('delta').load(f'abfss://edh@stedhen2444consqas.dfs.core.windows.net/eegis/ARAMVALTOK/')

df_ever.createOrReplaceTempView(f'ARAMVALTOK')
print('ARAMVALTOK')
# spark.sql(f'select ".NODE1", count(*) as cnt from ever group by ".NODE1" having cnt>1').display()

spark.sql(f'select * from ARAMVALTOK').display()

# COMMAND ----------


df_zisu_mdat=spark.read.options(header=True, delimiter="|").format('csv').load(f'abfss://isu@stedhenis01landdev.dfs.core.windows.net/hen/2024/06/19/ZISU_MDAT-00001.parquet')
df_zisu_mdat=spark.read.options(header=True, delimiter="|").format('csv').load(f'abfss://isu@stedhenis01landdev.dfs.core.windows.net/hen/2024/06/19/ZISU_MDAT-00002.parquet')

df_zisu_mdat.createOrReplaceTempView(f'zisu_mdat1')
print('zisu_mdat1')
# spark.sql(f'select ".NODE1", count(*) as cnt from zisu_mdat group by ".NODE1" having cnt>1').display()

spark.sql(f'select count(*) from zisu_mdat1').display()
spark.sql(f'select distinct count(*) from zisu_mdat1').display()

# COMMAND ----------

# MAGIC %md
# MAGIC ErrorCode=DelimitedTextMoreColumnsThanDefined,'Type=Microsoft.DataTransfer.Common.Shared.HybridDeliveryException,Message=Error found when processing 'Csv/Tsv Format Text' source 'ZISU_MDAT_20240516_084644.csv' with row number 2384181: found more columns than expected column count 75.,Source=Microsoft.DataTransfer.Common,'

# COMMAND ----------


df_zisu_mdat=spark.read.options(header=True, delimiter="|").format('csv').load(f'abfss://2444@stedhenis01extdev.dfs.core.windows.net/isu/ZISU_MDAT_20240516_084644.csv')

df_zisu_mdat.createOrReplaceTempView(f'zisu_mdat')
print('zisu_mdat')
# spark.sql(f'select ".NODE1", count(*) as cnt from zisu_mdat group by ".NODE1" having cnt>1').display()

spark.sql(f'select * from zisu_mdat').display(5)

# COMMAND ----------

spark.sql(f'select  MRRES,count(MRRES) as cnt from zisu_mdat group by MRRES having cnt>1').display(5)

# COMMAND ----------

df_zisu_mdat.show()

# COMMAND ----------

# MAGIC %md
# MAGIC --------------------------------------------------------------------------------------------------------------------------------------
# MAGIC check with incremental index the particular rows

# COMMAND ----------

from pyspark.sql.functions import lit,row_number,col
from pyspark.sql.window import Window
from pyspark.sql import functions as F

df_zisu_mdat = df_zisu_mdat.withColumn("_index", F.monotonically_increasing_id())

w = Window().partitionBy(lit('_index')).orderBy(lit('_index'))
# df1 = df_zisu_mdat.withColumn("row_num", row_number().over(w))

# df1.show()


# COMMAND ----------



df1.filter(col('row_num').between(2,4)).display()

# COMMAND ----------

df1 = df_zisu_mdat.withColumn("row_num", row_number().over(w))
df1.filter(col('_index').between(41160620,41160635)).display()

# COMMAND ----------

spark.sql(f'select count(*) from zisu_mdat').display()

# COMMAND ----------

df_zisu_mdat_dropped=spark.read.options(header=True, delimiter="|",mode="DROPMALFORMED").format('csv').load(f'abfss://2444@stedhenis01extdev.dfs.core.windows.net/isu/ZISU_MDAT_20240516_084644.csv')

df_zisu_mdat.createOrReplaceTempView(f'zisu_mdat_dr')
print('zisu_mdat')
spark.sql(f'select count(*) from zisu_mdat_dr').display()

# COMMAND ----------

df_zisu_mdat_dropped=spark.read.options(header=True, delimiter="|",LineSep="\n", maxColumns=75).format('csv').load(f'abfss://2444@stedhenis01extdev.dfs.core.windows.net/isu/ZISU_MDAT_20240516_084644.csv')

df_zisu_mdat.createOrReplaceTempView(f'zisu_mdat_s')
print('zisu_mdat')
spark.sql(f'select count(*) from zisu_mdat_s').display()

# COMMAND ----------

df_zisu_mdat_dropped=spark.read.options(header=True, delimiter="|",LineSep="\n", maxColumns=75,mode="DROPMALFORMED").format('csv').load(f'abfss://2444@stedhenis01extdev.dfs.core.windows.net/isu/ZISU_MDAT_20240516_084644.csv')

df_zisu_mdat.createOrReplaceTempView(f'zisu_mdat_s')
print('zisu_mdat')
spark.sql(f'select count(*) from zisu_mdat_s').display()

# COMMAND ----------

spark.sql(f'select * from zisu_mdat_s').display(5)

# COMMAND ----------

df_zisu_mdat_dropped=spark.read.options(header=True, delimiter="|",LineSep="\n", maxColumns=75,mode="PERMISSIVE").format('csv').load(f'abfss://2444@stedhenis01extdev.dfs.core.windows.net/isu/ZISU_MDAT_20240516_084644.csv')

from pyspark.sql import functions as F

df_zisu_mdat_dropped=spark.read.options(header=True, delimiter="|").format('csv').load(f'abfss://2444@stedhenis01extdev.dfs.core.windows.net/isu/ZISU_MDAT_20240516_084644.csv')

# Function to get rows at `rownums`
def getrows(df, rownums=None):
    return df.filter(df["_index"].isin(rownums))

# Add an index column to the DataFrame
df_zisu_mdat_dropped = df_zisu_mdat_dropped.withColumn("_index", F.monotonically_increasing_id())


df_zisu_mdat_dropped.createOrReplaceTempView(f'zisu_mdat_spermDROPPED')
print('zisu_mdat')
spark.sql(f'select * from zisu_mdat_spermDROPPED').display()

# COMMAND ----------

spark.sql(f'select * from zisu_mdat_spermDROPPED WHERE _index=41160626').display()

# COMMAND ----------

df_zisu_mdat_dropped=spark.read.options(header=True, delimiter="|",LineSep="\n", maxColumns=75,mode="FAILFAST").format('csv').load(f'abfss://2444@stedhenis01extdev.dfs.core.windows.net/isu/ZISU_MDAT_20240516_084644.csv')

df_zisu_mdat.createOrReplaceTempView(f'zisu_mdat_sss')
print('zisu_mdat')
spark.sql(f'select count(*) from zisu_mdat_sss').display()

# COMMAND ----------

# MAGIC %md
# MAGIC ErrorCode=DelimitedTextMoreColumnsThanDefined,'Type=Microsoft.DataTransfer.Common.Shared.HybridDeliveryException,Message=Error found when processing 'Csv/Tsv Format Text' source 'ZISU_MDAT_20240516_084644.csv' with row number 41160627: found more columns than expected column count 75.,Source=Microsoft.DataTransfer.Common,'

# COMMAND ----------

from pyspark.sql import functions as F

df=spark.read.options(header=True, delimiter="|").format('csv').load(f'abfss://2444@stedhenis01extdev.dfs.core.windows.net/isu/ZISU_MDAT_20240516_084644.csv')

# Function to get rows at `rownums`
def getrows(df, rownums=None):
    return df.filter(df["_index"].isin(rownums))

# Add an index column to the DataFrame
df = df.withColumn("_index", F.monotonically_increasing_id())

# Get rows at positions 0 and 2.
getrows(df, rownums=[0, 2]).collect()

# COMMAND ----------

getrows(df, rownums=[2384180,2384181,2384182]).collect()

# COMMAND ----------

df.createOrReplaceTempView(f'zisu_mdat')
print('zisu_mdat')

spark.sql(f'select * from zisu_mdat where _index=2384180').display()
spark.sql(f'select * from zisu_mdat where _index=2384181').display()

# COMMAND ----------

spark.sql(f'select * from zisu_mdat where _index=2384180').display()
spark.sql(f'select * from zisu_mdat where _index=2384181').display()

# COMMAND ----------

spark.sql(f'select * from zisu_mdat where _index=1').display()

# COMMAND ----------

getrows(df, rownums=[2384181]).collect()

# COMMAND ----------

# MAGIC %md
# MAGIC LANDING
# MAGIC

# COMMAND ----------


df_zisu_mdat=spark.read.format('parquet').load(f'abfss://test@stedhenis01landdev.dfs.core.windows.net/test/ZISU_MDAT-00001')
df_zisu_mdat=spark.read.format('parquet').load(f'abfss://isu@stedhenis01landdev.dfs.core.windows.net/hen/2024/06/12/EPROFHEAD.parquet')
df_zisu_mdat.createOrReplaceTempView(f'zisu_mdat1')
# print('zisu_mdat')
# spark.sql(f'select ".NODE1", count(*) as cnt from zisu_mdat group by ".NODE1" having cnt>1').display()

df_zisu_mdat=spark.read.format('parquet').load(f'abfss://test@stedhenis01landdev.dfs.core.windows.net/test/ZISU_MDAT-00002')

df_zisu_mdat.createOrReplaceTempView(f'zisu_mdat2')

spark.sql(f'select count(*) from zisu_mdat1').display()

spark.sql(f'select count(*) from zisu_mdat1 as zm1 inner join zisu_mdat2 as zm2 on zm1.ABLBELNR=zm2.ABLBELNR ').display()

# COMMAND ----------

# MAGIC %md
# MAGIC ######check for NODE1
# MAGIC "IPMSQNOFHDR","IPMSQNOHDR","IPMSQWOPER","IV_MPLA",

# COMMAND ----------


IPMSQWOPER=spark.read.format('delta').load(f'abfss://eam@stedhenedisconsqas.dfs.core.windows.net/NonPII/IPMSQWOPER/')
IPMSQWOPER.createOrReplaceTempView(f'IPMSQWOPER')
print(table)
spark.sql(f'select ".NODE1", count(*) as cnt from IPMSQWOPER group by ".NODE1" having cnt>1').display()



# COMMAND ----------

IV_MPLA.columns

# COMMAND ----------

#s4u  edi

storageacc=f's4u@stedhenediscons{env}'

dbutils.fs.ls(f'abfss://{storageacc}.dfs.core.windows.net/NonPII/')

# COMMAND ----------

storageacc=f's4u@stedhenediscons{env}'

#"DLCO_V_ACDOCA","DLCO_V_COOI",
tables=["C_EDH_Business_Asset","C_EDH_Measure","C_EDH_Status","DLCO_V_CSKB","DLCO_V_CSKT","DLCO_V_CSLA","DLCO_V_CSLT","DLCO_V_CSSL","DLCO_V_PROJ","DLCO_V_PRPS","DLFI_V_BKPF","DLFI_V_BSEG","DLFI_V_BSET","DLFI_V_BSID","DLFI_V_BVOR","DLFI_V_SKB1","DLFI_V_T001","DLMM_V_EBAN","DLMM_V_EKKO","DLMM_V_EKPO","DLSD_V_VBAK","DLSD_V_VBAP","DLSD_V_VBRK","DLSD_V_VBRP"]



#maincotroltable
# tablesALL=[
# /EON/DLCO_V_ACDOCA /EON/DLCO_V_COOI /EON/DLCO_V_CSKB /EON/DLCO_V_CSKT /EON/DLCO_V_CSLA /EON/DLCO_V_CSLT /EON/DLCO_V_CSSL /EON/DLCO_V_PROJ /EON/DLCO_V_PRPS /EON/DLFI_V_BKPF /EON/DLFI_V_BSEG /EON/DLFI_V_BSET /EON/DLFI_V_BSID /EON/DLFI_V_BVOR /EON/DLFI_V_SKB1 /EON/DLFI_V_T001 /EON/DLMM_V_EBAN /EON/DLMM_V_EKKO /EON/DLMM_V_EKPO /EON/DLSD_V_VBAK /EON/DLSD_V_VBAP /EON/DLSD_V_VBRK /EON/DLSD_V_VBRP /KAW/C_EDH_Business_Asset /KAW/C_EDH_Measure /KAW/C_EDH_Status AUFK CCVDOCOBJATTCHDE  JCDS JEST JSTO TJ30T  EKKN]
nonTables=[]



checkMandt(tables,storageacc)

# COMMAND ----------

len(tables)

# COMMAND ----------

# "DLCO_V_ACDOCA","DLCO_V_COOI"
storageacc=f's4u@stedhenediscons{env}'

df_acdoca=spark.read.format('delta').load(f'abfss://{storageacc}.dfs.core.windows.net/NonPII/DLCO_V_ACDOCA/')
df_acdoca.createOrReplaceTempView(f'df_acdoca_table')
print(table)
spark.sql(f'select ".NODE1", count(*) as cnt from df_acdoca_table group by ".NODE1" having cnt>1').display()

DLCO_V_COOI=spark.read.format('delta').load(f'abfss://{storageacc}.dfs.core.windows.net/NonPII/DLCO_V_COOI/')
DLCO_V_COOI.createOrReplaceTempView(f'DLCO_V_COOI')
print(table)
spark.sql(f'select ".NODE1", count(*) as cnt from DLCO_V_COOI group by ".NODE1" having cnt>1').display()


# COMMAND ----------

df_acdoca.columns

# COMMAND ----------

DLCO_V_COOI.columns

# COMMAND ----------

# MAGIC %md
# MAGIC #####further analyzes

# COMMAND ----------

storageacc=f's4u@stedhenavaconcons{env}'
tables=["DLCO_V_ACDOCA",'DLCO_V_ACDOCP']
# tables=["DLCO_V_ACDOCA",'DLCOSQACDCA']   edis

checkColumn(tables,storageacc,'".NODE1"')
checkColumn(tables,storageacc,'RCLNT')

# COMMAND ----------

storageacc=f's4u@stedhenediscons{env}'

tables=["DLCO_V_ACDOCA"]   

checkColumn(tables,storageacc,'".NODE1"')
checkColumn(tables,storageacc,'RCLNT')

# COMMAND ----------

